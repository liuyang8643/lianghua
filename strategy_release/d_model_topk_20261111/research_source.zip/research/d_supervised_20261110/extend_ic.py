"""Complete missing fit-period dailyIC once for allABC versions."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[key]='1'
import concurrent.futures,json,multiprocessing,time
from pathlib import Path
import numpy as np
from ai.supervised.ic import daily_ic
from env.forward_returns import label_split_mask
from factor_db import require_allowed_factor_names
from scripts.run_research_guarded import require_guarded_job
from utils.atomic_file import atomic_write_json,file_sha256
from .prepare import ROOT,PARENT

STATE=None
def initialize():
    global STATE
    read=lambda p:json.loads(p.read_text(encoding='utf8'))
    inventory=read(PARENT/'features/inventory.json');dates=np.load(PARENT/'features/dates.npy')
    eligible=np.load(PARENT/'features/label_eligible.npy',mmap_mode='r')
    labels={h:np.load(PARENT/'features'/f'labels_{h}d.npy',mmap_mode='r') for h in (3,7,15,30,60)}
    first=int(np.flatnonzero(label_split_mask(dates,'2005-01-01','2021-12-31',60))[-1])+1
    stop=int(np.flatnonzero(label_split_mask(dates,'2005-01-01','2025-12-31',60))[-1])+1
    STATE=(inventory,dates,eligible,labels,first,stop)

def compute(name):
    inventory,dates,eligible,labels,first,stop=STATE
    require_allowed_factor_names([name]);record=inventory[name];assert file_sha256(record['path'])==record['sha256']
    target=ROOT/'extended_ic';receipt=target/f'{name}.json'
    identity={'feature_sha256':record['sha256'],'first':first,'stop':stop,'source_sha256':file_sha256(__file__),'kernel_sha256':file_sha256('ai/supervised/ic.py')}
    if receipt.exists():
        saved=json.loads(receipt.read_text());assert saved['identity']==identity
        for h,r in saved['outputs'].items():assert file_sha256(r['path'])==r['sha256']
        return name
    values=np.load(record['path'],mmap_mode='r');outputs={}
    for h,label in labels.items():
        old=record['daily_ic'][str(h)];assert file_sha256(old['path'])==old['sha256']
        combined=np.load(old['path']).copy()
        combined[first:stop]=daily_ic(values[first:stop],label[first:stop],eligible[first:stop])
        path=target/f'{name}_{h}d.npy';np.save(path,combined)
        outputs[str(h)]={'path':str(path),'sha256':file_sha256(path)}
    atomic_write_json(receipt,{'identity':identity,'outputs':outputs});return name

def main():
    require_guarded_job();began=time.monotonic();target=ROOT/'extended_ic';target.mkdir(exist_ok=True)
    protocol=json.loads((ROOT/'protocol.json').read_text(encoding='utf8'));inventory=json.loads((PARENT/'features/inventory.json').read_text(encoding='utf8'))
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('spawn'),initializer=initialize) as pool:
        for count,name in enumerate(pool.map(compute,sorted(inventory)),1):
            if count%20==0:
                atomic_write_json(ROOT/'ic_status.json',{'state':'computing','factors':count,'total':len(inventory),'last':name});print({'factors':count,'total':len(inventory)},flush=True)
    dates=np.load(PARENT/'features/dates.npy')
    for spec in protocol['versions']:
        means={};counts={};mask=label_split_mask(dates,*spec['fit'],60)
        for h in protocol['model_horizons']:
            means[str(h)]={};counts[str(h)]={}
            for name in sorted(inventory):
                v=np.load(target/f'{name}_{h}d.npy')[mask,1];v=v[np.isfinite(v)]
                means[str(h)][name]=float(v.mean()) if len(v)>=60 else None;counts[str(h)][name]=len(v)
        atomic_write_json(ROOT/spec['name']/'fit_ic_complete.json',{'spec':spec,'means':means,'counts':counts,'last_feature_date':str(dates[np.flatnonzero(mask)[-1]]),'last_label_end':str(dates[np.flatnonzero(mask)[-1]+60])})
    atomic_write_json(ROOT/'ic_status.json',{'state':'complete','factors':len(inventory),'seconds':time.monotonic()-began})

if __name__=='__main__':main()
