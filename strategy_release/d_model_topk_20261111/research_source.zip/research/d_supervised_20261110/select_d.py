"""Exact fit-only daily Spearman pruning forB/C, with compatible prefix reuse."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='4'
import json,time
from pathlib import Path
import numpy as np
from numba import set_num_threads
from ai.supervised.selection import exact_day_spearman
from ai.supervised.multihorizon_select import select_one
from env.forward_returns import label_split_mask
from utils.atomic_file import atomic_write_json,file_sha256
from scripts.run_research_guarded import require_guarded_job
from .prepare import ROOT,PARENT

def main():
    require_guarded_job();set_num_threads(4);began=time.monotonic()
    read=lambda p:json.loads(p.read_text(encoding='utf8'))
    assert read(ROOT/'ic_status.json')['state']=='complete'
    protocol=read(ROOT/'protocol.json');inventory=read(PARENT/'features/inventory.json')
    specs=protocol['versions'];data={s['name']:read(ROOT/s['name']/'fit_ic_complete.json') for s in specs}
    positive=sorted({name for d in data.values() for means in d['means'].values() for name,value in means.items() if value is not None and value>0})
    canonical={}
    for name in positive:canonical.setdefault(inventory[name]['sha256'],name)
    names=sorted(canonical.values());index={inventory[n]['sha256']:i for i,n in enumerate(names)}
    dates=np.load(PARENT/'features/dates.npy');eligible=np.load(PARENT/'features/label_eligible.npy',mmap_mode='r')
    ends={s['name']:int(np.flatnonzero(label_split_mask(dates,*s['fit'],60))[-1]) for s in specs}
    stage=ROOT/'correlation_bc';stage.mkdir(exist_ok=True)
    identity={'source':file_sha256(__file__),'kernel':file_sha256('ai/supervised/selection.py'),'names':names,'features':{n:inventory[n]['sha256'] for n in names},'ends':ends,'ic_inputs':{s['name']:file_sha256(ROOT/s['name']/'fit_ic_complete.json') for s in specs},'eligible':file_sha256(PARENT/'features/label_eligible.npy')}
    if (stage/'identity.json').exists():assert read(stage/'identity.json')==identity
    else:atomic_write_json(stage/'identity.json',identity)
    arrays=[]
    for name in names:
        assert file_sha256(inventory[name]['path'])==inventory[name]['sha256'];arrays.append(np.load(inventory[name]['path'],mmap_mode='r'))
    sums=np.zeros((len(names),len(names)));counts=np.zeros(sums.shape,np.int32);first=0;reuse='none'
    old=PARENT/'fold_selection';oldid=read(old/'identity.json');oldindex={inventory[n]['sha256']:i for i,n in enumerate(oldid['names'])}
    if all(inventory[n]['sha256'] in oldindex for n in names):
        cp=read(old/'checkpoint.json');assert file_sha256(old/cp['file'])==cp['sha256'] and oldid['kernel']==identity['kernel']
        take=[oldindex[inventory[n]['sha256']] for n in names]
        with np.load(old/cp['file']) as z:sums=z['sums'][np.ix_(take,take)];counts=z['days'][np.ix_(take,take)];first=int(z['next'])
        assert first<=min(ends.values());reuse='verified_parent2021_prefix'
    checkpoint=stage/'checkpoint.json'
    if checkpoint.exists():
        cp=read(checkpoint);assert cp['identity_sha256']==file_sha256(stage/'identity.json') and file_sha256(stage/cp['file'])==cp['sha256']
        with np.load(stage/cp['file']) as z:sums=z['sums'];counts=z['days'];first=int(z['next'])
        reuse='own_verified_checkpoint'
    print({'stage':'correlation_start','factors':len(names),'next_row':first,'total':max(ends.values())+1,'reuse':reuse},flush=True)
    for t in range(first,max(ends.values())+1):
        values=np.stack([a[t,eligible[t]] for a in arrays]);corr,_=exact_day_spearman(values);valid=np.isfinite(corr);sums+=np.where(valid,corr,0);counts+=valid
        if t in ends.values():
            mean=np.divide(sums,counts,out=np.full(sums.shape,np.nan),where=counts>0)
            for spec in specs:
                if ends[spec['name']]!=t:continue
                directory=ROOT/spec['name']/'fold_selection'/spec['name'];directory.mkdir(parents=True,exist_ok=True);union=set()
                ids=[index[inventory[n]['sha256']] for n in positive];expanded=mean[np.ix_(ids,ids)];days=counts[np.ix_(ids,ids)].copy()
                for i in range(len(positive)):
                    for j in range(i):
                        if ids[i]==ids[j]:expanded[i,j]=expanded[j,i]=1.;days[i,j]=days[j,i]=10**9
                for h in protocol['model_horizons']:
                    means=data[spec['name']]['means'][str(h)];kept,removed=select_one(positive,means,expanded,days);selected=[positive[i] for i in kept];union.update(selected)
                    atomic_write_json(directory/f'selected_{h}d.json',{'horizon':h,'fit':spec['fit'],'selected':[{'name':n,'rank_ic':means[n],'valid_days':data[spec['name']]['counts'][str(h)][n]} for n in selected],'removed':removed,'threshold':.8})
                chosen=sorted(union);ii=[index[inventory[n]['sha256']] for n in chosen]
                np.savez_compressed(directory/'correlation.npz',names=np.asarray(chosen),correlation=mean[np.ix_(ii,ii)],valid_days=counts[np.ix_(ii,ii)])
                atomic_write_json(directory/'complete.json',{'state':'complete','features':chosen,'spec':spec,'fit_only':True,'last_feature_date':str(dates[t]),'identity_sha256':file_sha256(stage/'identity.json')})
                print({'selection_complete':spec['name'],'features':len(chosen)},flush=True)
        if (t+1)%25==0 or t in ends.values():
            filename=f'checkpoint_{t+1}.npz';np.savez_compressed(stage/filename,sums=sums,days=counts,next=t+1)
            atomic_write_json(checkpoint,{'file':filename,'sha256':file_sha256(stage/filename),'identity_sha256':file_sha256(stage/'identity.json')})
            atomic_write_json(stage/'status.json',{'state':'running','days':t+1,'total':max(ends.values())+1,'seconds':time.monotonic()-began})
    assert file_sha256(__file__)==identity['source']
    atomic_write_json(stage/'status.json',{'state':'complete','days':max(ends.values())+1,'seconds':time.monotonic()-began})

if __name__=='__main__':main()
