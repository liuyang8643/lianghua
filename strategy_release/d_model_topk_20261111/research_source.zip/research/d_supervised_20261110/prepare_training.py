"""Extend selected factor tails with existing adapters, then fitB orC."""
import argparse,gc,json,os,sys
from pathlib import Path
import numpy as np
import psutil
from scripts.run_research_guarded import require_guarded_job
from utils.atomic_file import atomic_write_json,file_sha256
from .prepare import ROOT,PARENT

def prepare(version):
    read=lambda p:json.loads(p.read_text(encoding='utf8'))
    protocol=read(ROOT/'protocol.json');spec=next(s for s in protocol['versions'] if s['name']==version);root=ROOT/version
    selection=root/'fold_selection'/version/'complete.json';selected=read(selection);assert selected['state']=='complete' and selected['spec']==spec;names=selected['features']
    latest=Path('artifacts/research/supervised_expand_2025_stop2026_1109_20261110/features');latestinv=read(latest/'inventory.json');oldinv=read(PARENT/'features/inventory.json')
    for path,sha in read(PARENT/'features/identity.json')['factor_sources'].items():assert file_sha256(path)==sha,path
    source=root/'features';source.mkdir(exist_ok=True)
    for name,sha in read(latest/'data_manifest.json').items():
        assert file_sha256(latest/name)==sha
        if not (source/name).exists():os.link(latest/name,source/name)
        assert file_sha256(source/name)==sha
    atomic_write_json(source/'data_manifest.json',read(latest/'data_manifest.json'))
    inventory={}
    for name in names:
        if name in latestinv:
            r=latestinv[name];assert file_sha256(r['path'])==r['sha256'];inventory[name]=r
    needed=set(names)-set(inventory)
    shared=Path('artifacts/research/abc_supervised_20261110/extended_columns');shared.mkdir(exist_ok=True)
    for name in sorted(needed.copy()):
        receipt=shared/f'{name}.json'
        if receipt.exists():
            r=read(receipt);assert r['old_sha256']==oldinv[name]['sha256'] and file_sha256(r['path'])==r['sha256'];inventory[name]=r;needed.remove(name)
    if needed:
        from offline_data import load_runtime_slice
        from offline_data.contracts import RuntimeSlice
        from ai.supervised.feature_data import materialize_factor_values,rank_features
        from ai.supervised.dated_features import source_inputs
        active=read(PARENT/'active_data.json');assert file_sha256(active['runtime_path'])==active['runtime_sha256']
        tail=Path('artifacts/research/new_topk_ytd_20261106');today=Path('artifacts/research/topk_today_20261109');reference=Path('artifacts/research/multihorizon_2026_explain_20261107_reference_complete')
        assert file_sha256(today/'quotes.json')==read(today/'input_identity.json')['quotes_sha256']
        base=load_runtime_slice(active['runtime_path'],'2026-10-30','2026-11-06',preload_rows=100001,cache_dir=Path(read(tail/'protocol.json')['feature_runtime_cache']))
        dates=np.concatenate((base.trade_dates,np.array(['2026-11-09'],dtype='datetime64[D]')));fields={}
        for name,a in base.data.items():
            fields[name]=a if a.ndim==1 else np.load(today/'runtime_fields'/f'{name}.npy',mmap_mode='r')
            if a.ndim==2:np.testing.assert_array_equal(fields[name][:-1],a)
        rt=RuntimeSlice(stock_codes=base.stock_codes,trade_dates=dates,data=fields,decision_start=base.decision_start,decision_stop=len(dates),manifest=base.manifest)
        axis=np.load(latest/'dates.npy');old_dates=np.load(PARENT/'features/dates.npy');eligible=np.load(latest/'eligible.npy',mmap_mode='r')
        np.testing.assert_array_equal(axis[:len(old_dates)],old_dates);np.testing.assert_array_equal(rt.stock_codes,np.load(latest/'codes.npy').astype(str))
        tail_start=int(np.searchsorted(dates,old_dates[-1]));np.testing.assert_array_equal(dates[tail_start:],axis[len(old_dates)-1:])
        industry,dividends,extra=source_inputs(reference,PARENT);monthly=tail/'monthly/monthly.npz';assert file_sha256(monthly)==read(tail/'monthly/complete.json')['output_sha256']
        inputs={'runtime':active['runtime_sha256'],'snapshot':file_sha256(today/'input_identity.json'),'extra':{str(p):file_sha256(p) for p in extra},'monthly':file_sha256(monthly),'builder':file_sha256(__file__),'adapter':file_sha256('ai/supervised/feature_data.py')}
        bound={x['name'] for x in read(PARENT/'bound_preflight.json')['results']}
        def save(name,raw):
            original=oldinv[name];assert file_sha256(original['path'])==original['sha256']
            old=np.load(original['path'],mmap_mode='r');tail_values=rank_features(np.asarray(raw)[tail_start:],eligible[len(old_dates)-1:],original['normalization']=='binary')
            np.testing.assert_array_equal(tail_values[0],old[-1],err_msg='Oct30 factor overlap mismatch:'+name)
            path=shared/f'{name}.npy';values=np.lib.format.open_memmap(path,mode='w+',dtype=old.dtype,shape=eligible.shape)
            values[:len(old)]=old;values[len(old):]=tail_values[1:];values.flush();del values
            r={**original,'path':str(path.resolve()),'sha256':file_sha256(path),'old_sha256':original['sha256'],'shape':list(eligible.shape),'tail_inputs':inputs}
            atomic_write_json(shared/f'{name}.json',r);inventory[name]=r
            print({'version':version,'tail_factor_complete':name,'columns_ready':len(inventory),'total':len(names)},flush=True)
        with np.load(monthly) as payload:materialize_factor_values(rt,needed,save,bound_names=bound,industry_history=industry,dividend_events=dividends,monthly_payload=payload)
    assert sorted(inventory)==sorted(names)
    # Selection receipts describe the current fit window; inheritedIC tables
    # from the2021 source cache must not masquerade asB/C diagnostics.
    inventory={name:{**{key:value for key,value in record.items() if key!='daily_ic'},
                     'fit_ic_source':str((root/'fit_ic_complete.json').resolve()),
                     'fit_ic_sha256':file_sha256(root/'fit_ic_complete.json')}
               for name,record in inventory.items()}
    atomic_write_json(source/'inventory.json',inventory)
    config={'model_horizons':protocol['model_horizons'],'compute':protocol['compute'],'spec':spec,'portfolio':protocol['portfolio'],'standard_sha256':protocol['standard_sha256'],'candidate_pool_sha256':protocol['candidate_pool_sha256'],'feature_count':len(names),'as_of':'2026-11-09'}
    if (root/'protocol.json').exists():assert read(root/'protocol.json')==config
    else:atomic_write_json(root/'protocol.json',config)
    return root,spec

def main(version):
    require_guarded_job()
    for process in psutil.process_iter(['cmdline']):
        assert 'research.abc_supervised_20261110.train_a' not in (process.info['cmdline'] or []),'A training still active'
    assert psutil.virtual_memory().available>=24*2**30,'Insufficient physical memory before input preparation'
    vendor=Path('artifacts/research/topk_multistart_20261109')
    manifest=json.loads((vendor/'report_dependencies_manifest.json').read_text())
    for name,sha in manifest['files'].items():assert file_sha256(vendor/'report_dependencies'/name)==sha
    sys.path.insert(0,str((vendor/'report_dependencies').resolve()))
    root,spec=prepare(version);gc.collect()
    from ai.supervised.multihorizon_model import fit_one
    atomic_write_json(root/'input_preparation_complete.json',{'state':'prepared_through_20261109_requires_1110_label_extension_before_fit','spec':spec});print('Input preparation complete; Nov10 label endpoint extension pending before fit',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('version',choices=['D']);main(parser.parse_args().version)
