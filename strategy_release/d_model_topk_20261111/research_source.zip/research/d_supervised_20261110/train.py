import json,sys,gc
from pathlib import Path
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from utils.atomic_file import atomic_write_json,file_sha256

def main():
 require_guarded_job();root=Path('artifacts/research/d_supervised_20261110/D');source=root/'features';read=lambda p:json.loads(p.read_text(encoding='utf8'));vendor=Path('artifacts/research/topk_multistart_20261109/report_dependencies')
 for name,sha in read(vendor.parent/'report_dependencies_manifest.json')['files'].items():assert file_sha256(vendor/name)==sha
 sys.path.insert(0,str(vendor.resolve()))
 from env.forward_returns import open_forward_returns
 from ai.supervised.feature_data import rank_features
 from research.d_supervised_20261110.model import fit_one,label_split_mask
 dates=np.load(source/'dates.npy');codes=np.load(source/'codes.npy').astype(str);assert str(dates[-1])=='2026-11-09'
 q9=read(Path('artifacts/research/topk_today_20261109/quotes.json'));q10=read(Path('artifacts/research/C_ytd_20261110/quotes.json'))
 panel={}
 for k in ('open','close','preClose','listing_age','delisted_mask'):
  a=np.load(Path('artifacts/research/topk_today_20261109/runtime_fields')/(k+'.npy'),mmap_mode='r')[-61:].copy();tail=a[-1].copy()
  if k=='close':
   a[-1]=[q9[c]['last'] if q9[c]['timestamp'].startswith('20261109') and q9[c]['last']>0 else np.nan for c in codes];tail[:]=np.nan
  elif k in ('open','preClose'):
   key='open' if k=='open' else 'reference';tail=np.array([q10[c][key] if q10[c]['timestamp'].startswith('20261110') and q10[c][key]>0 else np.nan for c in codes],dtype=a.dtype)
  elif k=='listing_age':tail=np.where(tail>=0,tail+1,-1)
  panel[k]=np.concatenate((a,tail[None,:]))
 buyable=np.load(source/'label_eligible.npy',mmap_mode='r');checks={}
 for h in (3,7,15,30,60):
  path=source/f'labels_{h}d.npy';old=np.load(path);new=old.copy();tail=open_forward_returns(panel,h)
  np.testing.assert_allclose(tail[:61-h],old[-61:-h],rtol=1e-12,atol=1e-12,equal_nan=True)
  new[-h]=tail[61-h];checks[h]={'new_mature_row':str(dates[-h]),'finite':int(np.isfinite(new[-h]).sum())}
  for name,arr in [(f'labels_{h}d.npy',new),(f'label_rank_{h}d.npy',rank_features(new,buyable))]:
   target=source/name;tmp=source/(name+'.tmp.npy');np.save(tmp,arr);tmp.replace(target)
 mask=label_split_mask(dates,'2026-01-01','2026-11-10',60);assert np.flatnonzero(mask)[-1]==len(dates)-60
 atomic_write_json(source/'data_manifest.json',{p.name:file_sha256(p) for p in source.glob('*.npy')})
 atomic_write_json(root/'endpoint_1110.json',{'state':'verified','labels':checks,'endpoint':'2026-11-10 open','feature_axis_ends':'2026-11-09','boundary':'virtual endpoint included only in label maturity; no Nov10 decision features needed','quotes10':file_sha256(Path('artifacts/research/C_ytd_20261110/quotes.json'))})
 print({'stage':'Nov10_labels_verified','labels':checks},flush=True);del panel,old,new;gc.collect()
 spec=read(root/'protocol.json')['spec'];result=fit_one(root,spec);atomic_write_json(root/'training_complete.json',result)
 print({'stage':'training_complete','best':result['trees']},flush=True)
if __name__=='__main__':main()
