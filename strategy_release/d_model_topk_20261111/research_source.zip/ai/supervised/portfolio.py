"""Frozen predictions -> Qlib allocations -> the single WBR account engine."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import numpy as np

from offline_data import load_runtime_slice
from factor import FactorDefinition,FactorMetadata,precompute_factors
from env.action_schema import ActionSchema
from env.backtest import PreparedEpisode,EpisodeSession,run_target_weight_episode
from env.contracts import PortfolioExecutionSpec
from env.fees import DEFAULT_FEE_SCHEDULE
from env.forward_returns import open_forward_returns
from env.qlib_strategy import TopkDropoutConfig,TopkDropoutPortfolio,MeanVarianceConfig,MeanVariancePortfolio
from env.qlib_strategy import RankBufferConfig,RankBufferPortfolio
from .model import RankReturnCalibration
from utils.atomic_file import file_sha256
from factor_db import require_allowed_factor_names


class PreparedModelPortfolio:
    def __init__(self,root,horizon,split):
        self.root=Path(root);self.horizon=horizon;self.split=split
        protocol=json.loads((self.root/'protocol.json').read_text(encoding='utf-8'))
        self.rank_buffer_version=protocol.get('rank_buffer_version')
        model_dir=self.root/'models'/f'n{horizon}'
        require_allowed_factor_names(json.loads((model_dir/'model.json').read_text(encoding='utf-8'))['feature_names'])
        active=json.loads((self.root/'active_data.json').read_text())
        manifest_path=Path(active['manifest_path'])
        if file_sha256(manifest_path)!=active['manifest_sha256']:raise ValueError('execution manifest changed')
        manifest=json.loads(manifest_path.read_text())
        if manifest['runtime_sha256']!=active['runtime_sha256'] or Path(manifest['runtime_path']).resolve()!=Path(active['runtime_path']).resolve():raise ValueError('execution manifest/runtime identity mismatch')
        if file_sha256(active['runtime_path'])!=active['runtime_sha256']:raise ValueError('actual execution runtime changed')
        complete=json.loads((model_dir/'complete.json').read_text())
        if complete['state']!='complete' or complete['horizon']!=horizon:raise ValueError('forecast model is not complete')
        if file_sha256(model_dir/'model.txt')!=complete['model_sha256'] or file_sha256(model_dir/'predictions.npy')!=complete['predictions_sha256']:
            raise ValueError('frozen model or predictions changed')
        if file_sha256(model_dir/'model.json')!=complete['artifact_sha256']['model.json']:raise ValueError('frozen model metadata changed')
        if file_sha256(self.root/'features/data_manifest.json')!=complete['data_manifest_sha256']:raise ValueError('prediction data manifest changed')
        axes=json.loads((self.root/'features/data_manifest.json').read_text())
        for filename in ('dates.npy','codes.npy'):
            if file_sha256(self.root/'features'/filename)!=axes[filename]:raise ValueError('prediction axes changed')
        feature_identity=json.loads((self.root/'features/identity.json').read_text())
        if feature_identity['runtime']!=active['runtime_sha256']:raise ValueError('forecast and execution runtime differ')
        cache=Path(protocol.get('portfolio_runtime_cache',str(self.root/'portfolio_runtime_cache')))
        self.runtime=rt=load_runtime_slice(active['runtime_path'],*protocol[split],preload_rows=252,cache_dir=cache)
        if rt.manifest.source_sha256!=active['runtime_sha256']:raise ValueError('loaded runtime identity mismatch')
        global_dates=np.load(self.root/'features/dates.npy');global_predictions=np.load(self.root/'models'/f'n{horizon}'/'predictions.npy',mmap_mode='r')
        if global_predictions.shape!=(len(global_dates),rt.n_stocks):raise ValueError('prediction axes do not align')
        np.testing.assert_array_equal(np.load(self.root/'features/codes.npy').astype(str),np.asarray(rt.stock_codes))
        prediction=np.full((rt.n_dates,rt.n_stocks),np.nan)
        at=np.searchsorted(global_dates,rt.trade_dates);match=at<len(global_dates)
        match[match]&=global_dates[at[match]]==rt.trade_dates[match]
        prediction[match]=global_predictions[at[match]]
        self._set_predictions(rt,prediction,f'MLRank{horizon}',
            hashlib.sha256((self.root/'models'/f'n{horizon}'/'model.txt').read_bytes()).hexdigest())
        self.observed_returns=None
        self.initial_cash=protocol['initial_cash']

    @classmethod
    def from_scores(cls,runtime,prediction,*,initial_cash,source_hash,split):
        """Already verified frozen signals, through the same native evaluator."""
        if prediction.shape!=(runtime.n_dates,runtime.n_stocks):raise ValueError('score axes differ')
        self=cls.__new__(cls);self.runtime=runtime;self.root=None;self.horizon=None;self.split=split
        self.rank_buffer_version='accumulating_nav_slots_v2';self.observed_returns=None;self.initial_cash=initial_cash
        self._set_predictions(runtime,prediction,'MultiHorizonScore',source_hash)
        return self

    def _set_predictions(self,rt,prediction,name,source_hash):
        self.prediction=prediction
        class PredictionFactor:
            def calc_batch(self,panel):
                if panel['open'] is not rt.field('open'):raise ValueError('prediction score used with different market snapshot')
                return prediction
        definition=FactorDefinition(FactorMetadata(name,'frozen-open-rank-prediction-v1',0,('open',),
            source_hash),PredictionFactor,raw_runtime_view=True)
        self.factors=precompute_factors(rt,definitions=(definition,))
        self.episode=PreparedEpisode.build(rt,self.factors,encode_observations=False)

    def evaluate(self,method,parameters,*,details=False,on_transition=None):
        if method=='topk':
            cfg=TopkDropoutConfig(**parameters);limit=cfg.topk;turnover=cfg.n_drop/cfg.topk
            strategy=TopkDropoutPortfolio(self.runtime.stock_codes,cfg)
            entry_limit=limit;allow_cash=False
        elif method=='rank_buffer':
            if self.rank_buffer_version!='accumulating_nav_slots_v2':raise ValueError('rank-buffer study requires the explicit accumulating v2 protocol; old studies use their archived implementation')
            cfg=RankBufferConfig(**parameters);limit=cfg.sell_m;entry_limit=cfg.buy_n;turnover=cfg.max_replacements/cfg.buy_n;allow_cash=True
            strategy=RankBufferPortfolio(self.runtime.stock_codes,cfg)
        elif method=='mvo':
            cfg=MeanVarianceConfig(**parameters);limit=self.runtime.n_stocks;turnover=1.
            entry_limit=limit;allow_cash=False
            model_dir=self.root/'models'/f'n{self.horizon}';complete=json.loads((model_dir/'complete.json').read_text())
            if file_sha256(model_dir/'calibration.json')!=complete['calibration_sha256']:raise ValueError('frozen return calibration changed')
            saved=json.loads((model_dir/'calibration.json').read_text())
            calibration=RankReturnCalibration(tuple(saved['percentile_knots']),tuple(saved['excess_return_knots']))
            strategy=MeanVariancePortfolio(self.runtime.stock_codes,cfg,self.horizon,calibration)
            if self.observed_returns is None:self.observed_returns=open_forward_returns(self.runtime.data,1)
        else:raise ValueError(method)
        schema=ActionSchema(factor_names=self.factors.factor_names,filter_names=self.factors.filter_names,
            fixed_buy_n=entry_limit,fixed_sell_m=cfg.sell_m if method=='rank_buffer' else limit,fixed_turnover_rate=turnover,
            fixed_rebalance_band_pct=.01,schema_version='supervised-portfolio-day-v1')
        config=schema.decode(np.ones(schema.action_dim))
        session=EpisodeSession(self.episode,action_schema=schema,initial_cash=self.initial_cash,
                               fees=DEFAULT_FEE_SCHEDULE,portfolio_spec=PortfolioExecutionSpec(limit,1.,allow_cash=allow_cash))
        def targets(context):
            index=context.current_index;scores=self.prediction[index]
            if method in ('topk','rank_buffer'):return strategy.targets(context.current_market,context.current_account,index,scores)
            # r[t] ends at open[t+1]; [:index] ends at the current known open.
            return strategy.targets(context.current_market,context.current_account,index,scores,self.observed_returns[:index])
        trace=run_target_weight_episode(session,config,targets,record_details=details,on_transition=on_transition)
        self.final_account=session.current_account
        metrics=trace.metrics.as_dict()
        metrics.update(mean_exposure=float(np.mean(trace.exposure)),mean_cash=float(np.mean(trace.cash)),
                       executed_sells=int(trace.executed_sell_count),allocation_contract_satisfied=bool(trace.full_investment_contract_satisfied),
                       full_investment_required=not allow_cash)
        if not allow_cash:metrics['full_investment_contract']=bool(trace.full_investment_contract_satisfied)
        if not details:
            metrics.update(total_fees=float(trace.total_fees),mean_gross_turnover=float(trace.sum_gross_turnover_ratio/len(trace.portfolio_returns)),
                           mean_total_cost=float(trace.sum_total_cost_ratio/len(trace.portfolio_returns)))
        metrics['solver_status_counts']={name:sum(d.get('status')==name for d in strategy.diagnostics) for name in sorted({d.get('status') for d in strategy.diagnostics if d.get('status')})}
        metrics['funding_floor_days']=sum(d.get('effective_turnover',0)>d.get('configured_turnover',0)+1e-8 for d in strategy.diagnostics)
        return trace,metrics,strategy.diagnostics
