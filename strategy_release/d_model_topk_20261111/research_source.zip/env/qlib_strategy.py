"""Qlib signal strategies adapted to WBR's existing execution contracts.

Selection follows TopkDropoutStrategy; the long-only quadratic objective is
PortfolioOptimizer(method='mvo'). Copyright Microsoft Corporation, MIT;
see factor/library/QLIB_LICENSE.txt. The study pins original source separately.
Tradability, quantities, fees, fills, and settlement remain owned by WBR.
"""
from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
from scipy import sparse
from scipy.stats import rankdata
from env.planner import mark_open_positions
from env.legality import investment_universe_mask


def project_box_simplex(values,lower,upper):
    if lower.sum()>1+1e-10 or upper.sum()<1-1e-10:return None
    low=float(np.min(values-upper))-1.;high=float(np.max(values-lower))+1.
    for _ in range(70):
        middle=(low+high)/2;result=np.clip(values-middle,lower,upper)
        if result.sum()>1:low=middle
        else:high=middle
    return np.clip(values-(low+high)/2,lower,upper)


@dataclass(frozen=True)
class TopkDropoutConfig:
    topk: int = 50
    n_drop: int = 5
    hold_thresh: int = 1

    def __post_init__(self):
        if any(type(x) is not int for x in (self.topk,self.n_drop,self.hold_thresh)):
            raise TypeError('TopkDropout parameters must be integers')
        if self.topk<1 or not 0<=self.n_drop<=self.topk or self.hold_thresh<1:
            raise ValueError('invalid TopkDropout parameters')


@dataclass(frozen=True)
class RankBufferConfig:
    buy_n: int = 20
    sell_m: int = 50
    hold_thresh: int = 7
    max_replacements: int = 2

    def __post_init__(self):
        if any(type(x) is not int for x in (self.buy_n,self.sell_m,self.hold_thresh,self.max_replacements)):
            raise TypeError('rank buffer parameters must be integers')
        if self.buy_n<1 or self.sell_m<self.buy_n or self.hold_thresh<1 or not 0<=self.max_replacements<=self.buy_n:
            raise ValueError('invalid rank buffer parameters')


def select_rank_buffer(scores,held,buyable,sellable,holding_days,config):
    order=np.argsort(-np.where(np.isfinite(scores),scores,-np.inf),kind='stable')
    observable_buyable=buyable&np.isfinite(scores)
    pool=held|observable_buyable;ranked=order[pool[order]]
    retained_rank=np.zeros(len(scores),bool);retained_rank[ranked[:config.sell_m]]=True
    worst=ranked[::-1]
    exit_mask=held&~retained_rank&sellable&(holding_days>=config.hold_thresh)
    exits=worst[exit_mask[worst]][:config.max_replacements]
    retain=held.copy();retain[exits]=False
    head=order[observable_buyable[order]][:config.buy_n]
    new=head[~held[head]][:max(0,config.sell_m-int(retain.sum()))]
    return np.flatnonzero(retain),new,exits


def select_topk_dropout(scores, held, buyable, sellable, holding_days, config, order=None):
    """Return retained and entry indices, preserving Qlib's combined-pool rule.

    Directional legality is checked before replacement slots are allocated,
    so an unexecuted sale cannot create an extra holding. Stable stock-axis
    order breaks score ties; missing predictions sort last for old holdings.
    """
    scores=np.asarray(scores,dtype=np.float64);held=np.asarray(held,dtype=bool)
    order=np.argsort(-np.where(np.isfinite(scores),scores,-np.inf),kind='stable') if order is None else np.asarray(order)
    vacancies=max(0,config.topk-int(held.sum()))
    new=order[(~held[order]) & buyable[order] & np.isfinite(scores[order])][:config.n_drop+vacancies]
    combined=held.copy();combined[new]=True
    ranked=order[combined[order]]
    bottom=ranked[-config.n_drop:] if config.n_drop else np.empty(0,dtype=np.intp)
    exits=bottom[held[bottom] & sellable[bottom] & (holding_days[bottom]>=config.hold_thresh)]
    retain=held.copy();retain[exits]=False
    entries=new[:max(0,config.topk-int(retain.sum()))]
    return np.flatnonzero(retain),entries,exits


def shrunk_covariance(observed_returns, *, shrinkage=.5, horizon=1):
    """Past daily covariance scaled to forecast horizon, with diagonal shrinkage.

    N times daily covariance assumes zero serial covariance; it is a declared
    risk approximation, not a prediction-label transformation. Missing returns
    are mean-neutral for covariance only, and counts are returned for gating.
    """
    x=np.asarray(observed_returns,dtype=np.float64)
    if x.ndim!=2 or len(x)<2 or not 0<=shrinkage<=1 or horizon<1:
        raise ValueError('invalid historical risk window')
    finite=np.isfinite(x);counts=finite.sum(axis=0)
    means=np.divide(np.where(finite,x,0.).sum(axis=0),counts,out=np.zeros(x.shape[1]),where=counts>0)
    residual=np.where(finite,x-means,0.)
    # Per-column effective-sample normalization retains a PSD Gram matrix.
    norm=np.sqrt(np.maximum(counts-1,1))
    residual=residual/norm
    covariance=residual.T@residual
    diagonal=np.diag(covariance).copy()
    known=diagonal[(counts>=2)&(diagonal>1e-12)]
    floor=float(np.median(known)) if len(known) else .0004
    diagonal=np.where((counts>=2)&(diagonal>1e-12),diagonal,floor)
    covariance=(1-shrinkage)*covariance+shrinkage*np.diag(diagonal)
    covariance+=np.diag(np.maximum(0.,1e-10-np.diag(covariance)))
    return covariance*float(horizon),counts


def solve_mean_variance(expected, covariance, current, *, risk_aversion=10.,
                        turnover_limit=.2, ridge=0., lower=None, upper=None):
    """Solve Qlib's MVO objective with explicit bounds and an exact L1 budget.

    Clarabel solves the same convex objective with auxiliary absolute-change
    variables. Failed/infeasible solutions are reported, never silently retried
    with relaxed turnover. Initial all-cash construction is handled by caller.
    """
    import clarabel
    r=np.asarray(expected,dtype=np.float64);s=np.asarray(covariance,dtype=np.float64)
    w0=np.asarray(current,dtype=np.float64);n=len(r)
    lo=np.zeros(n) if lower is None else np.asarray(lower,dtype=np.float64)
    hi=np.ones(n) if upper is None else np.asarray(upper,dtype=np.float64)
    if n==0 or s.shape!=(n,n) or any(x.shape!=(n,) for x in (w0,lo,hi)):
        raise ValueError('unaligned portfolio inputs')
    if not all(np.isfinite(x).all() for x in (r,s,w0,lo,hi)):
        raise ValueError('portfolio inputs must be finite')
    if any(not math.isfinite(x) or x<0 for x in (risk_aversion,turnover_limit,ridge)):
        raise ValueError('invalid optimizer parameter')
    if np.any(lo<0) or np.any(hi>1) or np.any(lo>hi) or np.any(w0<0) or w0.sum()>1+1e-8:
        raise ValueError('invalid portfolio bounds or current weights')
    s=(s+s.T)/2
    if np.linalg.eigvalsh(s)[0] < -1e-9:
        raise ValueError('risk covariance must be positive semidefinite')
    q=np.r_[-r,np.zeros(n)]
    p=sparse.block_diag((2*(risk_aversion*s+ridge*np.eye(n)),sparse.csc_matrix((n,n))),format='csc')
    eye=sparse.eye(n,format='csc');zero=sparse.csc_matrix((n,n))
    a=sparse.vstack([
        sparse.csc_matrix(np.r_[np.ones(n),np.zeros(n)][None,:]),
        sparse.hstack((eye,zero)),
        sparse.hstack((eye,-eye)),
        sparse.hstack((-eye,-eye)),
        sparse.csc_matrix(np.r_[np.zeros(n),np.ones(n)][None,:]),
        sparse.hstack((zero,eye)),
    ],format='csc')
    l=np.r_[1.,lo,np.full(2*n,-np.inf),-np.inf,np.zeros(n)]
    u=np.r_[1.,hi,w0,-w0,turnover_limit,np.full(n,np.inf)]
    # Convert the same two-sided linear bounds into Ax+s=b cones. The first
    # row is the full-investment equality; all other finite bounds are <=.
    upper_rows=np.flatnonzero(np.isfinite(u[1:]))+1
    lower_rows=np.flatnonzero(np.isfinite(l[1:]))+1
    conic_a=sparse.vstack((a[:1],a[upper_rows],-a[lower_rows]),format='csc')
    conic_b=np.r_[u[:1],u[upper_rows],-l[lower_rows]]
    settings=clarabel.DefaultSettings();settings.verbose=False;settings.max_iter=200
    settings.tol_gap_abs=1e-9;settings.tol_gap_rel=1e-9;settings.tol_feas=1e-9
    settings.max_threads=1;settings.direct_solve_method='qdldl'
    solver=clarabel.DefaultSolver(sparse.triu(p,format='csc'),q,conic_a,conic_b,
        [clarabel.ZeroConeT(1),clarabel.NonnegativeConeT(len(conic_b)-1)],settings)
    result=solver.solve()
    diagnostics={'status':str(result.status),'iterations':int(result.iterations),
                 'turnover_limit':float(turnover_limit),'solver':'clarabel',
                 'primal_residual':float(result.r_prim),'dual_residual':float(result.r_dual)}
    if str(result.status) not in ('Solved','AlmostSolved') or result.x is None:
        return None,diagnostics
    weights=np.asarray(result.x[:n],dtype=np.float64)
    # Do not clip/renormalize a portfolio into violating another constraint.
    violations=max(abs(weights.sum()-1),float(np.max(lo-weights)),float(np.max(weights-hi)),
                   float(np.abs(weights-w0).sum()-turnover_limit))
    diagnostics['max_constraint_violation']=float(violations)
    diagnostics['objective']=float(-weights@r+risk_aversion*(weights@s@weights)+ridge*(weights@weights))
    if violations>2e-6:
        diagnostics['status']='rejected_constraint_residual'
        return None,diagnostics
    # An interior-point zero is usually a tiny positive value. Keeping it as a
    # target would make native lot rounding leave one lot instead of a full
    # exit. Canonicalize only active zero lower bounds within the existing
    # final tolerance, and only when the same turnover/bounds remain feasible.
    dual_lower=np.asarray(result.z[1+len(upper_rows):1+len(upper_rows)+n])
    snap=(lo==0)&(weights<=1e-8)&(dual_lower>1e-8)
    polish_hi=hi.copy();polish_hi[snap]=0.
    anchor=project_box_simplex(w0,lo,polish_hi)
    if anchor is None or np.abs(anchor-w0).sum()>turnover_limit+1e-10:
        polish_hi=hi;snap[:]=False
    diagnostics['snapped_zero_weights']=int(snap.sum())
    weights=project_box_simplex(weights,lo,polish_hi)
    if weights is None:return None,{**diagnostics,'status':'infeasible_projection'}
    amount=np.abs(weights-w0).sum()
    if amount>turnover_limit+1e-10:
        anchor=project_box_simplex(w0,lo,polish_hi)
        anchor_amount=np.abs(anchor-w0).sum() if anchor is not None else np.inf
        if anchor_amount>turnover_limit+1e-10:return None,{**diagnostics,'status':'no_feasible_roundoff_anchor'}
        fraction=max(0.,min(1.,(turnover_limit-anchor_amount)/max(amount-anchor_amount,1e-15)))
        weights=anchor+fraction*(weights-anchor)
    if abs(weights.sum()-1)>1e-8 or np.abs(weights-w0).sum()>turnover_limit+1e-8 or np.any(weights<lo-1e-8) or np.any(weights>hi+1e-8):
        return None,{**diagnostics,'status':'rejected_postround_residual'}
    diagnostics['polished_objective']=float(-weights@r+risk_aversion*(weights@s@weights)+ridge*(weights@weights))
    return weights,diagnostics


class _PortfolioState:
    def __init__(self,codes):
        self.codes=tuple(codes);self.lookup={c:i for i,c in enumerate(codes)};self.born={};self.last_day=None
        self.diagnostics=[]

    def context(self,market,account,day,scores):
        if self.last_day is not None and day<=self.last_day:self.born={};self.diagnostics=[]
        self.last_day=day
        held=np.zeros(len(self.codes),bool);sellable=np.zeros(len(self.codes),bool);ages=np.zeros(len(self.codes),int)
        legal=market.trade_legality(True)
        prices,marks,_,values,equity=mark_open_positions(market,account,self.lookup)
        weights=np.zeros(len(self.codes));locked=np.zeros(len(self.codes))
        self.born={code:value for code,value in self.born.items() if code in values}
        for code,value in values.items():
            i=self.lookup[code];held[i]=True;weights[i]=value/equity
            self.born.setdefault(code,day-1);ages[i]=day-self.born[code]
            quantity=account.positions[code];available=min(quantity,account.sellable_positions.get(code,0))
            sellable[i]=bool(legal.sell_allowed[i] and available>=quantity)
            locked[i]=(quantity-available)*marks[code]/equity if legal.sell_allowed[i] else weights[i]
        eligible=investment_universe_mask(market.open_prices,market.listing_age,market.st_mask,market.delisted_mask)&np.isfinite(scores)
        buyable=eligible&legal.buy_allowed
        return held,sellable,ages,weights,locked,buyable,equity

    def selected_targets(self,day,keep,new,exits,current,buyable):
        weights=np.zeros(len(self.codes));weights[keep]=current[keep]
        cash=max(0.,1-weights.sum())
        if len(new):weights[new]=cash/len(new)
        else:
            able=keep[buyable[keep]]
            if len(able):weights[able]+=cash/len(able)
            elif len(keep):weights[keep]/=weights[keep].sum()
            else:raise ValueError('no observable legal stock for initial allocation')
        self.diagnostics.append({'day':int(day),'entries':int(len(new)),'exits':int(len(exits)),'cash_sweep':bool(not len(new) and cash>1e-8)})
        return {self.codes[i]:float(w) for i,w in enumerate(weights) if w>0}


class TopkDropoutPortfolio(_PortfolioState):
    """Qlib selection plus the local full-investment cash-sweep convention."""
    def __init__(self,codes,config):super().__init__(codes);self.config=config

    def targets(self,market,account,day,scores):
        if not np.isfinite(scores).any():raise ValueError('no observable model prediction at this decision date')
        held,sellable,ages,current,locked,buyable,equity=self.context(market,account,day,scores)
        keep,new,exits=select_topk_dropout(scores,held,buyable,sellable,ages,self.config)
        return self.selected_targets(day,keep,new,exits,current,buyable)


class RankBufferPortfolio(_PortfolioState):
    def __init__(self,codes,config):super().__init__(codes);self.config=config

    def targets(self,market,account,day,scores):
        if not np.isfinite(scores).any():raise ValueError('no observable model prediction at this decision date')
        held,sellable,ages,current,locked,buyable,equity=self.context(market,account,day,scores)
        keep,new,exits=select_rank_buffer(scores,held,buyable,sellable,ages,self.config)
        weights=np.zeros(len(self.codes));weights[keep]=current[keep]
        available=max(0.,1-float(weights.sum()))
        # Entry ranking and total capacity are distinct: retain buffered names
        # while adding new top-buy_n names, one NAV/sell_m budget per new name.
        admitted=[]
        for index in new:
            budget=min(1./self.config.sell_m,available)
            if budget<=1e-12:break
            weights[index]=budget;available-=budget;admitted.append(index)
        self.diagnostics.append({'day':int(day),'entries':len(admitted),'exits':len(exits),
            'target_positions':int(np.count_nonzero(weights)),'target_cash_weight':max(0.,1-float(weights.sum())),
            'entry_weight':1./self.config.sell_m,'max_replacements':self.config.max_replacements,'cash_sweep':False})
        return {self.codes[i]:float(weights[i]) for i in np.flatnonzero(weights>0)}


@dataclass(frozen=True)
class MeanVarianceConfig:
    pool_size:int=50
    risk_aversion:float=10.
    turnover_limit:float=.1
    ridge:float=.001
    lookback:int=120
    shrinkage:float=.5


class MeanVariancePortfolio(_PortfolioState):
    """Ordinary Qlib MVO: 0..1 weights, no benchmark tracking or shorting.

    Candidate pool is top forecast buyable names plus every existing holding.
    Turnover has an explicit net-cash funding floor (also used for first entry),
    not an infeasibility retry. Unavailable sales/buys are frozen in bounds.
    """
    def __init__(self,codes,config,horizon,calibration):
        super().__init__(codes);self.config=config;self.horizon=horizon;self.calibration=calibration

    def targets(self,market,account,day,scores,observed_daily_returns):
        if not np.isfinite(scores).any():raise ValueError('no observable model prediction at this decision date')
        held,sellable,ages,current,locked,buyable,equity=self.context(market,account,day,scores)
        ranks=np.full(len(scores),np.nan);good=np.isfinite(scores)&(market.listing_age>=0)&~market.delisted_mask&~market.st_mask&(market.open_prices>=2)
        if good.any():ranks[good]=(rankdata(scores[good],method='average')-.5)/good.sum()
        order=np.argsort(-np.where(np.isfinite(scores),scores,-np.inf),kind='stable')
        candidates=order[buyable[order]][:self.config.pool_size]
        indices=np.unique(np.r_[np.flatnonzero(held),candidates])
        if len(indices)==0:raise ValueError('no observable legal stock for initial MVO allocation')
        r=self.calibration.predict(np.nan_to_num(ranks[indices],nan=0.))
        fast_diagonal=self.config.shrinkage==1.
        factorized=not fast_diagonal and len(indices)>=256
        if fast_diagonal:
            from .diagonal_mvo import diagonal_variance
            variance,counts=diagonal_variance(observed_daily_returns[-self.config.lookback:,indices],horizon=self.horizon)
        elif factorized:
            from .factorized_mvo import risk_components
            risk_factor,risk_diagonal,counts=risk_components(observed_daily_returns[-self.config.lookback:,indices],
                shrinkage=self.config.shrinkage,horizon=self.horizon)
        else:
            covariance,counts=shrunk_covariance(observed_daily_returns[-self.config.lookback:,indices],shrinkage=self.config.shrinkage,horizon=self.horizon)
        w0=current[indices];lower=locked[indices]
        upper=np.where(buyable[indices],1.,w0)
        funding=max(0.,1-float(w0.sum()));limit=max(self.config.turnover_limit,funding)
        if upper.sum()<1-1e-8:
            # Every available slot is locked/unbuyable. These aspirational
            # targets cause no order; the shared executor reports residual cash.
            if not w0.sum():raise ValueError('MVO has no legal investment capacity')
            weights=w0/w0.sum();diagnostic={'status':'hold_unbuyable_cash','iterations':0}
        else:
            if fast_diagonal:
                from .diagonal_mvo import solve_diagonal
                weights,diagnostic=solve_diagonal(r,variance,w0,risk_aversion=self.config.risk_aversion,
                    turnover_limit=limit,ridge=self.config.ridge,lower=lower,upper=upper)
                if weights is None:
                    analytic_status=diagnostic['status']
                    weights,diagnostic=solve_mean_variance(r,np.diag(variance),w0,risk_aversion=self.config.risk_aversion,
                        turnover_limit=limit,ridge=self.config.ridge,lower=lower,upper=upper)
                    diagnostic['diagonal_attempt_status']=analytic_status
            elif factorized:
                from .factorized_mvo import solve_factor
                weights,diagnostic=solve_factor(r,risk_factor,risk_diagonal,w0,risk_aversion=self.config.risk_aversion,
                    turnover_limit=limit,ridge=self.config.ridge,lower=lower,upper=upper)
            else:
                weights,diagnostic=solve_mean_variance(r,covariance,w0,risk_aversion=self.config.risk_aversion,
                     turnover_limit=limit,ridge=self.config.ridge,lower=lower,upper=upper)
            if weights is None:raise RuntimeError('MVO solve failed without constraint relaxation: '+str(diagnostic))
        self.diagnostics.append({'day':int(day),'configured_turnover':self.config.turnover_limit,'effective_turnover':limit,
            'cash_funding_floor':funding,'candidates':len(indices),**diagnostic})
        return {self.codes[i]:float(w) for i,w in zip(indices,weights) if w>0}
