"""Exact separable convex QP candidate; staged outside running source files."""
from __future__ import annotations
import numpy as np
from numba import njit


@njit(cache=True,fastmath=False)
def _at_duals(a,r,current,lower,upper,nu,tau,weights):
    total=0.;slope=0.;signed_slope=0.
    for i in range(len(a)):
        value=r[i]-nu;center=2*a[i]*current[i];sign=0.
        if value>center+tau:raw=(value-tau)/(2*a[i]);sign=1.
        elif value<center-tau:raw=(value+tau)/(2*a[i]);sign=-1.
        else:raw=current[i]
        weight=min(upper[i],max(lower[i],raw));weights[i]=weight;total+=weight
        if sign!=0 and lower[i]<raw<upper[i]:
            inverse=1/(2*a[i]);slope+=inverse;signed_slope+=sign*inverse
    return total,slope,signed_slope


@njit(cache=True,fastmath=False)
def _simplex_at_tau(a,r,current,lower,upper,tau):
    left=np.min(r-tau-2*a*upper)-1.;right=np.max(r+tau-2*a*lower)+1.
    nu=.5*(left+right);weights=np.empty(len(a));best=np.empty(len(a));best_error=np.inf
    best_nu=nu;best_slope=0.;best_signed=0.
    for iteration in range(120):
        total,slope,signed=_at_duals(a,r,current,lower,upper,nu,tau,weights)
        error=total-1.
        if abs(error)<best_error:
            best_error=abs(error);best[:]=weights;best_nu=nu;best_slope=slope;best_signed=signed
        if abs(error)<=1e-12:return weights,nu,slope,signed,iteration+1,True
        if error>0:left=nu
        else:right=nu
        candidate=nu+error/slope if slope>0 else .5*(left+right)
        if not np.isfinite(candidate) or candidate<=left or candidate>=right:candidate=.5*(left+right)
        if candidate==nu:break
        nu=candidate
    return best,best_nu,best_slope,best_signed,120,best_error<=1e-10


@njit(cache=True,fastmath=False)
def _diagonal_duals(a,r,current,lower,upper,limit):
    weights,nu,slope,signed,iterations,okay=_simplex_at_tau(a,r,current,lower,upper,0.)
    if not okay:return weights,nu,0.,iterations,False
    amount=np.abs(weights-current).sum()
    if amount<=limit+1e-10:return weights,nu,0.,iterations,True
    lo_tau=0.;hi_tau=2*np.max(a)+np.max(np.abs(r))+1.
    best=weights.copy();best_nu=nu;best_tau=hi_tau;found=False
    for _ in range(30):
        candidate,cnu,cslope,csigned,used,okay=_simplex_at_tau(a,r,current,lower,upper,hi_tau)
        iterations+=used
        if not okay:return weights,nu,hi_tau,iterations,False
        if np.abs(candidate-current).sum()<=limit+1e-10:
            best=candidate;best_nu=cnu;best_tau=hi_tau;found=True;break
        hi_tau*=2
    if not found:return weights,nu,hi_tau,iterations,False
    tau=.5*(lo_tau+hi_tau)
    for _ in range(100):
        candidate,cnu,cslope,csigned,used,okay=_simplex_at_tau(a,r,current,lower,upper,tau)
        iterations+=used
        if not okay:return best,best_nu,best_tau,iterations,False
        amount=np.abs(candidate-current).sum();error=amount-limit
        if amount<=limit+1e-10:best=candidate;best_nu=cnu;best_tau=tau
        if abs(error)<=1e-10:return candidate,cnu,tau,iterations,True
        if error>0:lo_tau=tau
        else:hi_tau=tau
        decrease=max(0.,cslope-csigned*csigned/cslope) if cslope>0 else 0.
        proposal=tau+error/decrease if decrease>1e-18 else .5*(lo_tau+hi_tau)
        if not np.isfinite(proposal) or proposal<=lo_tau or proposal>=hi_tau:proposal=.5*(lo_tau+hi_tau)
        if proposal==tau:break
        tau=proposal
    return best,best_nu,best_tau,iterations,abs(np.abs(best-current).sum()-limit)<=1e-8


def diagonal_variance(observed_returns,*,horizon=1):
    """The shrinkage=1 diagonal, without computing unused off-diagonal entries."""
    x=np.asarray(observed_returns,dtype=np.float64)
    if x.ndim!=2 or len(x)<2 or horizon<1:raise ValueError('invalid historical risk window')
    finite=np.isfinite(x);counts=finite.sum(axis=0)
    means=np.divide(np.where(finite,x,0.).sum(axis=0),counts,out=np.zeros(x.shape[1]),where=counts>0)
    residual=np.where(finite,x-means,0.)/np.sqrt(np.maximum(counts-1,1))
    diagonal=np.einsum('ij,ij->j',residual,residual)
    known=diagonal[(counts>=2)&(diagonal>1e-12)]
    floor=float(np.median(known)) if len(known) else .0004
    diagonal=np.where((counts>=2)&(diagonal>1e-12),diagonal,floor)
    return np.maximum(diagonal,1e-10)*float(horizon),counts


def solve_diagonal(expected,variance,current,*,risk_aversion,turnover_limit,ridge,lower,upper):
    """Same box/simplex/L1 objective, solved through its two KKT multipliers.

    For fixed simplex multiplier nu and turnover multiplier tau, each coordinate
    is a clipped soft-threshold quadratic minimizer. Safeguarded Newton steps
    solve the monotone sum and turnover equations. Failed numerical checks are
    returned explicitly; the caller may solve the same QP with Clarabel.
    """
    r=np.asarray(expected,dtype=np.float64);v=np.asarray(variance,dtype=np.float64)
    w0=np.asarray(current,dtype=np.float64);lo=np.asarray(lower,dtype=np.float64);hi=np.asarray(upper,dtype=np.float64)
    n=len(r)
    if n==0 or any(x.shape!=(n,) for x in (v,w0,lo,hi)):raise ValueError('unaligned diagonal portfolio inputs')
    if not all(np.isfinite(x).all() for x in (r,v,w0,lo,hi)):raise ValueError('diagonal inputs must be finite')
    if np.any(v<0) or np.any(lo<0) or np.any(hi>1) or np.any(lo>hi) or np.any(w0<0) or w0.sum()>1+1e-8:
        raise ValueError('invalid diagonal bounds or variance')
    if not all(np.isfinite(x) and x>=0 for x in (risk_aversion,turnover_limit,ridge)):raise ValueError('invalid diagonal optimizer parameter')
    a=risk_aversion*v+ridge
    if not np.isfinite(a).all() or np.any(a<=0):return None,{'status':'non_strict_diagonal_objective','solver':'diagonal_kkt'}
    if lo.sum()>1+1e-10 or hi.sum()<1-1e-10:return None,{'status':'infeasible_bounds','solver':'diagonal_kkt'}
    clipped=np.clip(w0,lo,hi);minimum_turnover=np.abs(clipped-w0).sum()+abs(1-clipped.sum())
    if minimum_turnover>turnover_limit+1e-10:return None,{'status':'infeasible_turnover','solver':'diagonal_kkt'}
    weights,nu,tau,iterations,okay=_diagonal_duals(a,r,w0,lo,hi,turnover_limit)
    amount=float(np.abs(weights-w0).sum())
    violation=max(abs(weights.sum()-1),float(np.max(lo-weights)),float(np.max(weights-hi)),amount-turnover_limit)
    objective=float(np.sum(a*weights*weights-r*weights))
    dual_gap=abs(float(nu*(weights.sum()-1)+tau*(amount-turnover_limit)))
    diagnostic={'status':'DiagonalSolved' if okay else 'diagonal_iterations_or_precision','solver':'diagonal_kkt',
        'iterations':int(iterations),'turnover_limit':float(turnover_limit),'nu':float(nu),'tau':float(tau),
        'max_constraint_violation':float(violation),'objective':objective,'dual_gap':dual_gap}
    if not okay or violation>1e-8 or dual_gap>1e-8*(1+abs(objective)):
        diagnostic['status']='diagonal_rejected_numeric_certificate';return None,diagnostic
    return weights,diagnostic
