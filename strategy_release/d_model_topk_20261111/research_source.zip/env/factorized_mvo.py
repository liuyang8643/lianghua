"""Equivalent low-rank-plus-diagonal MVO formulation; no dense asset Gram matrix."""
import numpy as np
from scipy import sparse
from env.qlib_strategy import project_box_simplex


def risk_components(observed_returns,*,shrinkage,horizon):
    x=np.asarray(observed_returns,dtype=np.float64)
    if x.ndim!=2 or len(x)<2 or not 0<=shrinkage<=1 or horizon<1:raise ValueError('invalid risk window')
    finite=np.isfinite(x);counts=finite.sum(axis=0)
    mean=np.divide(np.where(finite,x,0.).sum(axis=0),counts,out=np.zeros(x.shape[1]),where=counts>0)
    z=np.where(finite,x-mean,0.)/np.sqrt(np.maximum(counts-1,1))
    raw=np.einsum('ij,ij->j',z,z);known=raw[(counts>=2)&(raw>1e-12)]
    floor=float(np.median(known)) if len(known) else .0004
    adjusted=np.where((counts>=2)&(raw>1e-12),raw,floor)
    extra=np.maximum(0.,1e-10-((1-shrinkage)*raw+shrinkage*adjusted))
    return np.sqrt(float(horizon)*(1-shrinkage))*z,float(horizon)*(shrinkage*adjusted+extra),counts


def solve_factor_interior(expected,factor,diagonal,current,*,risk_aversion,turnover_limit,ridge,lower,upper):
    import clarabel
    r=np.asarray(expected,dtype=np.float64);f=np.asarray(factor,dtype=np.float64);d=np.asarray(diagonal,dtype=np.float64)
    w0=np.asarray(current,dtype=np.float64);lo=np.asarray(lower,dtype=np.float64);hi=np.asarray(upper,dtype=np.float64)
    n=len(r);k=len(f)
    if n==0 or f.shape!=(k,n) or any(a.shape!=(n,) for a in (d,w0,lo,hi)):raise ValueError('unaligned factor QP inputs')
    if not all(np.isfinite(a).all() for a in (r,f,d,w0,lo,hi)) or np.any(d<0):raise ValueError('invalid factor risk inputs')
    if np.any(lo<0) or np.any(hi>1) or np.any(lo>hi) or np.any(w0<0) or w0.sum()>1+1e-8:raise ValueError('invalid factor bounds')
    if not all(np.isfinite(a) and a>=0 for a in (risk_aversion,turnover_limit,ridge)):raise ValueError('invalid factor QP parameters')
    # u=F*w gives w'(F'F+diag(d))w without forming an n by n Gram matrix.
    p=sparse.diags(np.r_[2*(risk_aversion*d+ridge),np.zeros(n),np.full(k,2*risk_aversion)],format='csc')
    p.eliminate_zeros();q=np.r_[-r,np.zeros(n+k)]
    eye=sparse.eye(n,format='csc');zero=sparse.csc_matrix((n,n));zk=sparse.csc_matrix((n,k))
    equality=sparse.vstack((sparse.csc_matrix(np.r_[np.ones(n),np.zeros(n+k)][None,:]),
        sparse.hstack((sparse.csc_matrix(f),sparse.csc_matrix((k,n)),-sparse.eye(k,format='csc')))),format='csc')
    inequality=sparse.vstack((sparse.hstack((-eye,zero,zk)),sparse.hstack((eye,zero,zk)),
        sparse.hstack((eye,-eye,zk)),sparse.hstack((-eye,-eye,zk)),
        sparse.csc_matrix(np.r_[np.zeros(n),np.ones(n),np.zeros(k)][None,:]),sparse.hstack((zero,-eye,zk))),format='csc')
    a=sparse.vstack((equality,inequality),format='csc')
    b=np.r_[1.,np.zeros(k),-lo,hi,w0,-w0,turnover_limit,np.zeros(n)]
    settings=clarabel.DefaultSettings();settings.verbose=False;settings.max_iter=200
    settings.max_threads=1;settings.direct_solve_method='qdldl';settings.tol_gap_abs=1e-9;settings.tol_gap_rel=1e-9;settings.tol_feas=1e-9
    result=clarabel.DefaultSolver(p,q,a,b,[clarabel.ZeroConeT(k+1),clarabel.NonnegativeConeT(5*n+1)],settings).solve()
    diagnostic={'status':str(result.status),'solver':'factor_clarabel','iterations':int(result.iterations),
        'turnover_limit':float(turnover_limit),'primal_residual':float(result.r_prim),'dual_residual':float(result.r_dual)}
    if str(result.status) not in ('Solved','AlmostSolved'):return None,diagnostic
    weights=np.asarray(result.x[:n])
    violation=max(abs(weights.sum()-1),float(np.max(lo-weights)),float(np.max(weights-hi)),float(np.abs(weights-w0).sum()-turnover_limit))
    diagnostic['max_constraint_violation']=float(violation)
    if violation>2e-6:return None,{**diagnostic,'status':'rejected_constraint_residual'}
    lower_dual=np.asarray(result.z[k+1:k+1+n]);snap=(lo==0)&(weights<=1e-8)&(lower_dual>1e-8)
    polish_hi=hi.copy();polish_hi[snap]=0.;anchor=project_box_simplex(w0,lo,polish_hi)
    if anchor is None or np.abs(anchor-w0).sum()>turnover_limit+1e-10:polish_hi=hi;snap[:]=False
    weights=project_box_simplex(weights,lo,polish_hi)
    if weights is None:return None,{**diagnostic,'status':'infeasible_projection'}
    amount=np.abs(weights-w0).sum()
    if amount>turnover_limit+1e-10:
        anchor=project_box_simplex(w0,lo,polish_hi)
        anchor_amount=np.abs(anchor-w0).sum() if anchor is not None else np.inf
        if anchor_amount>turnover_limit+1e-10:return None,{**diagnostic,'status':'no_feasible_roundoff_anchor'}
        fraction=max(0.,min(1.,(turnover_limit-anchor_amount)/max(amount-anchor_amount,1e-15)))
        weights=anchor+fraction*(weights-anchor)
    if abs(weights.sum()-1)>1e-8 or np.abs(weights-w0).sum()>turnover_limit+1e-8 or np.any(weights<lo-1e-8) or np.any(weights>hi+1e-8):
        return None,{**diagnostic,'status':'rejected_postround_residual'}
    fw=f@weights
    diagnostic.update(snapped_zero_weights=int(snap.sum()),objective=float(-weights@r+risk_aversion*(fw@fw+np.sum(d*weights*weights))+ridge*(weights@weights)))
    return weights,diagnostic


def solve_factor_projected(expected,factor,diagonal,current,*,risk_aversion,turnover_limit,ridge,lower,upper):
    """Certified projected gradient for strongly diagonal-dominant objectives.

    A global Lipschitz bound and strong-convexity lower bound select this
    numerical method. Every projection solves the same box/simplex/L1 set.
    The stopping certificate is a Lagrangian lower bound, not iterate change.
    """
    from env.diagonal_mvo import solve_diagonal
    r=np.asarray(expected,dtype=np.float64);f=np.asarray(factor,dtype=np.float64);d=np.asarray(diagonal,dtype=np.float64)
    w0=np.asarray(current,dtype=np.float64);lo=np.asarray(lower,dtype=np.float64);hi=np.asarray(upper,dtype=np.float64)
    a=risk_aversion*d+ridge;minimum=float(np.min(a))
    condition=1+risk_aversion*float(np.sum((f*f)/a[None,:]))
    if minimum<=0 or not np.isfinite(condition) or condition>20:
        return None,{'status':'use_interior_for_conditioning'}
    x=project_box_simplex(w0,lo,hi)
    if x is None or np.abs(x-w0).sum()>turnover_limit+1e-8:return None,{'status':'projection_initial_infeasible'}
    for iteration in range(200):
        fx=f@x;gradient=2*(a*x+risk_aversion*(f.T@fx))-r
        proposal=x-gradient/(2*condition*a)
        w,p=solve_diagonal(2*a*proposal,a,w0,risk_aversion=1.,turnover_limit=turnover_limit,ridge=0.,lower=lo,upper=hi)
        if w is None:return None,{'status':'projection_numeric_failure'}
        fw=f@w;g=2*(a*w+risk_aversion*(f.T@fw))-r
        nu=condition*p['nu'];tau=condition*p['tau']
        residual=g+nu
        up=w>w0;down=w<w0;equal=~(up|down)
        residual[up]+=tau;residual[down]-=tau
        residual[equal]=np.sign(residual[equal])*np.maximum(np.abs(residual[equal])-tau,0.)
        residual[(w==lo)&(residual>0)]=0.;residual[(w==hi)&(residual<0)]=0.
        amount=float(np.abs(w-w0).sum());objective=float(np.sum(a*w*w-r*w)+risk_aversion*(fw@fw))
        certificate=float(np.sum(residual*residual/a)/4+abs(nu*(w.sum()-1))+abs(tau*(amount-turnover_limit)))
        violation=max(abs(w.sum()-1),float(np.max(lo-w)),float(np.max(w-hi)),amount-turnover_limit)
        if certificate<=1e-9*(1+abs(objective)) and violation<=1e-8:
            return w,{'status':'ProjectedGradientSolved','solver':'factor_projected_gradient','iterations':iteration+1,
                'turnover_limit':float(turnover_limit),'objective':objective,'optimality_gap_bound':certificate,
                'max_constraint_violation':float(violation),'condition_bound':condition}
        x=w
    return None,{'status':'use_interior_after_iteration_budget'}


def solve_factor(expected,factor,diagonal,current,**kwargs):
    r=np.asarray(expected,dtype=np.float64);f=np.asarray(factor,dtype=np.float64);d=np.asarray(diagonal,dtype=np.float64)
    w=np.asarray(current,dtype=np.float64);lo=np.asarray(kwargs['lower'],dtype=np.float64);hi=np.asarray(kwargs['upper'],dtype=np.float64)
    if r.ndim!=1 or len(r)==0 or f.ndim!=2 or f.shape[1]!=len(r) or any(v.shape!=r.shape for v in (d,w,lo,hi)):
        raise ValueError('unaligned factor QP inputs')
    if not all(np.isfinite(v).all() for v in (r,f,d,w,lo,hi)) or np.any(d<0):raise ValueError('invalid factor QP values')
    if np.any(lo<0) or np.any(hi>1) or np.any(lo>hi) or np.any(w<0) or w.sum()>1+1e-8:raise ValueError('invalid factor QP bounds')
    if not all(np.isfinite(kwargs[name]) and kwargs[name]>=0 for name in ('risk_aversion','turnover_limit','ridge')):raise ValueError('invalid factor QP parameters')
    weights,diagnostic=solve_factor_projected(expected,factor,diagonal,current,**kwargs)
    if weights is not None:return weights,diagnostic
    weights,result=solve_factor_interior(expected,factor,diagonal,current,**kwargs)
    result['projected_attempt_status']=diagnostic['status']
    return weights,result
