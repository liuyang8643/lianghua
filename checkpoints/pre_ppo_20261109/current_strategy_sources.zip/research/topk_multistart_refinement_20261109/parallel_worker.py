"""Reuse the parity-verified worker loader and unchanged path cache evaluator."""
from research.topk_multistart_parallel_20261109 import worker as base
from .cache import Evaluator
from research.topk_multistart_20261109.selection import key

CACHE=None

def initialize(output,identity):
    global CACHE
    base.initialize(output)
    c,starts,rt,cube,_,_=base.STATE
    c=dict(c);c['output']=output
    CACHE=Evaluator(rt,cube,c,starts,identity)

def evaluate(task):
    parameters,stage=task
    record=CACHE.evaluate(parameters,stage)
    assert record['parameters']==parameters
    return {'key':key(parameters),'record':record}
