"""Replay stage48 mutation/selection/RNG from saved outcomes, no financial runs."""
import json,random,time
from pathlib import Path
from .driver import neighbours,elite
from .cache import read_trial,digest
from research.topk_multistart_20261109.selection import key,select
from utils.atomic_file import atomic_write_json,file_sha256

def main():
    began=time.monotonic();here=Path(__file__).parent;ext=json.loads((here/'protocol.json').read_text());c=json.loads(Path(ext['parent_protocol']).read_text());root=Path(c['output']);stage=root/'stage48'
    done=json.loads((stage/'complete.json').read_text());previous=json.loads((root/'stage12/complete.json').read_text());inputs={};records={}
    def load(p):
        path=stage/'trials'/f'{digest(p)}.json';inputs[str(path)]=file_sha256(path);r=read_trial(path);assert r['parameters']==p;return r
    for p in previous['shortlist']:records[key(p)]=load(p)
    ga=ext['stage48'];rng=random.Random(ga['seed']);stale=0;anchor=None
    for g in range(1,done['generations']+1):
        population=elite(records,ga['population']);available={}
        for p in population:
            for q in neighbours(p,c['space']):
                if key(q) not in records:available[key(q)]=q
        candidates=list(available.values());rng.shuffle(candidates);assert candidates
        proposed=candidates[:ga['new_candidates_per_generation']]
        for p in proposed:records[key(p)]=load(p)
        winner=select(list(records.values()));score=[max(r['summary']['typical'] for r in records.values()),winner['summary']['tail']]
        improved=anchor is None or score[0]>anchor[0]+ga['min_improvement'] or (score[0]>=anchor[0]-1e-12 and score[1]>anchor[1]+ga['min_improvement'])
        if improved:anchor=score;stale=0
        else:stale+=1
        expected={'winner':winner,'stale':stale,'trials':len(records),'population':population,'proposed':proposed,'record_order':list(records),'rng':rng.getstate()}
        path=stage/f'generation_{g:03d}.json';inputs[str(path)]=file_sha256(path)
        assert json.loads(path.read_text())==json.loads(json.dumps(expected)),f'stage48 generation{g} differs'
    assert len(records)==done['trials']==len(list((stage/'trials').glob('*.json')))
    if done['stop_reason']=='patience':assert stale>=ga['patience']
    else:
        assert done['stop_reason']=='neighbour_exhaustion'
        assert not any(key(q) not in records for p in elite(records,ga['population']) for q in neighbours(p,c['space']))
    assert done['stale']==stale
    ranked=sorted(records.values(),key=lambda r:r['summary']['typical'],reverse=True)
    near=[r for r in records.values() if r['summary']['typical']>=ranked[0]['summary']['typical']-.05-1e-12]
    proposals=[r['parameters'] for r in ranked[:3]]+[r['parameters'] for r in sorted(near,key=lambda r:r['summary']['tail'],reverse=True)[:3]]+[select(list(records.values()))['parameters'],c['baseline']]
    finalists=[]
    for p in proposals:
        if p not in finalists:finalists.append(p)
    assert done['finalists']==finalists
    for path,sha in inputs.items():assert file_sha256(path)==sha
    atomic_write_json(root/'refinement_ga_audit.json',{'state':'pass_refinement_history_exact','generations':done['generations'],'trials':len(records),'stale':stale,'finalists':finalists,
        'inputs':inputs,'complete_sha256':file_sha256(stage/'complete.json'),'source_sha256':file_sha256(__file__),'seconds':time.monotonic()-began})
    print({'state':'pass_refinement_history_exact','generations':done['generations'],'trials':len(records)})

if __name__=='__main__':main()
