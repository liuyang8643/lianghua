import unittest
from research.topk_multistart_20261109.selection import key
from .driver import neighbours,restore_tuple,restore_ordered_records
from .cache import COLS

class RefinementContracts(unittest.TestCase):
    def test_neighbours_preserve_simplex_and_limits(self):
        space={'buy_n':[20,30,40],'sell_m':[40,60,80],'hold_thresh':[3,7,15],'max_replacements':[1,2,3,5,10]}
        for weights in ([10,0,0,0,0],[2,3,1,3,1]):
            p=dict(weights=weights,buy_n=40,sell_m=40,hold_thresh=3,max_replacements=1)
            ns=neighbours(p,space)
            self.assertEqual(len({key(x) for x in ns}),len(ns))
            self.assertNotIn(p,ns)
            for q in ns:
                self.assertEqual(sum(q['weights']),10);self.assertGreaterEqual(min(q['weights']),0)
                self.assertLessEqual(q['buy_n'],q['sell_m'])
                for k in space:self.assertIn(q[k],space[k])
    def test_rng_exact_checkpoint(self):
        import random,json
        rng=random.Random(20261110)
        for _ in range(100):rng.random()
        state=json.loads(json.dumps(rng.getstate()));a=[rng.random() for _ in range(100)]
        other=random.Random();other.setstate(restore_tuple(state))
        self.assertEqual(a,[other.random() for _ in range(100)])
    def test_trace_contract_names(self):
        self.assertEqual(COLS,['returns','nav_before','nav_after','cash','exposure','turnover','fees'])

    def test_checkpoint_preserves_discovery_order(self):
        from research.topk_multistart_20261109.selection import key
        ps=[{'buy_n':40},{'buy_n':30},{'buy_n':20}];order=[key(p) for p in ps]
        initial={order[0]:ps[0]};restored=restore_ordered_records(initial,order,lambda p:p)
        self.assertEqual(list(restored),order)
        self.assertNotEqual(list(restored),sorted(order))
        with self.assertRaisesRegex(AssertionError,'order changed'):
            restore_ordered_records(initial,sorted(order),lambda p:p)

if __name__=='__main__':unittest.main()
