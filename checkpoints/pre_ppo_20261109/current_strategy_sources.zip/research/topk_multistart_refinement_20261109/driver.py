"""Refinement and all-start decision; explicitly requires completed stage12."""
import os
for _name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[_name]='1'
import atexit,gc,json,random,time
from pathlib import Path
from copy import deepcopy
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from ai.supervised.multihorizon_search import load_forecasts
from research.topk_multistart_20261109.selection import key,select
from utils.atomic_file import atomic_write_json,file_sha256
from .cache import Evaluator,read_trial
from .batch import BatchEvaluator
from research.topk_multistart_parallel_20261109 import worker as verified_worker

HERE=Path(__file__).resolve().parent

def neighbours(p,space):
    results=[]
    for field in ('buy_n','sell_m','hold_thresh','max_replacements'):
        at=space[field].index(p[field])
        for j in (at-1,at+1):
            if 0<=j<len(space[field]):
                q=deepcopy(p);q[field]=space[field][j]
                if q['buy_n']<=q['sell_m']:results.append(q)
    for source,v in enumerate(p['weights']):
        if not v:continue
        for dest in range(5):
            if source==dest:continue
            q=deepcopy(p);q['weights'][source]-=1;q['weights'][dest]+=1;results.append(q)
    return sorted(results,key=key)

def elite(records,n):
    chosen=[select(list(records.values()))['parameters']]
    for r in sorted(records.values(),key=lambda r:r['summary']['typical'],reverse=True):
        if r['parameters'] not in chosen:chosen.append(r['parameters'])
        if len(chosen)>=n:break
    return chosen

def restore_tuple(v):return tuple(restore_tuple(x) for x in v) if isinstance(v,list) else v

def restore_ordered_records(initial,ordered_keys,load):
    assert len(set(ordered_keys))==len(ordered_keys),'duplicate checkpoint candidate'
    assert list(initial)==ordered_keys[:len(initial)],'checkpoint initial candidate order changed'
    result=dict(initial)
    for name in ordered_keys[len(initial):]:result[name]=load(json.loads(name))
    return result

def main():
    require_guarded_job();began=time.monotonic()
    extension=json.loads((HERE/'protocol.json').read_text());c=json.loads(Path(extension['parent_protocol']).read_text())
    out=Path(c['output']);stage12=out/'stage12/complete.json'
    assert stage12.exists(),'stage12 not complete; do not race or bypass'
    done=json.loads(stage12.read_text());assert done['state']=='stage_complete_not_final_winner'
    if done['stop_reason']!='patience':
        raise RuntimeError('stage12 reached a safety cap, not patience; continue its exact search state before refinement')
    assert json.loads((out/'default_reference_precompute/complete.json').read_text())['state']=='fixed_default_reference_complete_not_a_winner','fixed-reference writer must finish before sharing final caches'
    probe=json.loads((out/'cache_native_probe/complete.json').read_text())
    assert probe['state']=='pass_real_native_cache_parity'
    assert probe['cache_sha256']==file_sha256(HERE/'cache.py')
    parallel_probe=json.loads((out/'parallel_cache_probe/complete.json').read_text())
    assert parallel_probe['state']=='pass_parallel_cache_actual480paths'
    for path,sha in parallel_probe['sources'].items():assert file_sha256(path)==sha
    assert json.loads((out/'oof_sample_boundary_audit.json').read_text())['state']=='pass_saved_sample_boundaries_and_selection_metadata'
    import subprocess,sys
    subprocess.run([sys.executable,'-m','research.topk_multistart_refinement_20261109.audit_paths','--stage','12'],check=True)
    path_audit=out/f"path_audit_stage12_{done['trials']:05d}.json"
    assert json.loads(path_audit.read_text())['trial_count']==done['trials']
    directory=out/'stage48';directory.mkdir(exist_ok=True)
    source_paths=list(HERE.glob('*.py'))+[Path(extension['parent_protocol']),HERE/'protocol.json',stage12,out/'start_indices.json',Path(verified_worker.__file__)]
    original=json.loads((out/'stage12/identity.json').read_text())
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    identity={'source':{str(p):file_sha256(p) for p in source_paths},'parent_identity':file_sha256(out/'stage12/identity.json')}
    if (directory/'identity.json').exists():assert json.loads((directory/'identity.json').read_text())==identity
    else:atomic_write_json(directory/'identity.json',identity)
    if (out/'winner_lock.json').exists():raise RuntimeError('winner already sealed; do not repeat selection')
    starts=json.loads((out/'start_indices.json').read_text());rt,cube,provenance=load_forecasts(Path(c['parent']),'oof')
    assert provenance==starts['models'];np.testing.assert_array_equal(rt.trade_dates.astype(str),starts['dates'])
    evaluator=BatchEvaluator(c,starts,file_sha256(directory/'identity.json'),workers=extension['execution_workers'])
    atexit.register(evaluator.close);del rt,cube;gc.collect()
    records={}
    for p,record in zip(done['shortlist'],evaluator.evaluate_many(done['shortlist'],48)):
        records[key(p)]=record
    ga=extension['stage48'];rng=random.Random(ga['seed']);stale=0;anchor=None;generation=0
    checkpoint=directory/'checkpoint.json'
    if checkpoint.exists():
        cp=json.loads(checkpoint.read_text());assert cp['version']==2
        generation=cp['next_generation'];stale=cp['stale'];anchor=cp['anchor'];rng.setstate(restore_tuple(cp['rng']))
        records=restore_ordered_records(records,cp['completed_keys'],lambda p:evaluator.evaluate(p,48))
    while generation<ga['generation_safety_limit'] and stale<ga['patience']:
        population=elite(records,ga['population']);available={}
        for p in population:
            for q in neighbours(p,c['space']):
                if key(q) not in records:available[key(q)]=q
        candidates=list(available.values());rng.shuffle(candidates)
        if not candidates:break
        proposed=candidates[:ga['new_candidates_per_generation']]
        for p,record in zip(proposed,evaluator.evaluate_many(proposed,48)):
            records[key(p)]=record
        winner=select(list(records.values()));typical=max(r['summary']['typical'] for r in records.values());score=[typical,winner['summary']['tail']]
        improved=anchor is None or score[0]>anchor[0]+ga['min_improvement'] or (score[0]>=anchor[0]-1e-12 and score[1]>anchor[1]+ga['min_improvement'])
        if improved:anchor=score;stale=0
        else:stale+=1
        generation+=1
        atomic_write_json(directory/f'generation_{generation:03d}.json',{'winner':winner,'stale':stale,'trials':len(records),'population':population,'proposed':proposed,'record_order':list(records),'rng':rng.getstate()})
        atomic_write_json(checkpoint,{'version':2,'next_generation':generation,'stale':stale,'anchor':anchor,'rng':rng.getstate(),'completed_keys':list(records)})
        atomic_write_json(out/'status.json',{'state':'stage48_searching','generation':generation,'trials':len(records),'stale':stale})
    if generation>=ga['generation_safety_limit'] and stale<ga['patience']:
        atomic_write_json(directory/'budget_boundary.json',{'state':'not_converged','generation':generation,'stale':stale,'trials':len(records),'next_action':'continue exact checkpoint under separately recorded budget extension; do not select final winner'})
        raise RuntimeError('stage48 reached safety cap before patience; no winner lock permitted')
    ranked=sorted(records.values(),key=lambda r:r['summary']['typical'],reverse=True)
    near=[r for r in records.values() if r['summary']['typical']>=ranked[0]['summary']['typical']-.05-1e-12]
    proposals=[r['parameters'] for r in ranked[:3]]+[r['parameters'] for r in sorted(near,key=lambda r:r['summary']['tail'],reverse=True)[:3]]+[select(list(records.values()))['parameters'],c['baseline']]
    finalists=[]
    for p in proposals:
        if p not in finalists:finalists.append(p)
    atomic_write_json(directory/'complete.json',{'state':'complete','trials':len(records),'generations':generation,'stale':stale,'finalists':finalists,'stop_reason':'patience' if stale>=ga['patience'] else ('generation_limit' if generation>=ga['generation_safety_limit'] else 'neighbour_exhaustion')})
    atomic_write_json(out/'status.json',{'state':'all_starts_evaluating','total':len(finalists)})
    final_records=evaluator.evaluate_many(finalists,'all')
    evaluator.close()
    winner=select(final_records)
    for path,sha in identity['source'].items():assert file_sha256(path)==sha
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    lock={'state':'locked_before_outer_evaluation','parameters':winner['parameters'],'summary':winner['summary'],'all_start_candidates':[{'parameters':r['parameters'],'summary':r['summary'],'trace_sha256':r['trace_sha256']} for r in final_records],
        'stage48_sha256':file_sha256(directory/'complete.json'),'identity_sha256':file_sha256(directory/'identity.json'),'elapsed_seconds':time.monotonic()-began,'holdout_forecasts_read':False}
    atomic_write_json(out/'winner_lock.json',lock)
    atomic_write_json(out/'status.json',{'state':'winner_locked_outer_and_diagnostics_pending'})

if __name__=='__main__':main()
