"""Audit actual stored fit/early-stop sample indices and fold selection cutoffs."""
import json,time
from pathlib import Path
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256

def main():
    begun=time.monotonic()
    config=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text())
    root=Path(config['parent']);out=Path(config['output'])
    dates=np.load(root/'features/dates.npy').astype('datetime64[D]')
    nstocks=len(np.load(root/'features/codes.npy'))
    inputs={};results=[]
    def read(path):
        inputs[str(path)]=file_sha256(path)
        return json.loads(path.read_text(encoding='utf8'))
    for year in config['oof_years']:
        folder=root/'models'/f'fold{year}'
        done=read(folder/'complete.json');identity=read(folder/'identity.json')
        selection=read(root/'fold_selection'/f'fold{year}'/'complete.json')
        assert selection['fit_only'] and selection['spec']==done['spec']==identity['spec']
        assert set(selection['features'])==set(identity['features'])
        union=set()
        for h in config['horizons']:
            selected=read(root/'fold_selection'/f'fold{year}'/f'selected_{h}d.json')
            assert selected['fit']==done['spec']['fit']
            assert selected['label_end_boundary']==done['spec']['fit'][1]
            idx=int(np.searchsorted(dates,np.datetime64(selected['last_feature_date'])))
            assert dates[idx+60]<=np.datetime64(selected['label_end_boundary'])
            assert all(x['rank_ic']>0 for x in selected['selected'])
            union.update(x['name'] for x in selected['selected'])
        assert union==set(selection['features'])
        splits={}
        for filename,split in [('samples.npz','fit'),('validation_samples.npz','stop')]:
            path=folder/filename;inputs[str(path)]=file_sha256(path)
            with np.load(path) as z:
                flat=z['flat'];task=z['task'];weight=z['weight']
            assert flat.ndim==1 and len(flat)==len(task)==len(weight)
            assert set(np.unique(task))==set(range(5))
            assert np.isfinite(weight).all() and np.all(weight>0)
            # All horizons are purged conservatively by the maximum60-day horizon.
            rows=np.unique(flat//nstocks)
            assert rows.min()>=0 and rows.max()+60<len(dates)
            lo,hi=map(np.datetime64,done['spec'][split])
            assert np.all(dates[rows]>=lo) and np.all(dates[rows+60]<=hi)
            splits[split]={'samples':len(flat),'first':str(dates[rows[0]]),'last_feature':str(dates[rows[-1]]),'last_label_end':str(dates[rows[-1]+60])}
            del flat,task,weight
        assert np.datetime64(splits['fit']['last_label_end'])<np.datetime64(splits['stop']['first'])
        rows=np.load(folder/'rows.npy')
        assert np.datetime64(splits['stop']['last_label_end'])<dates[rows.min()]
        results.append({'year':year,'features':len(union),'splits':splits})
        print({'fold':year,'passed':True},flush=True)
    for path,sha in inputs.items():assert file_sha256(path)==sha
    atomic_write_json(out/'oof_sample_boundary_audit.json',{'state':'pass_saved_sample_boundaries_and_selection_metadata','folds':results,'inputs':inputs,'seconds':time.monotonic()-begun,'scope':'All stored fit and early-stop sample indices, conservative60day label endpoints, stored selection boundaries and union. Does not rederive every raw factor or claim previously studied periods are blind.','holdout_read':False})

if __name__=='__main__':main()
