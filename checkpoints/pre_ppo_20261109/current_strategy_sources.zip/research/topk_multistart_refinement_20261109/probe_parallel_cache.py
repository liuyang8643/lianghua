"""Full10-year/48-start baseline through the new worker wrapper vs serial cache."""
import gc,json,shutil,time
from pathlib import Path
from scripts.run_research_guarded import require_guarded_job
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256
from .batch import BatchEvaluator
from .cache import digest,read_trial

def main():
    require_guarded_job();began=time.monotonic();c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text());root=Path(c['output']);out=root/'parallel_cache_probe'
    if out.exists():raise RuntimeError('probe root exists; preserve previous evidence')
    p=c['baseline'];name=f'{digest(p)}.json';reference=root/'stage48/trials'/name;old=read_trial(reference)
    assert len(old['paths'])==480
    (out/'stage12/trials').mkdir(parents=True)
    for suffix in ('.json','.npz'):
        source=(root/'stage12/trials'/name).with_suffix(suffix);shutil.copy2(source,(out/'stage12/trials'/name).with_suffix(suffix))
    original=json.loads((root/'stage12/identity.json').read_text())
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    starts=json.loads((root/'start_indices.json').read_text());cfg=dict(c);cfg['output']=str(out)
    identity={str(path):file_sha256(path) for path in [Path(__file__),Path(__file__).with_name('batch.py'),Path(__file__).with_name('parallel_worker.py')]}
    e=BatchEvaluator(cfg,starts,'parallel-cache-probe',workers=4)
    try:actual=e.evaluate_many([p],48)[0]
    finally:e.close()
    assert actual['paths']==old['paths'] and actual['summary']==old['summary']
    with np.load(reference.with_suffix('.npz')) as a,np.load((out/'stage48/trials'/name).with_suffix('.npz')) as b:
        assert set(a.files)==set(b.files)
        for field in a.files:np.testing.assert_array_equal(a[field],b[field])
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    for path,sha in identity.items():assert file_sha256(path)==sha
    atomic_write_json(out/'complete.json',{'state':'pass_parallel_cache_actual480paths','sources':identity,'reference_sha256':file_sha256(reference),'paths':480,
        'all_arrays_metrics_summary_exact':True,'reused_paths':actual['reused_paths'],'new_paths':actual['new_paths'],'seconds':time.monotonic()-began,'holdout_read':False})
    print({'state':'pass_parallel_cache_actual480paths','seconds':time.monotonic()-began},flush=True)

if __name__=='__main__':main()
