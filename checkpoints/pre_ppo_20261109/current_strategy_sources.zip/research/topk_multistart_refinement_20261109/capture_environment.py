"""Capture local reproducibility metadata; no market/model computation."""
import importlib.metadata,json,platform,subprocess,sys,zipfile
from pathlib import Path
from utils.atomic_file import atomic_write_json,file_sha256

def main():
    root=Path('artifacts/research/topk_multistart_20261109');destination=root/'environment'
    if destination.exists():raise RuntimeError('environment capture already exists; preserve first capture')
    identity=json.loads((root/'stage12/identity.json').read_text())
    for path,sha in identity['sources'].items():assert file_sha256(path)==sha
    destination.mkdir()
    packages=sorted([{'name':d.metadata['Name'],'version':d.version} for d in importlib.metadata.distributions()],key=lambda x:(x['name'] or '').lower())
    inventory={}
    archive=destination/'supplementary_dependency_sources.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for folder in ('factor_db','data','configs','testback','strategy_release'):
            for path in Path(folder).rglob('*.py'):
                inventory[str(path)]=file_sha256(path);z.write(path,path.as_posix())
        for filename in ('pyproject.toml','uv.lock','.venv/pyvenv.cfg'):
            path=Path(filename);inventory[str(path)]=file_sha256(path);z.write(path,path.as_posix())
    for path,sha in identity['sources'].items():assert file_sha256(path)==sha
    for path,sha in inventory.items():assert file_sha256(path)==sha
    result={'python':sys.version,'executable':sys.executable,'base_executable':sys._base_executable,'executable_sha256':file_sha256(sys.executable),
        'base_executable_sha256':file_sha256(sys._base_executable),'platform':platform.platform(),'packages':packages,
        'git_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'git_branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
        'original_source_identity_sha256':file_sha256(root/'stage12/identity.json'),'supplementary_inventory':inventory,'archive_sha256':file_sha256(archive),
        'scope':'Environment and supplementary dependencies captured during active uninterrupted search. Original sealed search sources rechecked exact; supplemental dependencies were not independently snapshotted at initial launch. No secrets/environment variables or market outcomes are serialized.'}
    atomic_write_json(destination/'manifest.json',result)
    print({'state':'environment_captured','packages':len(packages),'supplementary_files':len(inventory),'python':platform.python_version()})

if __name__=='__main__':main()
