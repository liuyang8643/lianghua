"""Parallel computation, ordered consumption, exact cached coverage checks."""
import concurrent.futures,multiprocessing
from pathlib import Path
from . import parallel_worker
from .cache import read_trial,digest
from research.topk_multistart_20261109.selection import key

class BatchEvaluator:
    def __init__(self,c,starts,identity,workers=4):
        self.c,self.starts=c,starts;self.root=Path(c['output']);self.closed=False
        self.pool=concurrent.futures.ProcessPoolExecutor(max_workers=workers,mp_context=multiprocessing.get_context('spawn'),
            initializer=parallel_worker.initialize,initargs=(str(self.root),identity))

    def validate(self,record,p,stage):
        assert record['parameters']==p and record['stage']==stage
        expected=[]
        for year in self.c['scored_years']:
            schedule=self.starts['schedules'][str(year)]
            indices=schedule[str(max(map(int,schedule)))] if stage=='all' else schedule[str(stage)]
            expected.extend((year,self.starts['dates'][i]) for i in indices)
        assert [(r['year'],r['start']) for r in record['paths']]==expected,'cached candidate has wrong start coverage'

    def evaluate_many(self,parameters,stage):
        assert not self.closed
        results={};missing=[]
        for p in parameters:
            path=self.root/f'stage{stage}/trials'/f'{digest(p)}.json'
            if path.exists():
                record=read_trial(path);self.validate(record,p,stage);results[key(p)]=record
            elif p not in missing:missing.append(p)
        for p,result in zip(missing,self.pool.map(parallel_worker.evaluate,[(p,stage) for p in missing])):
            assert result['key']==key(p)
            path=self.root/f'stage{stage}/trials'/f'{digest(p)}.json'
            record=read_trial(path);assert record==result['record'];self.validate(record,p,stage);results[key(p)]=record
        return [results[key(p)] for p in parameters]

    def evaluate(self,p,stage):return self.evaluate_many([p],stage)[0]

    def close(self):
        if not self.closed:self.pool.shutdown(wait=True);self.closed=True
