Progress and remaining gates
============================

2026-11-09, stage12 continues in original guarded process (do not duplicate).
No original search-bound Python source was modified in this continuation.

New evidence:

* audit_oof.py checked every saved fit/early-stop sample index in11folds,
  conservative60day endpoints, selection metadata, positive IC and feature union.
  Receipt: artifacts/research/topk_multistart_20261109/oof_sample_boundary_audit.json.
  This is not a new reconstruction of raw factor point-in-time inputs.
* audit_paths.py independently reconstructs annual returns/drawdown/Calmar and
  mean-fold median/q20 from actual saved arrays, checking common start coverage.
  First snapshot passed4trials/480paths. It does not imply search completion.
* Refinement protocol fixed before stage12 finishes: stage48 initial shortlist,
 16elite population with4local mutations per generation,10stale/60safetycap;
  final top3typical +top3eligible-tail +winner +default, deduplicated.
* Separate refinement evaluator reuses exact matching start paths only, keeping
  full trace arrays and provenance. driver.py refuses launch without stage12
  completion; no refinement or outer backtest has run yet.
* Three refinement unit tests passed. Actual cache/full-stage parity and driver
  integration tests remain necessary before stage48 launch.

Important resume issue identified by code inspection:

Original search.py comment claims deterministic replay on resume, but loading
all partial/future trial records before replaying generation0 can contaminate
earlier generation selection. Current uninterrupted process is unaffected.
Do not use its main entry to resume a stopped run. Implement a separate resume
entry restoring last completed generation RNG and historical record-prefix,
with saved trace reuse only when a candidate is reached. Preserve old source.

Next actions:

1. Verify original process identity and advance; audit completed snapshots.
2. Test refinement reuse/selection with saved baseline paths, including missing,
   mismatched and incomplete traces. Full model/engine source parity mandatory.
3. Complete stage12, then launch stage48 and final all-start evaluation. Do not
   allow incomplete stages to be presented as a final selected strategy.
4. Lock parameters before any outer prediction load. Build final-head cube
   from existing parent and verified YTD tail forecasts; no new training.
5. Native winner/default reports, fresh launch and holdings-convergence
   diagnostics, full lineage and per-requirement completion audit.

Score interpretation: mean annual Calmar is not continuous-period Calmar.
Default first-stage mean annual median about3.63 must not be presented as an
improvement over its continuous OOF Calmar1.365; those are different statistics.
Only compare candidates under exactly the same statistic/calendar/coverage.
