import hashlib,json,unittest
from pathlib import Path
from copy import deepcopy
from research.topk_multistart_20261109.selection import key,aggregate
from .recover_stage12 import replay_ga

class Recovery(unittest.TestCase):
    def test_future_cache_does_not_change_historical_generations(self):
        c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text());c['ga']['population']=8;c['ga']['generation_safety_limit']=4
        cache={};first=[]
        def evaluate(p):
            k=key(p)
            if k not in cache:
                value=int(hashlib.sha256(k.encode()).hexdigest()[:8],16)/2**32
                paths=[{'year':2012,'start':str(i),'metrics':{'calmar':value+i/100,'mean_gross_turnover':.1}} for i in range(3)]
                cache[k]={'parameters':deepcopy(p),'paths':paths,'summary':aggregate(paths)}
            return cache[k]
        records,_,_=replay_ga(c,evaluate,lambda g,s:first.append(json.loads(json.dumps(s))))
        seen=[];second=[]
        def from_future_cache(p):seen.append(key(p));return cache[key(p)]
        again,_,_=replay_ga(c,from_future_cache,lambda g,s:second.append(json.loads(json.dumps(s))))
        self.assertEqual(first,second);self.assertEqual(list(records),seen);self.assertEqual(records,again)
        self.assertEqual(first[0]['trials'],8)
        self.assertGreater(len(cache),8)
        prefetched=set();third=[]
        def prefetch(population):
            # Completion order differs from original parameter order.
            for p in reversed(population):prefetched.add(key(p))
        def lookup(p):
            self.assertIn(key(p),prefetched)
            return cache[key(p)]
        parallel,_,_=replay_ga(c,lookup,lambda g,s:third.append(json.loads(json.dumps(s))),prepare_population=prefetch)
        self.assertEqual(first,third);self.assertEqual(records,parallel)

if __name__=='__main__':unittest.main()
