import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256
from research.topk_multistart_20261109.selection import aggregate,key
from .cache import digest
from .batch import BatchEvaluator

class BatchContract(unittest.TestCase):
    def test_order_reuse_and_wrong_coverage(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);params=[dict(weights=[2]*5,buy_n=n,sell_m=40,hold_thresh=3,max_replacements=1) for n in (20,30,40)]
            starts={'dates':['2011-01-04','2011-06-01','2011-12-30'],'schedules':{'2012':{'48':[0,1,2]}}};calls=[]
            def write(p):
                path=root/'stage48/trials'/f'{digest(p)}.json';path.parent.mkdir(parents=True,exist_ok=True)
                rows=[{'year':2012,'start':d,'metrics':{'calmar':1.,'mean_gross_turnover':.1}} for d in starts['dates']]
                np.savez(path.with_suffix('.npz'),fixture_only=np.ones(1))
                r={'parameters':p,'stage':48,'paths':rows,'summary':aggregate(rows),'trace_sha256':file_sha256(path.with_suffix('.npz'))};atomic_write_json(path,r);return r
            write(params[0])
            class FakePool:
                def __init__(self,**kwargs):pass
                def map(self,fn,tasks):
                    tasks=list(tasks);done={}
                    for p,stage in reversed(tasks):calls.append(p);done[key(p)]=write(p)
                    return iter([{'key':key(p),'record':done[key(p)]} for p,stage in tasks])
                def shutdown(self,wait):pass
            with patch('research.topk_multistart_refinement_20261109.batch.concurrent.futures.ProcessPoolExecutor',FakePool):
                e=BatchEvaluator({'output':folder,'scored_years':[2012]},starts,'fixture')
                result=e.evaluate_many(params,48)
                self.assertEqual([r['parameters'] for r in result],params);self.assertEqual(calls,params[:0:-1])
                path=root/'stage48/trials'/f'{digest(params[0])}.json';r=json.loads(path.read_text());r['paths'].pop();r['summary']=aggregate(r['paths']);atomic_write_json(path,r)
                with self.assertRaisesRegex(AssertionError,'coverage'):e.evaluate(params[0],48)
                e.close()

if __name__=='__main__':unittest.main()
