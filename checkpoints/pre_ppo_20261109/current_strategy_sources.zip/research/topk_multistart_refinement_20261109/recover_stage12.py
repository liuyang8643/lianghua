"""Causal-prefix recovery for an interrupted stage12; never restart a live job."""
import gc,hashlib,json,random,time
from pathlib import Path
import numpy as np
from ai.supervised.multihorizon_search import random_candidate,load_forecasts
from ai.supervised.portfolio import PreparedModelPortfolio
from research.topk_multistart_20261109.search import make_child,save_trial
from research.topk_multistart_20261109.selection import key,select
from utils.atomic_file import atomic_write_json,file_sha256
from .cache import read_trial

def replay_ga(c,evaluate,on_generation,prepare_population=None):
    """Only reveal a cached result when its candidate is causally reached."""
    ga=c['ga'];space=c['space'];rng=random.Random(ga['seed']);records={};population=[c['baseline']]
    for i in range(5):
        w=[0]*5;w[i]=10;population.append(dict(weights=w,buy_n=20,sell_m=60,hold_thresh=7,max_replacements=2))
    population.append(dict(weights=[2]*5,buy_n=20,sell_m=60,hold_thresh=7,max_replacements=2))
    while len(population)<ga['population']:
        p=random_candidate(space,rng)
        if p not in population:population.append(p)
    stale=0;anchor=None
    for generation in range(ga['generation_safety_limit']):
        if prepare_population is not None:prepare_population(population)
        for p in population:
            if key(p) not in records:records[key(p)]=evaluate(p)
        winner=select(list(records.values()));best=max(r['summary']['typical'] for r in records.values());score=(best,winner['summary']['tail'])
        improved=anchor is None or score[0]>anchor[0]+ga['min_improvement'] or (score[0]>=anchor[0]-1e-12 and score[1]>anchor[1]+ga['min_improvement'])
        if improved:stale=0;anchor=score
        else:stale+=1
        snapshot={'population':population,'winner':winner,'stale':stale,'rng':rng.getstate(),'trials':len(records)}
        on_generation(generation+1,snapshot)
        if stale>=ga['patience']:break
        ranked=sorted(records.values(),key=lambda r:r['summary']['typical'],reverse=True)
        elite=[winner['parameters']]
        for r in ranked:
            if r['parameters'] not in elite:elite.append(r['parameters'])
            if len(elite)==4:break
        new=elite[:]
        while len(new)<ga['population']:
            p=random_candidate(space,rng) if rng.random()<.15 else make_child(space,population,records,rng)
            if p not in new:new.append(p)
        population=new
    return records,generation+1,stale

def main():
    from scripts.run_research_guarded import require_guarded_job
    import psutil
    require_guarded_job()
    # Exact module argument, including guarded launchers, not a loose substring.
    own=psutil.Process();owned={own.pid,*[p.pid for p in own.parents()]}
    modules={'research.topk_multistart_20261109.search','research.topk_multistart_refinement_20261109.recover_stage12'}
    for process in psutil.process_iter(['pid','cmdline']):
        if process.pid in owned:continue
        cmd=process.info['cmdline'] or []
        if any(cmd[i]=='-m' and cmd[i+1] in modules for i in range(len(cmd)-1)):
            raise RuntimeError(f'search process still live: {process.pid}; refuse duplicate')
    c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text());root=Path(c['output']);stage=root/'stage12'
    if (stage/'complete.json').exists():raise RuntimeError('sealed stage exists; this entry only recovers interrupted stages')
    identity=json.loads((stage/'identity.json').read_text())
    for path,sha in identity['sources'].items():assert file_sha256(path)==sha
    assert identity['protocol']==file_sha256(Path('research/topk_multistart_20261109/protocol.json'))
    assert identity['starts']==file_sha256(root/'start_indices.json')
    starts=json.loads((root/'start_indices.json').read_text());began=time.monotonic()
    rt,cube,provenance=load_forecasts(Path(c['parent']),'oof');assert provenance==starts['models']
    audit=stage/f'recovery_{time.time_ns()}.json';new_count=0;reuse_count=0
    def evaluate(p):
        nonlocal new_count,reuse_count
        path=stage/'trials'/f'{hashlib.sha256(key(p).encode()).hexdigest()}.json'
        if path.exists():reuse_count+=1;return read_trial(path)
        signal=np.sum(cube*(np.asarray(p['weights'])/10),axis=2)
        prepared=PreparedModelPortfolio.from_scores(rt,signal,initial_cash=c['execution']['initial_cash'],source_hash=hashlib.sha256((identity['protocol']+key(p)).encode()).hexdigest(),split='oof_multistart')
        record=save_trial(root,p,12,prepared,starts,c['scored_years']);new_count+=1
        del prepared,signal;gc.collect();return record
    def on_generation(generation,snapshot):
        path=stage/f'generation_{generation:03d}.json'
        normalized=json.loads(json.dumps(snapshot))
        if path.exists():assert json.loads(path.read_text())==normalized,'historical generation/RNG mismatch'
        else:atomic_write_json(path,snapshot)
        atomic_write_json(audit,{'state':'running_causal_prefix_recovery','source_sha256':file_sha256(__file__),'generation':generation,'new':new_count,'reused':reuse_count,'seconds':time.monotonic()-began})
    records,generations,stale=replay_ga(c,evaluate,on_generation)
    for path,sha in identity['sources'].items():assert file_sha256(path)==sha
    ranked=sorted(records.values(),key=lambda r:r['summary']['typical'],reverse=True);shortlist=[r['parameters'] for r in ranked[:12]]
    for r in sorted(records.values(),key=lambda r:r['summary']['tail'],reverse=True):
        if r['summary']['typical']>=ranked[0]['summary']['typical']-.05 and r['parameters'] not in shortlist:shortlist.append(r['parameters'])
        if len(shortlist)>=24:break
    if c['baseline'] not in shortlist:shortlist.append(c['baseline'])
    atomic_write_json(stage/'complete.json',{'state':'stage_complete_not_final_winner','generations':generations,'trials':len(records),'stop_reason':'patience' if stale>=c['ga']['patience'] else 'safety_generation_limit','shortlist':shortlist,'seconds':time.monotonic()-began,'recovery_receipt':str(audit)})
    atomic_write_json(audit,{'state':'complete_causal_prefix_recovery','source_sha256':file_sha256(__file__),'new':new_count,'reused':reuse_count,'seconds':time.monotonic()-began})

if __name__=='__main__':main()
