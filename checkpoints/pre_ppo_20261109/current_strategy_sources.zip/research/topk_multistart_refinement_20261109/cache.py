"""Exact per-path reuse between increasing start-coverage stages."""
import gc,hashlib,json,time
from pathlib import Path
import numpy as np
from ai.supervised.portfolio import PreparedModelPortfolio
from research.topk_multistart_20261109.evaluator import run_path,summarize
from research.topk_multistart_20261109.selection import key,aggregate
from utils.atomic_file import atomic_write_json,file_sha256

COLS=['returns','nav_before','nav_after','cash','exposure','turnover','fees']

def digest(p):return hashlib.sha256(key(p).encode()).hexdigest()

def read_trial(path):
    r=json.loads(path.read_text(encoding='utf8'))
    assert file_sha256(path.with_suffix('.npz'))==r['trace_sha256']
    assert r['summary']==aggregate(r['paths'])
    return r

class Evaluator:
    def __init__(self,rt,cube,config,starts,source_identity):
        self.rt,self.cube,self.c,self.starts,self.identity=rt,cube,config,starts,source_identity
        self.output=Path(config['output'])
        self.years=np.asarray([int(str(d)[:4]) for d in rt.trade_dates])

    def indices(self,year,stage):
        schedule=self.starts['schedules'][str(year)]
        return schedule[str(max(map(int,schedule)))] if stage=='all' else schedule[str(stage)]

    def evaluate(self,p,stage):
        directory=self.output/f'stage{stage}'/'trials';directory.mkdir(parents=True,exist_ok=True)
        path=directory/f'{digest(p)}.json'
        if path.exists():return read_trial(path)
        began=time.monotonic();reused={};parent_hashes={}
        for old in ([12] if stage==48 else [12,48]):
            parent=self.output/f'stage{old}'/'trials'/path.name
            if not parent.exists():continue
            record=read_trial(parent);assert record['parameters']==p
            parent_hashes[str(parent)]=file_sha256(parent)
            with np.load(parent.with_suffix('.npz')) as z:
                offsets=z['offsets'];values=z['values'];columns=z['columns']
            np.testing.assert_array_equal(columns,COLS)
            assert len(offsets)==len(record['paths'])+1 and offsets[-1]==len(values)
            for i,r in enumerate(record['paths']):
                ident=(r['year'],r['start']);a=values[offsets[i]:offsets[i+1]]
                if ident in reused:
                    np.testing.assert_array_equal(a,reused[ident][1]);assert r==reused[ident][0]
                reused[ident]=(r,a.copy())
        signal=np.sum(self.cube*(np.asarray(p['weights'])/10),axis=2)
        prepared=PreparedModelPortfolio.from_scores(self.rt,signal,initial_cash=self.c['execution']['initial_cash'],source_hash=self.identity,split='oof_multistart')
        paths=[];arrays=[];offsets=[0];hits=0;misses=0
        for year in self.c['scored_years']:
            stop=min(self.rt.decision_stop,int(np.flatnonzero(self.years<=year)[-1])+1)
            for start in self.indices(year,stage):
                date=str(self.rt.trade_dates[start]);ident=(year,date)
                if ident in reused:
                    record,a=reused[ident];hits+=1
                    assert len(a)==stop-start-1
                    check={'returns':a[:,0],'nav':np.r_[a[0,1],a[:,2]],'cash':a[:,3],'exposure':a[:,4],'turnover':a[:,5],'fees':a[:,6],
                        'next_dates':self.rt.trade_dates[start+1:stop].astype(str)}
                    assert summarize(check,year)==record['metrics']
                else:
                    trace=run_path(prepared,p,start,stop);misses+=1
                    record={'year':year,'start':date,'metrics':summarize(trace,year)}
                    a=np.column_stack([trace['returns'],trace['nav'][:-1],trace['nav'][1:],trace['cash'],trace['exposure'],trace['turnover'],trace['fees']])
                paths.append(record);arrays.append(a);offsets.append(offsets[-1]+len(a))
        result={'parameters':p,'stage':stage,'paths':paths,'summary':aggregate(paths),'seconds':time.monotonic()-began,'reused_paths':hits,'new_paths':misses,'reuse_sources':parent_hashes}
        np.savez_compressed(path.with_suffix('.npz'),values=np.concatenate(arrays),offsets=np.asarray(offsets),columns=np.asarray(COLS))
        result['trace_sha256']=file_sha256(path.with_suffix('.npz'));atomic_write_json(path,result)
        del prepared,signal;gc.collect()
        print({'stage':stage,'parameters':p,'typical':result['summary']['typical'],'tail':result['summary']['tail'],'reused':hits,'new':misses,'seconds':result['seconds']},flush=True)
        return result
