"""NumPy-only reconstruction of saved native paths; no model/account execution."""
import argparse,json,time
from pathlib import Path
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',default='12');args=parser.parse_args()
    root=Path('artifacts/research/topk_multistart_20261109');started=time.monotonic()
    axes=json.loads((root/'start_indices.json').read_text());dates=np.asarray(axes['dates']);inputs={};pathcount=0
    files=sorted((root/f'stage{args.stage}'/'trials').glob('*.json'))
    for file in files:
        record=json.loads(file.read_text());inputs[str(file)]=file_sha256(file)
        trace=file.with_suffix('.npz');assert file_sha256(trace)==record['trace_sha256']
        with np.load(trace) as z:values=z['values'];offsets=z['offsets'];cols=z['columns']
        assert list(cols)==['returns','nav_before','nav_after','cash','exposure','turnover','fees']
        assert len(offsets)==len(record['paths'])+1 and offsets[0]==0 and offsets[-1]==len(values)
        summaries={};turnover={};coverage={}
        for i,path in enumerate(record['paths']):
            x=values[offsets[i]:offsets[i+1]];start=int(np.searchsorted(dates,path['start']));year=path['year']
            nd=dates[start+1:start+1+len(x)]
            assert len(nd)==len(x) and np.all(nd<='2021-12-31')
            np.testing.assert_allclose(x[:,0],x[:,2]/x[:,1]-1,atol=1e-12,rtol=1e-10)
            np.testing.assert_array_equal(x[1:,1],x[:-1,2])
            mask=np.char.startswith(nd,str(year));r=x[mask,0];nav=np.r_[1.,np.cumprod(1+r)]
            ann=np.expm1(np.log1p(r).sum()*252/len(r));dd=float(np.max(1-nav/np.maximum.accumulate(nav)))
            # Native denominator epsilon is an explicit contract, read below rather than guessed.
            from env.metrics import CALMAR_DRAWDOWN_EPSILON
            m={'transition_count':len(r),'total_return':nav[-1]-1,'annualized_return':ann,'max_drawdown':dd,'calmar':ann/max(dd,CALMAR_DRAWDOWN_EPSILON),
                'mean_gross_turnover':x[mask,5].mean(),'total_fees':x[mask,6].sum(),'mean_exposure':x[mask,4].mean()}
            for k,v in m.items():np.testing.assert_allclose(v,path['metrics'][k],rtol=1e-9,atol=1e-10)
            summaries.setdefault(year,[]).append(m['calmar']);turnover.setdefault(year,[]).append(m['mean_gross_turnover']);coverage.setdefault(year,[]).append(start);pathcount+=1
        assert sorted(coverage)==list(range(2012,2022))
        for year,starts in coverage.items():
            schedule=axes['schedules'][str(year)];expected=schedule[str(max(map(int,schedule)))] if args.stage=='all' else schedule[args.stage]
            assert starts==expected
        expected={'typical':np.mean([np.median(v) for v in summaries.values()]),'tail':np.mean([np.quantile(v,.2) for v in summaries.values()]),
            'worst_fold':min(np.median(v) for v in summaries.values()),'turnover':np.mean([np.mean(v) for v in turnover.values()])}
        for k,v in expected.items():np.testing.assert_allclose(v,record['summary'][k],rtol=1e-9,atol=1e-10)
    for path,sha in inputs.items():assert file_sha256(path)==sha
    receipt={'state':'pass_saved_paths_only','stage':args.stage,'trial_count':len(files),'paths':pathcount,'inputs':inputs,'seconds':time.monotonic()-started,'snapshot_only':True,'does_not_certify_search_complete':True}
    atomic_write_json(root/f'path_audit_stage{args.stage}_{len(files):05d}.json',receipt)
    print({k:v for k,v in receipt.items() if k!='inputs'})

if __name__=='__main__':main()
