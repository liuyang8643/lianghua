"""Replay completed generation decisions from saved trials, without accounts."""
import json,time
from pathlib import Path
from utils.atomic_file import atomic_write_json,file_sha256
from .recover_stage12 import replay_ga
from .cache import digest,read_trial

def main():
    began=time.monotonic();c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text());root=Path(c['output']);stage=root/'stage12'
    snapshots=sorted(stage.glob('generation_*.json'))
    if not snapshots:raise RuntimeError('no complete generation yet; wait, do not infer progress from partial population')
    count=int(snapshots[-1].stem.rsplit('_',1)[1]);assert [int(p.stem.rsplit('_',1)[1]) for p in snapshots]==list(range(1,count+1))
    c['ga']['generation_safety_limit']=count;inputs={str(p):file_sha256(p) for p in snapshots};checked=[]
    def evaluate(p):
        path=stage/'trials'/f'{digest(p)}.json';inputs[str(path)]=file_sha256(path);return read_trial(path)
    def check(g,s):
        path=stage/f'generation_{g:03d}.json'
        assert json.loads(path.read_text())==json.loads(json.dumps(s)),f'GA generation{g} selection or RNG mismatch'
        checked.append(g)
    records,_,_=replay_ga(c,evaluate,check)
    for p,sha in inputs.items():assert file_sha256(p)==sha
    receipt={'state':'pass_saved_ga_history_exact','generations':checked,'unique_trials':len(records),'inputs':inputs,'seconds':time.monotonic()-began,
        'scope':'same populations, winner, patience count, trial counts and RNG; saved outcomes only, no new financial execution','recovery_source_sha256':file_sha256(Path(__file__).with_name('recover_stage12.py'))}
    atomic_write_json(root/f'ga_replay_audit_{count:03d}.json',receipt)
    print({k:v for k,v in receipt.items() if k!='inputs'})

if __name__=='__main__':main()
