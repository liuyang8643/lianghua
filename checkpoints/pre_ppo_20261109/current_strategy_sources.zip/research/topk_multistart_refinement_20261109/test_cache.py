"""Cross-stage reuse must equal fresh evaluation, including valuation boundaries."""
import json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256
from research.topk_multistart_20261109.evaluator import summarize
from research.topk_multistart_20261109.selection import aggregate
from .cache import Evaluator,digest,COLS

class CacheContract(unittest.TestCase):
    def test_reuse_matches_fresh_and_runs_only_missing_path(self):
        dates=np.asarray(['2011-12-28','2011-12-29','2011-12-30','2012-01-03','2012-01-04','2012-01-05'],dtype='datetime64[D]')
        rt=SimpleNamespace(trade_dates=dates,decision_stop=6)
        parameters={'weights':[2]*5,'buy_n':20,'sell_m':40,'hold_thresh':3,'max_replacements':1}
        calls=[]
        def path(prepared,p,start,stop):
            calls.append(start);r=np.asarray([.01,-.02,.03,-.01,.02])[start:stop-1]
            return {'returns':r,'nav':1e6*np.r_[1.,np.cumprod(1+r)],'cash':np.zeros(len(r)),
                'exposure':np.full(len(r),.95),'turnover':np.full(len(r),.1),'fees':np.full(len(r),100.),'next_dates':dates[start+1:stop].astype(str)}
        with tempfile.TemporaryDirectory() as folder:
            out=Path(folder);d=out/'stage12/trials';d.mkdir(parents=True)
            rows=[];chunks=[];offsets=[0]
            for start in (0,2):
                a=path(None,parameters,start,6)
                rows.append({'year':2012,'start':str(dates[start]),'metrics':summarize(a,2012)})
                chunks.append(np.column_stack([a['returns'],a['nav'][:-1],a['nav'][1:],a['cash'],a['exposure'],a['turnover'],a['fees']]))
                offsets.append(offsets[-1]+len(a['returns']))
            target=d/f'{digest(parameters)}.npz'
            np.savez_compressed(target,values=np.concatenate(chunks),offsets=offsets,columns=COLS)
            atomic_write_json(target.with_suffix('.json'),{'parameters':parameters,'paths':rows,'summary':aggregate(rows),'trace_sha256':file_sha256(target)})
            c={'output':folder,'execution':{'initial_cash':1e6},'scored_years':[2012]}
            starts={'schedules':{'2012':{'12':[0,2],'48':[0,1,2]}}}
            e=Evaluator(rt,np.zeros((6,1,5)),c,starts,'fixture')
            calls.clear()
            with patch('research.topk_multistart_refinement_20261109.cache.PreparedModelPortfolio.from_scores',return_value=SimpleNamespace()),patch('research.topk_multistart_refinement_20261109.cache.run_path',side_effect=path):
                result=e.evaluate(parameters,48)
            self.assertEqual(calls,[1]);self.assertEqual(result['reused_paths'],2);self.assertEqual(result['new_paths'],1)
            expected=[{'year':2012,'start':str(dates[i]),'metrics':summarize(path(None,parameters,i,6),2012)} for i in range(3)]
            self.assertEqual(result['paths'],expected);self.assertEqual(result['summary'],aggregate(expected))
            # Cached result must be hash-verified, not trusted solely on a JSON marker.
            file=out/'stage48/trials'/f'{digest(parameters)}.npz'
            with file.open('ab') as stream:stream.write(b'corruption')
            with self.assertRaises(AssertionError):e.evaluate(parameters,48)

if __name__=='__main__':unittest.main()
