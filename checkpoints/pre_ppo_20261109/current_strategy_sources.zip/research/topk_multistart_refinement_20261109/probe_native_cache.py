"""Real-market12->48 cache parity for one OOF year; never a search trial."""
import json,time
from pathlib import Path
from copy import deepcopy
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from ai.supervised.multihorizon_search import load_forecasts
from ai.supervised.portfolio import PreparedModelPortfolio
from research.topk_multistart_20261109.evaluator import run_path,summarize
from research.topk_multistart_20261109.selection import aggregate
from utils.atomic_file import atomic_write_json,file_sha256
from .cache import Evaluator,digest,COLS,read_trial

def main():
    require_guarded_job();began=time.monotonic()
    c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text())
    root=Path(c['output']);out=root/'cache_native_probe'
    if out.exists():raise RuntimeError('probe root exists; inspect, do not overwrite')
    out.mkdir();p=c['baseline'];year=2012
    parent=root/'stage12/trials'/f'{digest(p)}.json';r=read_trial(parent)
    source_sha=file_sha256(parent);trace_sha=file_sha256(parent.with_suffix('.npz'))
    with np.load(parent.with_suffix('.npz')) as z:values=z['values'];offsets=z['offsets']
    rows=[];chunks=[];new_offsets=[0]
    for i,row in enumerate(r['paths']):
        if row['year']!=year:continue
        a=values[offsets[i]:offsets[i+1]];rows.append(row);chunks.append(a);new_offsets.append(new_offsets[-1]+len(a))
    assert len(rows)==12
    target=out/'stage12/trials'/parent.name;target.parent.mkdir(parents=True)
    np.savez_compressed(target.with_suffix('.npz'),values=np.concatenate(chunks),offsets=new_offsets,columns=COLS)
    atomic_write_json(target,{'parameters':p,'paths':rows,'summary':aggregate(rows),'trace_sha256':file_sha256(target.with_suffix('.npz')),
        'probe_subset_only':True,'parent':str(parent),'parent_sha256':source_sha})
    starts=json.loads((root/'start_indices.json').read_text());rt,cube,provenance=load_forecasts(Path(c['parent']),'oof')
    assert provenance==starts['models']
    cfg=deepcopy(c);cfg['output']=str(out);cfg['scored_years']=[year]
    cache=Evaluator(rt,cube,cfg,starts,'native-cache-probe')
    result=cache.evaluate(p,48)
    assert result['reused_paths']==12 and result['new_paths']==36
    with np.load(out/'stage48/trials'/f'{digest(p)}.npz') as z:actual=z['values'];positions=z['offsets']
    signal=np.sum(cube*(np.asarray(p['weights'])/10),axis=2)
    prepared=PreparedModelPortfolio.from_scores(rt,signal,initial_cash=c['execution']['initial_cash'],source_hash='native-cache-probe',split='oof_probe')
    years=np.asarray([int(str(d)[:4]) for d in rt.trade_dates]);stop=int(np.flatnonzero(years<=year)[-1])+1
    fresh_rows=[]
    for i,start in enumerate(starts['schedules'][str(year)]['48']):
        trace=run_path(prepared,p,start,stop)
        fresh=np.column_stack([trace['returns'],trace['nav'][:-1],trace['nav'][1:],trace['cash'],trace['exposure'],trace['turnover'],trace['fees']])
        np.testing.assert_array_equal(actual[positions[i]:positions[i+1]],fresh)
        row={'year':year,'start':str(rt.trade_dates[start]),'metrics':summarize(trace,year)}
        assert row==result['paths'][i];fresh_rows.append(row)
    assert aggregate(fresh_rows)==result['summary']
    assert file_sha256(parent)==source_sha and file_sha256(parent.with_suffix('.npz'))==trace_sha
    atomic_write_json(out/'complete.json',{'state':'pass_real_native_cache_parity','year':year,'paths':48,'reused':12,'new_in_cache':36,'fresh_independent_replays':48,
        'all_seven_trace_columns_exact':True,'all_path_metrics_exact':True,'summary_exact':True,'not_search_result':True,'holdout_read':False,'seconds':time.monotonic()-began,
        'parent':str(parent),'parent_sha256':source_sha,'parent_trace_sha256':trace_sha,'driver_sha256':file_sha256(__file__),'cache_sha256':file_sha256(Path(__file__).with_name('cache.py'))})
    print({'state':'pass_real_native_cache_parity','seconds':time.monotonic()-began},flush=True)

if __name__=='__main__':main()
