"""Independent fixed-default reference, never candidate generation or selection."""
import json,time
from pathlib import Path
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from ai.supervised.multihorizon_search import load_forecasts
from utils.atomic_file import atomic_write_json,file_sha256
from .cache import Evaluator

def main():
    require_guarded_job();began=time.monotonic();here=Path(__file__).resolve().parent
    c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text());root=Path(c['output'])
    folder=root/'default_reference_precompute';folder.mkdir(exist_ok=False)
    probe=json.loads((root/'cache_native_probe/complete.json').read_text());assert probe['state']=='pass_real_native_cache_parity'
    assert probe['cache_sha256']==file_sha256(here/'cache.py')
    original=json.loads((root/'stage12/identity.json').read_text())
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    starts=json.loads((root/'start_indices.json').read_text())
    identity={'scope':'fixed default reference only; no candidate selection, no holdout','parameters':c['baseline'],
        'protocol_sha256':file_sha256(Path('research/topk_multistart_20261109/protocol.json')),'starts_sha256':file_sha256(root/'start_indices.json'),
        'sources':{str(p):file_sha256(p) for p in (Path(__file__),here/'cache.py')},'original_identity_sha256':file_sha256(root/'stage12/identity.json')}
    atomic_write_json(folder/'identity.json',identity)
    rt,cube,provenance=load_forecasts(Path(c['parent']),'oof');assert provenance==starts['models']
    np.testing.assert_array_equal(rt.trade_dates.astype(str),starts['dates'])
    evaluator=Evaluator(rt,cube,c,starts,file_sha256(folder/'identity.json'));results={}
    for stage in (48,'all'):
        result=evaluator.evaluate(c['baseline'],stage)
        assert result['parameters']==c['baseline']
        results[str(stage)]={'summary':result['summary'],'paths':len(result['paths']),'trace_sha256':result['trace_sha256']}
        atomic_write_json(folder/'progress.json',{'state':'running','finished_stages':results,'seconds':time.monotonic()-began})
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    for path,sha in identity['sources'].items():assert file_sha256(path)==sha
    atomic_write_json(folder/'complete.json',{'state':'fixed_default_reference_complete_not_a_winner','results':results,'seconds':time.monotonic()-began,'identity_sha256':file_sha256(folder/'identity.json')})

if __name__=='__main__':main()
