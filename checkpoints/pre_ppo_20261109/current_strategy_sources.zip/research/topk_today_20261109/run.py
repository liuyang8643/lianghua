import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import concurrent.futures,dataclasses,gc,json,time,urllib.request,sys,csv
from pathlib import Path
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256

R=Path('artifacts/research/topk_today_20261109');P=Path('artifacts/research/multihorizon_pre_live_20261108_volume_fix');Y=Path('artifacts/research/new_topk_ytd_20261106');S=Path('artifacts/research/multihorizon_2026_explain_20261107_reference_complete')
read=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
TODAY='2026-11-09'

def fetch(batch):
    offset,codes=batch;symbols=[c.split('.')[1].lower()+c.split('.')[0] for c in codes]
    url='https://qt.gtimg.cn/q='+','.join(symbols)
    for attempt in range(3):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'});raw=urllib.request.urlopen(req,timeout=15).read();break
        except Exception:
            if attempt==2:raise
            time.sleep(1)
    (R/'quotes'/f'{offset:05d}.raw').write_bytes(raw);parsed={}
    for line in raw.decode('gbk').split(';'):
        if '=' not in line or '"' not in line:continue
        symbol=line.split('=')[0].strip().split('_')[-1];v=line.split('"')[1].split('~')
        if symbol not in symbols or len(v)<53:continue
        code=symbol[2:]+'.'+symbol[:2].upper();assert v[2]==code.split('.')[0]
        parsed[code]={'name':v[1],'open':float(v[5] or 0),'last':float(v[3] or 0),'reference':float(v[4] or 0),'timestamp':v[30],'volume':float(v[6] or 0),'limit_up':float(v[47] or 0),'limit_down':float(v[48] or 0)}
    return parsed

def main():
    from scripts.run_research_guarded import require_guarded_job
    require_guarded_job();began=time.monotonic();R.mkdir(exist_ok=True,parents=True);(R/'quotes').mkdir(exist_ok=True)
    codes=np.load(Y/'features/codes.npy').astype(str).tolist()
    if (R/'quotes.json').exists():quotes=read(R/'quotes.json')
    else:
        quotes={}
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            for part in pool.map(fetch,[(i,codes[i:i+80]) for i in range(0,len(codes),80)]):quotes.update(part)
        atomic_write_json(R/'quotes.json',quotes)
    valid={c:q for c,q in quotes.items() if q['timestamp'].startswith(TODAY.replace('-','')) and q['open']>0 and q['last']>0 and q['volume']>0}
    assert len(valid)>4500,'incomplete current-date quote universe'
    assert all(q['timestamp'][8:12]>='1500' for q in valid.values()),'not closing snapshot'
    print({'stage':'quotes','requested':len(codes),'same_day_open_close':len(valid)},flush=True)
    vendor=Path('artifacts/research/topk_multistart_20261109/report_dependencies');vm=read(vendor.parent/'report_dependencies_manifest.json')
    for name,sha in vm['files'].items():assert file_sha256(vendor/name)==sha
    sys.path.insert(0,str(vendor.resolve()))
    from offline_data import load_runtime_slice
    from offline_data.contracts import RuntimeSlice
    from ai.supervised.dated_features import source_inputs
    from ai.supervised.feature_data import materialize_factor_values,rank_features
    from ai.supervised.multihorizon_model import predict
    from env.legality import investment_universe_mask,evaluate_buy_legality_mask
    import lightgbm as lgb
    active=read(Y/'active_data.json');cfg=read(Y/'protocol.json');base=load_runtime_slice(active['runtime_path'],'2026-11-06','2026-11-06',preload_rows=100001,cache_dir=Path(cfg['feature_runtime_cache']))
    assert str(base.trade_dates[-1])=='2026-11-06';assert list(base.stock_codes)==codes
    dates=np.r_[base.trade_dates,np.array([TODAY],dtype='datetime64[D]')];fields={};fd=R/'runtime_fields';fd.mkdir(exist_ok=True)
    for name,a in base.data.items():
        if a.ndim==1:fields[name]=a;continue
        path=fd/(name+'.npy');v=np.lib.format.open_memmap(path,mode='w+',dtype=a.dtype,shape=(len(dates),len(codes)));v[:-1]=a;v[-1]=a[-1]
        if name in ('high','low','close','amount','volume'):v[-1]=np.nan
        elif name=='open':v[-1]=[valid.get(c,{}).get('open',np.nan) for c in codes]
        elif name=='preClose':v[-1]=[valid.get(c,{}).get('reference',np.nan) for c in codes]
        elif name=='listing_age':v[-1]=np.where(a[-1]>=0,a[-1]+1,-1)
        elif name=='st_mask':v[-1]=['ST' in valid[c]['name'].upper() if c in valid else bool(a[-1,j]) for j,c in enumerate(codes)]
        v.flush();del v;fields[name]=np.load(path,mmap_mode='r')
    identity={'scope':'Paper-only append: current open/reference/ST quote fields; T high/low/close/volume/amount all NaN during factor construction. Frozen local security universe and known financial/capital/industry/dividend/monthly snapshots carried; not a newly refreshed event feed. Closing quotes used only after predictions.','base_runtime_sha256':active['runtime_sha256'],'quotes_sha256':file_sha256(R/'quotes.json'),'date':TODAY,'source_sha256':file_sha256(__file__)}
    atomic_write_json(R/'input_identity.json',identity)
    manifest=dataclasses.replace(base.manifest,source_path=str(R/'input_identity.json'),source_sha256=file_sha256(R/'input_identity.json'),source_size=(R/'input_identity.json').stat().st_size,requested_start='2026-11-06',requested_end=TODAY,loaded_end=TODAY)
    rt=RuntimeSlice(stock_codes=base.stock_codes,trade_dates=dates,data=fields,decision_start=len(dates)-2,decision_stop=len(dates),manifest=manifest)
    for field in ('high','low','close','volume','amount'):assert np.isnan(rt.field(field)[-1]).all()
    eligible=investment_universe_mask(rt.field('open')[-2:],rt.field('listing_age')[-2:],rt.field('st_mask')[-2:],rt.field('delisted_mask')[-2:])
    np.testing.assert_array_equal(eligible[0],np.load(Y/'features/eligible.npy')[-1])
    meta=read(P/'models/final/model.json');names=meta['feature_names'];reference=read(Y/'features/inventory.json');features=R/'features';features.mkdir(exist_ok=True);inventory={}
    industry,dividends,sourcefiles=source_inputs(S,P);bound={x['name'] for x in read(P/'bound_preflight.json')['results']}
    monthly=Y/'monthly/monthly.npz';monthly_done=read(Y/'monthly/complete.json');assert file_sha256(monthly)==monthly_done['output_sha256']
    def save(name,raw):
        binary=reference[name]['normalization']=='binary';v=rank_features(np.asarray(raw)[-2:],eligible,binary)
        np.testing.assert_array_equal(v[0],np.load(reference[name]['path'],mmap_mode='r')[-1],err_msg='historical feature changed:'+name)
        np.save(features/(name+'.npy'),v);inventory[name]={'path':str(features/(name+'.npy')),'sha256':file_sha256(features/(name+'.npy'))}
        atomic_write_json(R/'status.json',{'stage':'features','complete':len(inventory),'total':len(names),'last':name})
        if len(inventory)%20==0:print({'stage':'features','count':len(inventory)},flush=True)
    with np.load(monthly) as payload:materialize_factor_values(rt,set(names),save,bound_names=bound,industry_history=industry,dividend_events=dividends,monthly_payload=payload)
    atomic_write_json(features/'inventory.json',inventory)
    modelpath=P/'models/final/model.txt';model=lgb.Booster(model_file=str(modelpath));pred=predict(model,[np.load(inventory[n]['path'],mmap_mode='r') for n in names],eligible,np.arange(2),meta['horizons'])
    np.testing.assert_allclose(pred[0],np.load(Y/'features/predictions.npy',mmap_mode='r')[-1],atol=1e-12,rtol=1e-12,equal_nan=True)
    pool=eligible&np.isfinite(pred).all(axis=2);ranks=np.stack([rank_features(pred[:,:,k],pool) for k in range(5)],axis=2);scores=(ranks*np.array([0,0,.3,0,.7])).sum(axis=2)[-1]
    legal=evaluate_buy_legality_mask(decision_date=TODAY,stock_codes=codes,listing_age=rt.field('listing_age')[-1],open_prices=rt.field('open')[-1],preclose_prices=rt.field('preClose')[-1],issue_prices=np.full(len(codes),np.nan),st_mask=rt.field('st_mask')[-1],delisted_mask=rt.field('delisted_mask')[-1])
    # Match the rank-buffer account's optional near-limit-up protection as well.
    from env.legality import evaluate_trade_legality
    protection=evaluate_trade_legality(decision_date=TODAY,stock_codes=codes,listing_age=rt.field('listing_age')[-1],open_prices=rt.field('open')[-1],preclose_prices=rt.field('preClose')[-1],issue_prices=np.full(len(codes),np.nan),st_mask=rt.field('st_mask')[-1],delisted_mask=rt.field('delisted_mask')[-1],limit_up_protection=True)
    buyable=pool[-1]&legal&protection.buy_allowed;order=np.argsort(-np.where(buyable,scores,-np.inf),kind='stable');chosen=order[buyable[order]][:30];assert len(chosen)==30
    result=[]
    for j in chosen:
        q=valid[codes[j]];ret=q['last']/q['open']-1;result.append({'code':codes[j],'name':q['name'],'open':q['open'],'close':q['last'],'return':ret,'account_weight':.025,'account_contribution':.025*ret,'score':float(scores[j]),'quote_timestamp':q['timestamp']})
    np.save(features/'predictions.npy',pred);np.save(features/'scores.npy',scores)
    with (R/'selected.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(result[0]));w.writeheader();w.writerows(result)
    atomic_write_json(R/'result.json',{'state':'complete','date':TODAY,'start':'fresh_cash_today_open','stock_count':30,'stock_weight':.75,'cash_weight':.25,'gross_account_return':sum(r['account_contribution'] for r in result),'basket_equal_weight_return':float(np.mean([r['return'] for r in result])),'stocks':result,'fee_and_lot_rounding':'Excluded as requested simple open-to-close calculation; weights are nominal2.5% each. No orders sent.','data_scope':identity['scope'],'historical_feature_and_prediction_parity':True,'model_sha256':file_sha256(modelpath),'input_identity_sha256':file_sha256(R/'input_identity.json'),'seconds':time.monotonic()-began})
    print({'state':'complete','return':sum(r['account_contribution'] for r in result),'seconds':time.monotonic()-began},flush=True)

if __name__=='__main__':main()
