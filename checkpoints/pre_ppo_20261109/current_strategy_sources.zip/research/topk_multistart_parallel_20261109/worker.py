"""Process-local frozen OOF evaluator; candidate decisions stay in parent."""
import os
for _name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[_name]='1'
import gc,hashlib,json,time
from pathlib import Path
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from ai.supervised.multihorizon_search import load_forecasts
from ai.supervised.portfolio import PreparedModelPortfolio
from research.topk_multistart_20261109.search import save_trial
from research.topk_multistart_20261109.selection import key
from utils.atomic_file import file_sha256

STATE=None

def initialize(output):
    global STATE
    require_guarded_job();began=time.monotonic()
    c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text());root=Path(c['output'])
    starts=json.loads((root/'start_indices.json').read_text());rt,cube,models=load_forecasts(Path(c['parent']),'oof')
    assert models==starts['models'];np.testing.assert_array_equal(rt.trade_dates.astype(str),starts['dates'])
    STATE=(c,starts,rt,cube,Path(output),file_sha256(Path('research/topk_multistart_20261109/protocol.json')))
    print({'worker_pid':os.getpid(),'loaded_seconds':time.monotonic()-began},flush=True)

def evaluate(parameters):
    assert STATE is not None
    c,starts,rt,cube,output,protocol_sha=STATE
    scores=np.sum(cube*(np.asarray(parameters['weights'])/10),axis=2)
    prepared=PreparedModelPortfolio.from_scores(rt,scores,initial_cash=c['execution']['initial_cash'],source_hash=hashlib.sha256((protocol_sha+key(parameters)).encode()).hexdigest(),split='oof_multistart')
    record=save_trial(output,parameters,12,prepared,starts,c['scored_years'])
    del prepared,scores;gc.collect()
    return {'pid':os.getpid(),'key':key(parameters),'record':record}
