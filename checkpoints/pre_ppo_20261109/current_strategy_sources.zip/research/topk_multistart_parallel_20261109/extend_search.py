"""Continue a terminal safety-capped stage12 with the exact same GA trajectory."""
import os
for _name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[_name]='1'
import concurrent.futures,json,multiprocessing,time
from pathlib import Path
from scripts.run_research_guarded import require_guarded_job
from utils.atomic_file import atomic_write_json,file_sha256
from research.topk_multistart_20261109.selection import key
from research.topk_multistart_refinement_20261109.cache import digest,read_trial
from research.topk_multistart_refinement_20261109.recover_stage12 import replay_ga
from . import worker

def main():
    import psutil
    require_guarded_job();began=time.monotonic();root=Path('artifacts/research/topk_multistart_20261109');stage=root/'stage12'
    parent_path=stage/'complete.json';parent=json.loads(parent_path.read_text())
    assert parent['state']=='stage_complete_not_final_winner' and parent['stop_reason']=='safety_generation_limit'
    assert not (root/'winner_lock.json').exists(),'never extend after final selection'
    own=psutil.Process();owned={own.pid,*[p.pid for p in own.parents()]}
    modules={'research.topk_multistart_20261109.search','research.topk_multistart_refinement_20261109.recover_stage12',
        'research.topk_multistart_parallel_20261109.search','research.topk_multistart_parallel_20261109.extend_search'}
    for process in psutil.process_iter(['pid','cmdline']):
        if process.pid in owned:continue
        cmd=process.info['cmdline'] or []
        if any(cmd[i]=='-m' and cmd[i+1] in modules for i in range(len(cmd)-1)):raise RuntimeError(f'other search remains live: {process.pid}')
    original=json.loads((stage/'identity.json').read_text())
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    audit=root/f"ga_replay_audit_{parent['generations']:03d}.json"
    verified=json.loads(audit.read_text());assert verified['state']=='pass_saved_ga_history_exact' and verified['generations'][-1]==parent['generations']
    c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text())
    prior_limit=parent['generations'];new_limit=prior_limit+60
    c['ga']['generation_safety_limit']=new_limit
    folder=stage/'budget_extensions'/f'after_{prior_limit:03d}';folder.mkdir(parents=True,exist_ok=True)
    identity={'kind':'safety_budget_extension_only','old_generations':prior_limit,'new_limit':new_limit,'patience_unchanged':c['ga']['patience'],
        'parent_complete_sha256':file_sha256(parent_path),'parent_audit_sha256':file_sha256(audit),'protocol_sha256':file_sha256(Path('research/topk_multistart_20261109/protocol.json')),
        'sources':{str(p):file_sha256(p) for p in [Path(__file__),Path(worker.__file__),Path('research/topk_multistart_refinement_20261109/recover_stage12.py')]},
        'semantics':'same seed/population/mutation/fitness/candidate order; reconstruct historical generations from verified cache then continue until patience or next safety boundary'}
    if (folder/'identity.json').exists():assert json.loads((folder/'identity.json').read_text())==identity
    else:
        (folder/'parent_complete.json').write_bytes(parent_path.read_bytes());atomic_write_json(folder/'identity.json',identity)
    def evaluate(p):return read_trial(stage/'trials'/f'{digest(p)}.json')
    def on_generation(g,s):
        path=stage/f'generation_{g:03d}.json'
        if path.exists():assert json.loads(path.read_text())==json.loads(json.dumps(s)),'historical generation changed'
        else:atomic_write_json(path,s)
        if g>=prior_limit:
            atomic_write_json(root/'status.json',{'state':'stage12_exact_budget_extension','generation':g,'trials':s['trials'],'stale':s['stale'],'safety_limit':new_limit})
            print({'generation':g,'trials':s['trials'],'stale':s['stale']},flush=True)
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('spawn'),initializer=worker.initialize,initargs=(str(root),)) as pool:
        def prepare(population):
            missing=[p for p in population if not (stage/'trials'/f'{digest(p)}.json').exists()]
            for p,result in zip(missing,pool.map(worker.evaluate,missing)):
                assert result['key']==key(p) and evaluate(p)['parameters']==p
        records,generations,stale=replay_ga(c,evaluate,on_generation,prepare_population=prepare)
    assert generations>prior_limit
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    for path,sha in identity['sources'].items():assert file_sha256(path)==sha
    ranked=sorted(records.values(),key=lambda r:r['summary']['typical'],reverse=True);shortlist=[r['parameters'] for r in ranked[:12]]
    for r in sorted(records.values(),key=lambda r:r['summary']['tail'],reverse=True):
        if r['summary']['typical']>=ranked[0]['summary']['typical']-.05 and r['parameters'] not in shortlist:shortlist.append(r['parameters'])
        if len(shortlist)>=24:break
    if c['baseline'] not in shortlist:shortlist.append(c['baseline'])
    result={'state':'stage_complete_not_final_winner','generations':generations,'trials':len(records),'stop_reason':'patience' if stale>=c['ga']['patience'] else 'safety_generation_limit',
        'shortlist':shortlist,'seconds':time.monotonic()-began,'extension_identity_sha256':file_sha256(folder/'identity.json'),'extension_parent':str(folder/'parent_complete.json'),'time_scope':'this extension only; previous work preserved separately'}
    atomic_write_json(folder/'complete.json',result)
    atomic_write_json(parent_path,result)

if __name__=='__main__':main()
