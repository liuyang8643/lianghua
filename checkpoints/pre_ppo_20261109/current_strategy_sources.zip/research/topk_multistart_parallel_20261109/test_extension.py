import hashlib,json,unittest
from pathlib import Path
from research.topk_multistart_refinement_20261109.recover_stage12 import replay_ga
from research.topk_multistart_20261109.selection import key,aggregate

class Extension(unittest.TestCase):
    def test_budget_change_preserves_prefix_and_rng(self):
        c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text());c['ga']['population']=8;c['ga']['generation_safety_limit']=2
        cache={}
        def evaluate(p):
            k=key(p)
            if k not in cache:
                v=int(hashlib.sha256(k.encode()).hexdigest()[:8],16)/2**32
                rows=[{'year':2012,'start':str(i),'metrics':{'calmar':v+i/100,'mean_gross_turnover':.1}} for i in range(3)]
                cache[k]={'parameters':p,'paths':rows,'summary':aggregate(rows)}
            return cache[k]
        first=[];replay_ga(c,evaluate,lambda g,s:first.append(json.loads(json.dumps(s))))
        c['ga']['generation_safety_limit']=4;second=[]
        replay_ga(c,evaluate,lambda g,s:second.append(json.loads(json.dumps(s))))
        self.assertEqual(first,second[:2]);self.assertEqual(len(second),4)
        self.assertGreater(second[-1]['trials'],first[-1]['trials'])

if __name__=='__main__':unittest.main()
