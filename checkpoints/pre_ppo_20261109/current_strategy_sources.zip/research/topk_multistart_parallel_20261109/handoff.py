"""Explicit planned handoff: terminate only the verified original private Job."""
import argparse,ctypes as ct,json,shutil,time
from ctypes import wintypes as wt
from pathlib import Path
import psutil
from scripts.run_research_guarded import win_api,checked,JOB_ENV
from utils.atomic_file import atomic_write_json,file_sha256

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stop',action='store_true');args=parser.parse_args()
    root=Path('artifacts/research/topk_multistart_20261109');folder=root/'parallel_migration';folder.mkdir(exist_ok=True)
    if (folder/'stopped.json').exists():raise RuntimeError('handoff already recorded; do not terminate again')
    proof=json.loads((root/'parallel_probe/complete.json').read_text());assert proof['state']=='pass_four_process_native_parity' and proof['conservative_speed_ratio']>1
    latest=sorted((root/'stage12').glob('generation_*.json'))[-1];generation=int(latest.stem.rsplit('_',1)[1])
    audit=json.loads((root/f'ga_replay_audit_{generation:03d}.json').read_text());assert audit['state']=='pass_saved_ga_history_exact'
    assert audit['inputs'][str(latest)]==file_sha256(latest)
    original=json.loads((root/'stage12/identity.json').read_text())
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    events=[json.loads(x) for x in (root/'search12_logs/guard.jsonl').read_text().splitlines()];event=next(x for x in events if x['event']=='started')
    assert not any(x['event']=='child_exit' for x in events),'original already terminal'
    parent=psutil.Process(event['pid']);birth=parent.create_time();cmd=parent.cmdline()
    assert abs(birth-event['time'])<5 and cmd[-2:]==['-m','research.topk_multistart_20261109.search']
    assert Path(parent.cwd()).resolve()==Path.cwd().resolve()
    jobname=parent.environ()[JOB_ENV];assert jobname.startswith('Local\\WBRResearchGuard-')
    api=win_api();handle=checked(api.OpenJobObjectW(0x0004|0x0008,False,jobname))
    class IdList(ct.Structure):
        _fields_=[('assigned',wt.DWORD),('listed',wt.DWORD),('ids',ct.c_size_t*128)]
    try:
        info=IdList();checked(api.QueryInformationJobObject(handle,3,ct.byref(info),ct.sizeof(info),None))
        assert info.assigned==info.listed and 0<info.listed<=128
        members=list(info.ids[:info.listed]);descendants={parent.pid,*[p.pid for p in parent.children(recursive=True)]}
        assert set(members)<=descendants and parent.pid in members
        rows=[]
        for pid in members:
            process=psutil.Process(pid);rows.append({'pid':pid,'birth':process.create_time(),'command':process.cmdline()})
        assert psutil.virtual_memory().available>=12*2**30
        record={'state':'verified_ready_for_parallel_handoff','job_members':rows,'job_name':jobname,'checkpoint':str(latest),'checkpoint_sha256':file_sha256(latest),
            'ga_audit_sha256':file_sha256(root/f'ga_replay_audit_{generation:03d}.json'),'parallel_proof_sha256':file_sha256(root/'parallel_probe/complete.json'),
            'reason':'four-process actual native parity passed; preserve exact GA and completed trial cache, discard at most in-flight incomplete trial',
            'time_ns':time.time_ns(),'memory_available':psutil.virtual_memory().available}
        atomic_write_json(folder/'ready.json',record)
        print({'state':record['state'],'checkpoint_generation':generation,'owned_members':members,'stop_requested':args.stop},flush=True)
        if not args.stop:return
        # All identity and ownership checks above precede any process mutation.
        checked(api.TerminateJobObject(handle,76))
        deadline=time.monotonic()+10
        while time.monotonic()<deadline:
            alive=[r for r in rows if psutil.pid_exists(r['pid']) and psutil.Process(r['pid']).create_time()==r['birth']]
            if not alive:break
            time.sleep(.05)
        assert not alive,'owned original process did not exit'
        orphan=folder/'orphaned_inflight';orphan.mkdir(exist_ok=True);orphans=[]
        for path in (root/'stage12/trials').glob('*.npz'):
            if path.with_suffix('.json').exists():continue
            saved=orphan/path.name;shutil.copy2(path,saved);orphans.append({'path':str(path),'saved':str(saved),'sha256':file_sha256(saved)})
        record.update(state='original_owned_job_stopped_for_parallel_handoff',orphaned_inflight=orphans,completed_trial_files=len(list((root/'stage12/trials').glob('*.json'))),stopped_time_ns=time.time_ns())
        atomic_write_json(folder/'stopped.json',record)
        print({'state':record['state'],'completed_trial_files':record['completed_trial_files'],'orphans':len(orphans)},flush=True)
    finally:checked(api.CloseHandle(handle))

if __name__=='__main__':main()
