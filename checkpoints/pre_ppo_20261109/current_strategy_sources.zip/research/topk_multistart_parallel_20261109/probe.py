"""Four actual parameter evaluations versus saved native serial traces."""
import os
for _name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[_name]='1'
import concurrent.futures,hashlib,json,multiprocessing,time
from pathlib import Path
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from utils.atomic_file import atomic_write_json,file_sha256
from research.topk_multistart_20261109.selection import key
from research.topk_multistart_refinement_20261109.cache import read_trial,digest
from . import worker

def main():
    require_guarded_job();began=time.monotonic();root=Path('artifacts/research/topk_multistart_20261109');out=root/'parallel_probe'
    if out.exists():raise RuntimeError('probe root exists; do not overwrite')
    out.mkdir();original=json.loads((root/'stage12/identity.json').read_text())
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    generation=json.loads((root/'stage12/generation_001.json').read_text());parameters=generation['population'][:4]
    identity={'scope':'bounded4candidate native OOF parallel parity/speed probe, no GA selection or holdout','parameters':parameters,'workers':4,
        'original_identity_sha256':file_sha256(root/'stage12/identity.json'),'source':{str(p):file_sha256(p) for p in Path(__file__).parent.glob('*.py')}}
    atomic_write_json(out/'identity.json',identity)
    results=[];pool_begin=time.monotonic()
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('spawn'),initializer=worker.initialize,initargs=(str(out),)) as pool:
        for value in pool.map(worker.evaluate,parameters):results.append(value)
    elapsed=time.monotonic()-pool_begin;comparisons=[]
    for parameter,result in zip(parameters,results):
        assert result['key']==key(parameter)
        oldpath=root/'stage12/trials'/f'{digest(parameter)}.json';newpath=out/'stage12/trials'/oldpath.name
        old=read_trial(oldpath);new=read_trial(newpath)
        assert old['parameters']==new['parameters']==parameter
        assert old['paths']==new['paths'];assert old['summary']==new['summary']
        with np.load(oldpath.with_suffix('.npz')) as a,np.load(newpath.with_suffix('.npz')) as b:
            assert set(a.files)==set(b.files)
            for name in a.files:np.testing.assert_array_equal(a[name],b[name])
        comparisons.append({'parameter':parameter,'serial_account_seconds':old['seconds'],'parallel_account_seconds':new['seconds'],'worker_pid':result['pid'],
            'serial_trace_sha256':old['trace_sha256'],'parallel_trace_sha256':new['trace_sha256'],'arrays_exact':True})
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    for path,sha in identity['source'].items():assert file_sha256(path)==sha
    saved_serial=sum(x['serial_account_seconds'] for x in comparisons)
    atomic_write_json(out/'complete.json',{'state':'pass_four_process_native_parity','comparisons':comparisons,'paths':480,'parallel_wall_including_startup':elapsed,
        'saved_serial_account_seconds_excluding_startup':saved_serial,'conservative_speed_ratio':saved_serial/elapsed,'distinct_workers':len({x['pid'] for x in results}),
        'source_identity_sha256':file_sha256(out/'identity.json'),'seconds':time.monotonic()-began,'search_process_unchanged':True})
    print({'state':'pass_four_process_native_parity','parallel_wall':elapsed,'serial_saved':saved_serial,'ratio':saved_serial/elapsed},flush=True)

if __name__=='__main__':main()
