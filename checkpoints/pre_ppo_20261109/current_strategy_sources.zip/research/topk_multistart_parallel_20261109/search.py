"""Same GA state machine, concurrent independent evaluations in ordered batches."""
import os
for _name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[_name]='1'
import concurrent.futures,json,multiprocessing,time
from pathlib import Path
from scripts.run_research_guarded import require_guarded_job
from utils.atomic_file import atomic_write_json,file_sha256
from research.topk_multistart_20261109.selection import key
from research.topk_multistart_refinement_20261109.cache import digest,read_trial
from research.topk_multistart_refinement_20261109.recover_stage12 import replay_ga
from . import worker

def main():
    import psutil
    require_guarded_job();began=time.monotonic();root=Path('artifacts/research/topk_multistart_20261109');stage=root/'stage12'
    own=psutil.Process();owned={own.pid,*[p.pid for p in own.parents()]}
    modules={'research.topk_multistart_20261109.search','research.topk_multistart_refinement_20261109.recover_stage12','research.topk_multistart_parallel_20261109.search'}
    for process in psutil.process_iter(['pid','cmdline']):
        if process.pid in owned:continue
        cmd=process.info['cmdline'] or []
        if any(cmd[i]=='-m' and cmd[i+1] in modules for i in range(len(cmd)-1)):raise RuntimeError(f'other search still live: {process.pid}')
    c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text())
    if (stage/'complete.json').exists():raise RuntimeError('completed stage is sealed')
    migration=json.loads((root/'parallel_migration/stopped.json').read_text());assert migration['state']=='original_owned_job_stopped_for_parallel_handoff'
    for row in migration['job_members']:
        if psutil.pid_exists(row['pid']):assert psutil.Process(row['pid']).create_time()!=row['birth'],'old member remains live'
    original=json.loads((stage/'identity.json').read_text())
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    proof=json.loads((root/'parallel_probe/complete.json').read_text());assert proof['state']=='pass_four_process_native_parity' and proof['distinct_workers']==4
    proof_identity=json.loads((root/'parallel_probe/identity.json').read_text())
    assert file_sha256(Path(worker.__file__))==proof_identity['source'][str(Path(worker.__file__).resolve())]
    identity={'kind':'same_experiment_parallel_execution_handoff','workers':4,'original_identity_sha256':file_sha256(stage/'identity.json'),
        'protocol_sha256':file_sha256(Path('research/topk_multistart_20261109/protocol.json')),'proof_sha256':file_sha256(root/'parallel_probe/complete.json'),
        'stopped_sha256':file_sha256(root/'parallel_migration/stopped.json'),'source':{str(p):file_sha256(p) for p in [Path(__file__),Path(worker.__file__),Path('research/topk_multistart_refinement_20261109/recover_stage12.py')]},
        'semantics':'parallelize only independent candidate execution; consume results in original population order; same random seed, scores and stopping rule'}
    receipt=root/'parallel_migration/identity.json'
    if receipt.exists():assert json.loads(receipt.read_text())==identity
    else:atomic_write_json(receipt,identity)
    completed=0
    def evaluate(p):return read_trial(stage/'trials'/f'{digest(p)}.json')
    def on_generation(g,s):
        nonlocal completed
        path=stage/f'generation_{g:03d}.json';normalized=json.loads(json.dumps(s))
        if path.exists():assert json.loads(path.read_text())==normalized,'historical generation changed'
        else:atomic_write_json(path,s)
        completed=g
        atomic_write_json(root/'status.json',{'state':'searching_parallel4','stage':12,'generation_completed':g,'trials':s['trials'],'stale':s['stale'],'elapsed':time.monotonic()-began})
        print({'generation_completed':g,'trials':s['trials'],'stale':s['stale'],'typical':s['winner']['summary']['typical'],'tail':s['winner']['summary']['tail']},flush=True)
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('spawn'),initializer=worker.initialize,initargs=(str(root),)) as pool:
        def prepare(population):
            missing=[p for p in population if not (stage/'trials'/f'{digest(p)}.json').exists()]
            # Cache availability has no effect on selection order or candidate generation.
            for p,result in zip(missing,pool.map(worker.evaluate,missing)):
                assert result['key']==key(p);record=evaluate(p);assert record['parameters']==p
                print({'finished_parameter':p,'worker_pid':result['pid'],'typical':record['summary']['typical'],'tail':record['summary']['tail']},flush=True)
        records,generations,stale=replay_ga(c,evaluate,on_generation,prepare_population=prepare)
    for path,sha in original['sources'].items():assert file_sha256(path)==sha
    for path,sha in identity['source'].items():assert file_sha256(path)==sha
    ranked=sorted(records.values(),key=lambda r:r['summary']['typical'],reverse=True);shortlist=[r['parameters'] for r in ranked[:12]]
    for r in sorted(records.values(),key=lambda r:r['summary']['tail'],reverse=True):
        if r['summary']['typical']>=ranked[0]['summary']['typical']-.05 and r['parameters'] not in shortlist:shortlist.append(r['parameters'])
        if len(shortlist)>=24:break
    if c['baseline'] not in shortlist:shortlist.append(c['baseline'])
    atomic_write_json(stage/'complete.json',{'state':'stage_complete_not_final_winner','generations':generations,'trials':len(records),'stop_reason':'patience' if stale>=c['ga']['patience'] else 'safety_generation_limit',
        'shortlist':shortlist,'seconds':time.monotonic()-began,'parallel_execution_identity_sha256':file_sha256(receipt),'time_scope':'this handoff only; original serial elapsed is separate and preserved'})
    atomic_write_json(root/'status.json',{'state':'stage12_complete_pending_stage48','trials':len(records)})

if __name__=='__main__':main()
