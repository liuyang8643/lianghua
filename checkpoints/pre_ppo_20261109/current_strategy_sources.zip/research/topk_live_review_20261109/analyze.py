import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import csv,gzip,json,sys,time
from pathlib import Path
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256
from research.topk_multistart_delivery_20261109.outer import locked_config,load_outer
from env.metrics import performance_from_log_rewards

OUT=Path('artifacts/research/topk_live_review_20261109')
OLD=Path('artifacts/research/topk_multistart_20261109')
read=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
def stats(v):
    x=np.asarray(v,float);x=x[np.isfinite(x)]
    return {'n':len(x),'mean':float(x.mean()),'p10':float(np.quantile(x,.1)),'median':float(np.median(x)),'p90':float(np.quantile(x,.9)),'p95':float(np.quantile(x,.95))} if len(x) else {'n':0}
def writecsv(path,rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    from scripts.run_research_guarded import require_guarded_job
    require_guarded_job();began=time.monotonic();OUT.mkdir(exist_ok=True,parents=True)
    c,lock,locksha=locked_config();rt,cube,provenance=load_outer(c)
    params={'default':c['baseline'],'selected':lock['parameters']};lookup={code:i for i,code in enumerate(rt.stock_codes)}
    accounts={n:read(OLD/'delivery/outer'/n/'daily_attribution.json') for n in params}
    dates=np.array([d['decision_date'] for d in accounts['default']]);np.testing.assert_array_equal(dates,[d['decision_date'] for d in accounts['selected']]);ri=np.array([rt.index_of(d) for d in dates])
    parent=Path(c['parent']);tail=Path('artifacts/research/new_topk_ytd_20261106');meta=read(parent/'models/final/model.json');names=meta['feature_names'];spec=read('artifacts/research/new_topk_monthly_explain_20261108/protocol.json');anchors=spec['anchors']
    dirs=[parent,tail];invs=[read(p/'features/inventory.json') for p in dirs];fd=[np.load(p/'features/dates.npy').astype(str) for p in dirs];maps=[{d:i for i,d in enumerate(a)} for a in fd]
    src=np.array([1 if d in maps[1] else 0 for d in dates]);rows=np.array([maps[s][d] for s,d in zip(src,dates)])
    columns=[]
    for inv in invs:
        block={}
        for name in anchors:
            assert file_sha256(inv[name]['path'])==inv[name]['sha256'];block[name]=np.load(inv[name]['path'],mmap_mode='r')
        columns.append(block)
    amount=rt.field('amount');has_industry='industry_id' in rt.data;industry=rt.field('industry_id') if has_industry else np.zeros(amount.shape,dtype=np.int8);result={'parameters':params,'provenance':provenance,'historical_industry_available':has_industry,'strategies':{}};dailyrows=[];tradeall=[]
    holdsets={};holdweights={}
    for name,p in params.items():
        days=accounts[name];daymap={d['decision_date']:d for d in days};liquidity=[];style=[];stockprofit={};holdsets[name]=[];holdweights[name]=[]
        with gzip.open(OLD/'delivery/outer'/name/'report/report_payload.json.gz','rt',encoding='utf8') as f:payload=json.load(f)
        for d,t in enumerate(days):
            held=[s for s in t['stocks'] if s['open_weight']>0];js=np.array([lookup[s['code']] for s in held]);w=np.array([s['open_weight'] for s in held]);wn=w/w.sum();heldmap={s['code']:float(v) for s,v in zip(held,wn)};holdsets[name].append(set(heldmap));holdweights[name].append(heldmap)
            ind=industry[ri[d],js];known=ind>0;ig=np.array([wn[ind==g].sum() for g in np.unique(ind[known])]);ik=ig/ig.sum() if ig.sum()>0 else np.array([])
            item={'strategy':name,'date':dates[d],'month':dates[d][:7],'count':len(held),'effective_stocks':float(1/(wn@wn)),'max_stock_nav_weight':float(w.max()),'industry_known_share':float(wn[known].sum()),'industry_count':len(ig),'effective_industries':float(1/(ik@ik)) if len(ik) else None,'max_industry_equity_weight':float(ig.max()) if len(ig) else None}
            for a in anchors:
                v=columns[src[d]][a][rows[d],js];ok=np.isfinite(v);den=wn[ok].sum();item[a+'_mean']=float(np.average(v[ok],weights=wn[ok])) if den else None;item[a+'_top20_share']=float(wn[ok&(v>=.8)].sum()/den) if den else None;item[a+'_coverage']=float(den)
            style.append(item);dailyrows.append(item)
            for s in t['stocks']:stockprofit[s['code']]=stockprofit.get(s['code'],0.)+s['net_pnl']
        for tr in payload['trade_log']:
            i=rt.index_of(tr['trade_date']);j=lookup[tr['code']];past=np.asarray(amount[i-20:i,j],float);past=past[np.isfinite(past)];adv=float(past.mean()) if len(past) else np.nan;today=float(amount[i,j]);nav=daymap[tr['trade_date']]['pretrade_nav'];value=float(tr['amount']);fraction=value/nav
            assert value>0 and tr['action'] in ('buy','sell')
            rec={'strategy':name,'date':tr['trade_date'],'side':tr['action'],'code':tr['code'],'notional':value,'nav_fraction':fraction,'day_amount':today,'adv20_prior':adv,'prior_observations':len(past),'participation_actual_adv20':value/adv if adv>0 else np.nan,'participation_per_1m_adv20':fraction*1e6/adv if adv>0 else np.nan}
            liquidity.append(rec);tradeall.append(rec)
        closed=payload['cleared_positions'];hp=[s['holding_days'] for s in closed];positive=sorted([v for v in stockprofit.values() if v>0],reverse=True)
        summary={'trade_count':len(liquidity),'holding_days_closed':stats(hp),'closed_under7_fraction':float(np.mean(np.asarray(hp)<7)),'unique_traded_stocks':len({x['code'] for x in liquidity}),'unique_held_stocks':len(stockprofit),'top10_share_positive_stock_pnl':float(sum(positive[:10])/sum(positive)),'liquidity':{k:stats([x[k] for x in liquidity]) for k in ('day_amount','adv20_prior','participation_actual_adv20','participation_per_1m_adv20')},'buy_liquidity':stats([x['adv20_prior'] for x in liquidity if x['side']=='buy']),'sell_liquidity':stats([x['adv20_prior'] for x in liquidity if x['side']=='sell']),'adv20_below_20m_fraction':float(np.mean([x['adv20_prior']<2e7 for x in liquidity])),'adv20_below_50m_fraction':float(np.mean([x['adv20_prior']<5e7 for x in liquidity])),'style':{k:stats([x[k] for x in style if x[k] is not None]) for k in style[0] if k not in ('strategy','date','month')},'yearly':{}}
        for year in sorted({d[:4] for d in dates}):
            ys=[x for x in style if x['date'].startswith(year)];yt=[x for x in liquidity if x['date'].startswith(year)]
            summary['yearly'][year]={'trade_adv20':stats([x['adv20_prior'] for x in yt]),'smallcap_share_mean':float(np.mean([x[anchors[0]+'_top20_share'] for x in ys])),'lowvol_share_mean':float(np.mean([x['LowResidualVol20_top20_share'] for x in ys]))}
        result['strategies'][name]=summary
    writecsv(OUT/'daily_styles.csv',dailyrows);writecsv(OUT/'trades_liquidity.csv',tradeall)
    correlations=[];fusioncorr=[];topoverlap=[]
    weights={n:np.asarray(p['weights'])/10 for n,p in params.items()}
    for i in ri:
        a=cube[i];a=a[np.isfinite(a).all(axis=1)];correlations.append(np.corrcoef(a.T));f={n:a@w for n,w in weights.items()};fusioncorr.append(np.corrcoef(f['default'],f['selected'])[0,1]);top={n:set(np.argsort(-v,kind='stable')[:40]) for n,v in f.items()};topoverlap.append(len(top['default']&top['selected'])/40)
    C=np.mean(correlations,axis=0)
    result['diversification']={'head_daily_rank_correlation_mean':C.tolist(),'correlation_adjusted_signal_count_diagnostic':{n:float(1/(w@C@w)) for n,w in weights.items()},'nominal_weight_effective_heads':{n:float(1/(w@w)) for n,w in weights.items()},'fused_score_correlation':stats(fusioncorr),'top40_prediction_overlap':stats(topoverlap),'actual_holdings_jaccard':stats([len(a&b)/len(a|b) for a,b in zip(holdsets['default'],holdsets['selected'])]),'actual_equity_weight_overlap':stats([sum(min(a.get(k,0),b.get(k,0)) for k in set(a)|set(b)) for a,b in zip(holdweights['default'],holdweights['selected'])])}
    atomic_write_json(OUT/'execution_style.json',result);print({'stage':'execution_style_complete'},flush=True)
    # Deterministic first/last decision date per calendar month, actual holdings union.
    months=np.array([d[:7] for d in dates]);sampledays=sorted({int(j) for m in np.unique(months) for j in (np.flatnonzero(months==m)[0],np.flatnonzero(months==m)[-1])})
    samples=[];sampleweights={n:[] for n in params};stock=[];dayids=[]
    for d in sampledays:
        js=sorted(lookup[k] for k in holdsets['default'][d]|holdsets['selected'][d]);samples.extend((src[d],rows[d],j) for j in js);stock.extend(js);dayids.extend([d]*len(js))
        for n in params:sampleweights[n].extend(holdweights[n][d].get(rt.stock_codes[j],0.) for j in js)
    samples=np.asarray(samples,int);x=np.empty((len(samples),len(names)+1));expected=np.full((len(samples),5),np.nan)
    base_rows=np.load(parent/'models/final/rows.npy');predmap={int(v):i for i,v in enumerate(base_rows)};preds=[np.load(parent/'models/final/predictions.npy',mmap_mode='r'),np.load(tail/'features/predictions.npy',mmap_mode='r')]
    for s in (0,1):
        take=samples[:,0]==s;rr=samples[take,1];jj=samples[take,2]
        if s==0:assert all(int(r) in predmap for r in rr)
        expected[take]=preds[s][np.array([predmap[int(r)] for r in rr]) if s==0 else rr,jj]
        for k,feature in enumerate(names):
            rec=invs[s][feature];assert file_sha256(rec['path'])==rec['sha256'];v=np.load(rec['path'],mmap_mode='r');x[take,k]=v[rr,jj]
    good=np.isfinite(expected).all(axis=1);x=x[good];expected=expected[good];dayids=np.asarray(dayids)[good]
    sampleweights={n:np.asarray(w)[good] for n,w in sampleweights.items()}
    vendor=OLD/'report_dependencies';vm=read(OLD/'report_dependencies_manifest.json')
    for p,sha in vm['files'].items():assert file_sha256(vendor/p)==sha
    sys.path.insert(0,str(vendor.resolve()));import lightgbm as lgb
    model=lgb.Booster(model_file=str(parent/'models/final/model.txt'));assert file_sha256(parent/'models/final/model.txt')==provenance['model_sha256']
    blended={n:np.zeros((len(x),len(names))) for n in params}
    for k,h in enumerate(meta['horizons']):
        x[:,-1]=k;sh=model.predict(x,pred_contrib=True,num_threads=4);raw=model.predict(x,raw_score=True,num_threads=4);np.testing.assert_allclose(sh.sum(axis=1),raw,atol=1e-10,rtol=1e-10);np.testing.assert_allclose(raw,expected[:,k],atol=1e-10,rtol=1e-10)
        for n in params:blended[n]+=weights[n][k]*sh[:,:len(names)]
        print({'stage':'shap','horizon':h,'samples':len(x)},flush=True)
    groups=spec['groups'];explain={}
    for n,b in blended.items():
        importance=np.sum(np.abs(b)*sampleweights[n][:,None],axis=0)/sampleweights[n].sum();total=float(importance.sum());gi={g:float(importance[[names.index(f) for f in fs]].sum()/total) for g,fs in groups.items()}
        order=np.argsort(-importance);explain[n]={'top_features':[{'name':names[i],'absolute_share':float(importance[i]/total)} for i in order[:20]],'group_absolute_share':gi,'effective_feature_count':float(1/np.sum((importance/total)**2)),'mean_sample_holdings_coverage':float(sampleweights[n].sum()/len(sampledays))}
    atomic_write_json(OUT/'explanations.json',{'days':len(sampledays),'samples':len(x),'sampling':'first and last decision day of each calendar month, actual-held union, no outcome-based selection','scope':'Weighted raw-prediction TreeSHAP, excludes task and bias; not exact nonlinear rank-fusion attribution or causal PNL. Same model, different horizons and actual holdings.','model_sha256':provenance['model_sha256'],'results':explain})
    # Fixed executed-path extra-cost sensitivity: no new portfolio/quantity simulation.
    launch=Path('artifacts/research/topk_launch_compare_20261109/outer');stress={};paths={n:{p.stem:p for p in (launch/n).glob('*.npz')} for n in params};assert set(paths['default'])==set(paths['selected'])
    for h in (252,504,756):
        score={n:{str(b):[] for b in (0,10,25,50)} for n in params}
        for stem in sorted(paths['default']):
            for n in params:
                with np.load(paths[n][stem]) as z:r=z['returns'][:h];turn=z['turnover'][:h]
                if len(r)<h:continue
                for b in (0,10,25,50):
                    v=r-turn*b/10000;assert np.all(v>-1);m=performance_from_log_rewards(np.log1p(v)).as_dict();score[n][str(b)].append(m['calmar'])
        stress[str(h)]={str(b):{'pairs':len(score['default'][str(b)]),'default_calmar_median':float(np.median(score['default'][str(b)])),'selected_calmar_median':float(np.median(score['selected'][str(b)])),'selected_calmar_win_fraction':float(np.mean(np.asarray(score['selected'][str(b)])>score['default'][str(b)]))} for b in (0,10,25,50)}
    atomic_write_json(OUT/'cost_sensitivity.json',{'scope':'Subtract extra bps times daily gross turnover from fixed saved returns. Holdings/fills/quantities remain fixed; not a rerun with endogenous cash/market impact or an auction-capacity guarantee. Existing2500ppm slippage retained; bps here are additional per side.','results':stress})
    assert file_sha256(OLD/'winner_lock.json')==locksha
    atomic_write_json(OUT/'complete.json',{'state':'complete','seconds':time.monotonic()-began,'lock_sha256':locksha,'source_sha256':file_sha256(__file__),'outputs':{p.name:file_sha256(p) for p in OUT.iterdir() if p.is_file() and p.name!='complete.json'},'no_training':True,'no_reselection':True,'no_deployment':True})
    print({'state':'complete','seconds':time.monotonic()-began},flush=True)

if __name__=='__main__':main()
