"""Frozen strategies: liquidity, styles, explanations and execution sensitivity."""
