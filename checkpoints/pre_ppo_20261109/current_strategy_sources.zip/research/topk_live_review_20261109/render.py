import csv,html,json
from pathlib import Path
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256

R=Path('artifacts/research/topk_live_review_20261109')
read=lambda p:json.loads(p.read_text(encoding='utf8'))
def table(head,rows):
    e=lambda x:html.escape(str(x))
    return '<table><tr>'+''.join('<th>'+e(x)+'</th>' for x in head)+'</tr>'+''.join('<tr>'+''.join('<td>'+e(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</table>'
def main():
    complete=read(R/'complete.json');assert complete['state']=='complete'
    for n,sha in complete['outputs'].items():assert file_sha256(R/n)==sha
    assert file_sha256('research/topk_live_review_20261109/analyze.py')==complete['source_sha256']
    x=read(R/'execution_style.json');s=x['strategies'];e=read(R/'explanations.json');cost=read(R/'cost_sensitivity.json')
    # Independently verify saved trade aggregation and its complete sample count.
    with (R/'trades_liquidity.csv').open(encoding='utf-8-sig',newline='') as f:trades=list(csv.DictReader(f))
    for n,v in s.items():
        chosen=[t for t in trades if t['strategy']==n];assert len(chosen)==v['trade_count']
        for field in v['liquidity']:
            a=np.asarray([float(t[field]) for t in chosen]);a=a[np.isfinite(a)]
            for key,val in [('mean',a.mean()),('median',np.median(a)),('p10',np.quantile(a,.1)),('p95',np.quantile(a,.95))]:np.testing.assert_allclose(val,v['liquidity'][field][key],atol=1e-9,rtol=1e-12)
        shares=e['results'][n]['group_absolute_share'];np.testing.assert_allclose(sum(shares.values()),1,atol=1e-12)
    old=Path('artifacts/research/topk_multistart_20261109');assert file_sha256(old/'winner_lock.json')==complete['lock_sha256']
    d=read(Path('configs/default_supervised_strategy.json'));manifest=read(Path(d['bundle'])/'manifest.json')
    assert file_sha256(Path(d['bundle'])/'manifest.json')==d['manifest_sha256'];assert manifest['parameters']=={k:v for k,v in x['parameters']['default'].items() if k!='weights'}
    rows=[]
    for label,fn,fmt in [
        ('日均实际持股数',lambda v:v['style']['count']['mean'],'.2f'),
        ('有效持股数（权重HHI倒数）',lambda v:v['style']['effective_stocks']['mean'],'.2f'),
        ('已清仓持仓天数均值',lambda v:v['holding_days_closed']['mean'],'.2f'),
        ('已清仓持仓天数中位数',lambda v:v['holding_days_closed']['median'],'.0f'),
        ('7日内清仓比例',lambda v:v['closed_under7_fraction'],'.2%'),
        ('成交当日成交额均值（万元）',lambda v:v['liquidity']['day_amount']['mean']/1e4,'.0f'),
        ('成交当日成交额中位数（万元）',lambda v:v['liquidity']['day_amount']['median']/1e4,'.0f'),
        ('交易前20日成交额中位数（万元）',lambda v:v['liquidity']['adv20_prior']['median']/1e4,'.0f'),
        ('交易前20日成交额P10（万元）',lambda v:v['liquidity']['adv20_prior']['p10']/1e4,'.0f'),
        ('过去20日成交额不足2000万元的交易比例',lambda v:v['adv20_below_20m_fraction'],'.2%'),
        ('百万NAV订单/历史全日成交额P95',lambda v:v['liquidity']['participation_per_1m_adv20']['p95'],'.3%'),
        ('最小市值20%股票的平均持仓占比',lambda v:v['style']['Optimized__TrueMarketCap_top20_share']['mean'],'.2%'),
        ('低成交额因子前20%股票的平均持仓占比',lambda v:v['style']['AmountBasedSmallCap5_top20_share']['mean'],'.2%'),
        ('低残差波动前20%股票的平均持仓占比',lambda v:v['style']['LowResidualVol20_top20_share']['mean'],'.2%'),
        ('前10大盈利股占所有正盈利股利润比例',lambda v:v['top10_share_positive_stock_pnl'],'.2%')]:rows.append([label,*[format(fn(s[n]),fmt) for n in ('default','selected')]])
    groups=[[g,*[f"{e['results'][n]['group_absolute_share'][g]:.2%}" for n in ('default','selected')]] for g in e['results']['default']['group_absolute_share']]
    years=[[year,*[f"{s[n]['yearly'][year]['smallcap_share_mean']:.1%}" for n in ('default','selected')],*[f"{s[n]['yearly'][year]['trade_adv20']['median']/1e4:.0f}" for n in ('default','selected')]] for year in s['default']['yearly']]
    stress=[[h,b,v['pairs'],f"{v['default_calmar_median']:.3f}",f"{v['selected_calmar_median']:.3f}",f"{v['selected_calmar_win_fraction']:.1%}"] for h,sc in cost['results'].items() for b,v in sc.items()]
    div=x['diversification'];corr=div['head_daily_rank_correlation_mean'];corrtable=[[h,*[f'{v:.3f}' for v in row]] for h,row in zip([3,7,15,30,60],corr)]
    multi=read(R/'monthly_start_summary.json');assert multi['starts_per_strategy']==46
    assert file_sha256('research/topk_live_review_20261109/multistart.py')==multi['source_sha256']
    for name in ('default','selected'):
        paths=list((R/'monthly_starts').glob(name+'_*.json'));assert len(paths)==46
        for path in paths:
            v=read(path);assert v['native_full_path_exact'] is True
            original=Path('artifacts/research/topk_launch_compare_20261109/outer')/name/f"{v['start_index']:05d}.npz"
            assert file_sha256(original)==v['original_trace_sha256']
    multirows=[]
    for label,key,scale,fmt in [('各账户平均持股数的中位数','mean_holding_count',1,'.2f'),('各账户小市值暴露均值的中位数','mean_smallcap_share',1,'.2%'),('各账户成交前20日成交额中位数的中位数/万元','trade_adv20_median',1e-4,'.0f'),('各账户成交额P10的中位数/万元','trade_adv20_p10',1e-4,'.0f'),('各账户百万NAV订单参与率P95的中位数','participation_per1m_p95',1,'.3%')]:
        multirows.append([label,*[format(multi['metrics'][n][key]['median']*scale,fmt) for n in ('default','selected')]])
    body='<!doctype html><meta charset="utf-8"><title>实盘方案综合比较</title><style>body{font:16px system-ui;color:#192c44;margin:32px;max-width:1500px}p{line-height:1.7}table{border-collapse:collapse;width:100%;margin:20px 0}td,th{padding:9px;border:1px solid #ddd;text-align:right}th{background:#edf3fb}</style><h1>实盘选择：冻结新模型＋本次多起点搜索选中参数</h1><p><b>建议选择15日30%＋60日70%，buy_n30/sell_m40/最短持仓7日/每日最多主动换出1只。</b>这是部署建议，没有修改实盘默认。两套共用同一冻结模型；不根据外验再搜索权重。验证期2/3年多起点优势有支持，流动性与分散度差异不足以否定；保留OOF长期回撤更差、最近不足一年组偏弱的反证。</p><p>执行与风格统计来自2022-01-04至2026-11-06的两条连续真实模拟账户，1171个收益区间。它们不是所有上线起点的持仓/成交审计；多起点收益风险证据见下方独立报告。全日成交额不是开盘可成交量，不能推导集合竞价容量。</p>'
    body+='<h2>实际交易、流动性与持仓</h2>'+table(['指标','默认','选中'],rows)
    body+='<h2>多开仓日期复核风格与流动性</h2><p>2022-01至2025-10每月首个交易日空仓启动，两策略各46个起点，均运行到2026-11-06；其完整净值/收益路径逐项等于此前逐日上线研究。下表先计算每个账户的指标，再对46个账户取中位数，不能与上表的单条连续账户统计混为同一口径。</p>'+table(['指标','默认','选中'],multirows)
    body+='<h2>实际风格变化</h2><p>小市值占比按当前因子股票池的市值排名定义；股票权重归一化到股票仓位。历史行业字段缺失，因此没有行业分散度结论，也没有使用当前行业标签倒填历史。</p>'+table(['年份','默认小市值占比','选中小市值占比','默认成交前20日额中位数/万元','选中成交前20日额中位数/万元'],years)
    body+=f'<h2>信号多样性</h2><p>两策略融合分数的日均横截面相关性：{div["fused_score_correlation"]["mean"]:.4f}；预测前40重合比例：{div["top40_prediction_overlap"]["mean"]:.1%}；实际股票权重重合：{div["actual_equity_weight_overlap"]["mean"]:.1%}。五周期不能视作五个独立策略。</p>'+table(['预测周期',3,7,15,30,60],corrtable)
    body+='<h2>因子可解释性</h2><p>固定取每月首末交易日，共118天、5724个股票日期样本；按各自实际持仓加权，覆盖约99.9%样本日股票仓位。下表是融合原始预测的绝对TreeSHAP贡献占比，不是非线性排名的精确分解，也不是收益贡献或因果证明。“其他量价及财务”仍占约一半，不能把整个模型简化成几个命名风格。</p>'+table(['因子分组','默认','选中'],groups)
    body+='<h2>额外成本压力测算</h2><p>在原费用与单边25bp滑点之外，再扣10/25/50bp×每日双边换手。使用验证期逐日上线保存路径，成交和持仓固定，不是重新模拟冲击、排队或资金不足后的交易路径。胜率是重叠历史窗口的配对比例，不是未来胜率。</p>'+table(['固定交易日数','额外单边bp','配对起点数','默认Calmar中位数','选中Calmar中位数','选中Calmar胜率'],stress)
    body+='<p><a href="../topk_launch_compare_20261109/report/index.html">完整多开仓日期对比</a> · <a href="daily_styles.csv">逐日风格明细</a> · <a href="trades_liquidity.csv">逐笔流动性明细</a> · <a href="explanations.json">主要因子贡献</a></p>'
    (R/'report.html').write_text(body,encoding='utf8')
    atomic_write_json(R/'review_audit.json',{'state':'pass_saved_outputs_trade_aggregation_and_source_lock','source_sha256':file_sha256(__file__),'input_complete_sha256':file_sha256(R/'complete.json'),'monthly_start_summary_sha256':file_sha256(R/'monthly_start_summary.json'),'report_sha256':file_sha256(R/'report.html'),'trade_rows':len(trades),'monthly_start_paths':92,'default_deployment_changed':False,'scope':'Saved input hashes, trade census and liquidity aggregates, group shares, locked model/parameters and unchanged deployment; predictive raw SHAP additivity and stored predictions asserted during actual execution. Additional92monthly-start full NAV paths match audited daily-start study. Historical industries unavailable.'})
    print(R/'report.html')

if __name__=='__main__':main()
