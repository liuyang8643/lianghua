"""Observe original frozen static strategy on the exact selected-strategy calendar."""
import csv,json,time
from pathlib import Path
import numpy as np
from offline_data import load_runtime_slice
from factor import precompute_factors
from env.action_schema import ActionSchema
from env.backtest import PreparedEpisode,EpisodeSession,run_day_config_episode
from env.fees import DEFAULT_FEE_SCHEDULE
from env.prefilter import prefilter_n_from_config
from ai.ga.config import canonicalize_individual_config
from utils.atomic_file import atomic_write_json,file_sha256
from .analyze import stats,read

R=Path('artifacts/research/static_vs_selected_liquidity_20261109')
P=Path('artifacts/research/multihorizon_pre_live_20261108_volume_fix')
def main():
    from scripts.run_research_guarded import require_guarded_job
    require_guarded_job();began=time.monotonic();R.mkdir(exist_ok=True,parents=True)
    cfg=read(P/'protocol.json');active=read(P/'active_data.json');payload=read(P/'static_baseline/config.json')
    assert file_sha256(active['runtime_path'])==active['runtime_sha256']
    rt=load_runtime_slice(active['runtime_path'],'2022-01-01','2026-11-06',preload_rows=100001,cache_dir=Path(cfg['feature_runtime_cache']))
    factors=precompute_factors(rt);schema=ActionSchema.from_config(payload,factor_names=factors.factor_names,filter_names=factors.filter_names);canonical,dayconfig=canonicalize_individual_config(payload,action_schema=schema)
    ep=PreparedEpisode.build(rt,factors,decision_start=rt.decision_start,decision_stop=rt.decision_stop,prefilter_n=prefilter_n_from_config(payload),encode_observations=False,action_schema=schema)
    session=EpisodeSession(ep,action_schema=schema,initial_cash=1000000,fees=DEFAULT_FEE_SCHEDULE)
    lookup={s:i for i,s in enumerate(rt.stock_codes)};amount=rt.field('amount');trades=[];days=[]
    def observe(before,tr):
        i=rt.index_of(tr.order_plan.decision_date);nav=float(tr.step_result.diagnostics['pretrade_nav'])
        for fill in tr.step_result.fills:
            j=lookup[fill.code];past=np.asarray(amount[i-20:i,j],float);past=past[np.isfinite(past)];adv=float(past.mean());value=float(fill.quantity*fill.price)
            trades.append({'strategy':'static','date':tr.order_plan.decision_date,'side':fill.side,'code':fill.code,'notional':value,'nav_fraction':value/nav,'day_amount':float(amount[i,j]),'adv20_prior':adv,'prior_observations':len(past),'participation_actual_adv20':value/adv if adv>0 else np.nan,'participation_per_1m_adv20':value/nav*1e6/adv if adv>0 else np.nan})
        days.append({'date':tr.order_plan.decision_date,'holdings':sum(q>0 for q in tr.step_result.account_state.positions.values()),'turnover':float(tr.info['gross_turnover_ratio'])})
    trace=run_day_config_episode(session,lambda _:dayconfig,record_details=False,on_transition=observe)
    original=Path('artifacts/research/new_topk_monthly_explain_20261108/static.npz')
    with np.load(original) as z:
        for key,v in [('nav',trace.nav),('returns',trace.portfolio_returns),('decision_dates',trace.decision_dates),('next_dates',trace.next_decision_dates)]:np.testing.assert_array_equal(v,z[key])
    with np.load('artifacts/research/topk_multistart_20261109/delivery/outer/selected/trace.npz') as z:
        np.testing.assert_array_equal(trace.decision_dates,z['decision_dates']);np.testing.assert_array_equal(trace.next_decision_dates,z['next_dates'])
    with (R/'static_trades.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(trades[0]));w.writeheader();w.writerows(trades)
    def summarize(rows):
        return {'trade_count':len(rows),'liquidity':{k:stats([r[k] for r in rows]) for k in ('day_amount','adv20_prior','participation_actual_adv20','participation_per_1m_adv20','nav_fraction')},'adv20_below20m_fraction':float(np.mean([r['adv20_prior']<2e7 for r in rows])),'adv20_below50m_fraction':float(np.mean([r['adv20_prior']<5e7 for r in rows])),'buy_adv20':stats([r['adv20_prior'] for r in rows if r['side']=='buy']),'sell_adv20':stats([r['adv20_prior'] for r in rows if r['side']=='sell'])}
    with Path('artifacts/research/topk_live_review_20261109/trades_liquidity.csv').open(encoding='utf-8-sig',newline='') as f:new=[{k:(v if k in ('strategy','date','side','code') else float(v)) for k,v in r.items()} for r in csv.DictReader(f) if r['strategy']=='selected']
    strategies={'static':summarize(trades),'selected':summarize(new)}
    strategies['static'].update(mean_holdings=float(np.mean([d['holdings'] for d in days])),mean_gross_turnover=float(np.mean([d['turnover'] for d in days])))
    review=read('artifacts/research/topk_live_review_20261109/execution_style.json')['strategies']['selected'];backtest=read('artifacts/research/topk_multistart_20261109/delivery/outer/selected/complete.json')
    strategies['selected'].update(mean_holdings=review['style']['count']['mean'],mean_gross_turnover=backtest['metrics']['mean_gross_turnover'])
    yearly={}
    for y in ('2022','2023','2024','2025','2026'):yearly[y]={n:summarize([r for r in rows if r['date'].startswith(y)]) for n,rows in [('static',trades),('selected',new)]}
    result={'state':'complete','period':[str(trace.decision_dates[0]),str(trace.next_decision_dates[-1])],'days':len(days),'strategies':strategies,'yearly':yearly,'static_configuration':payload,'static_trace_exact':True,'same_calendar_as_selected':True,'static_source_trace_sha256':file_sha256(original),'source_sha256':file_sha256(__file__),'runtime_sha256':active['runtime_sha256'],'seconds':time.monotonic()-began,'scope':'Actual fills on each continuous2022 account. Equal-weight per fill observations, not unique stocks; ex-post full-day amount and strictly prior20day amount. NAV-normalized participation allows equal-capital comparison; neither is auction liquidity or a guaranteed capacity. No strategy changes.'}
    atomic_write_json(R/'summary.json',result);print({'state':'complete','trades':len(trades),'seconds':time.monotonic()-began},flush=True)

if __name__=='__main__':main()
