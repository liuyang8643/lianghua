import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import json,time
from pathlib import Path
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256
from research.topk_multistart_delivery_20261109.outer import locked_config,load_outer
from ai.supervised.portfolio import PreparedModelPortfolio
from env.action_schema import ActionSchema
from env.backtest import EpisodeSession,run_target_weight_episode
from env.contracts import PortfolioExecutionSpec
from env.fees import DEFAULT_FEE_SCHEDULE
from env.qlib_strategy import RankBufferConfig,RankBufferPortfolio
from .analyze import OUT,stats,read

def main():
    from scripts.run_research_guarded import require_guarded_job
    require_guarded_job();began=time.monotonic();c,lock,sha=locked_config();rt,cube,prov=load_outer(c);lookup={s:i for i,s in enumerate(rt.stock_codes)}
    dirs=[Path(c['parent']),Path('artifacts/research/new_topk_ytd_20261106')];maps=[{str(d):i for i,d in enumerate(np.load(p/'features/dates.npy'))} for p in dirs]
    invs=[read(p/'features/inventory.json') for p in dirs];caps=[]
    for inv in invs:
        r=inv['Optimized__TrueMarketCap'];assert file_sha256(r['path'])==r['sha256'];caps.append(np.load(r['path'],mmap_mode='r'))
    a=rt.field('amount');op=rt.field('open');start_by_month={}
    for i in range(rt.decision_start,rt.decision_stop-252):start_by_month.setdefault(str(rt.trade_dates[i])[:7],i)
    starts=list(start_by_month.values());results={};target=OUT/'monthly_starts';target.mkdir(exist_ok=True)
    for name,p in [('default',c['baseline']),('selected',lock['parameters'])]:
        scores=np.sum(cube*(np.asarray(p['weights'])/10),axis=2);prep=PreparedModelPortfolio.from_scores(rt,scores,initial_cash=c['execution']['initial_cash'],source_hash=sha,split='monthly_start_style_review');cfg=RankBufferConfig(**{k:v for k,v in p.items() if k!='weights'})
        schema=ActionSchema(factor_names=prep.factors.factor_names,filter_names=prep.factors.filter_names,fixed_buy_n=cfg.buy_n,fixed_sell_m=cfg.sell_m,fixed_turnover_rate=cfg.max_replacements/cfg.buy_n,fixed_rebalance_band_pct=.01,schema_version='supervised-portfolio-day-v1');rows=[]
        for start in starts:
            class WindowSession(EpisodeSession):
                def reset(self,**kwargs):
                    assert not kwargs
                    return super().reset(decision_start=int(start),decision_stop=rt.decision_stop)
            session=WindowSession(prep.episode,action_schema=schema,initial_cash=prep.initial_cash,fees=DEFAULT_FEE_SCHEDULE,portfolio_spec=PortfolioExecutionSpec(cfg.sell_m,1.,allow_cash=True));strategy=RankBufferPortfolio(rt.stock_codes,cfg)
            trade_adv=[];small=[];counts=[];participation=[]
            def targets(context):return strategy.targets(context.current_market,context.current_account,context.current_index,prep.prediction[context.current_index])
            def observe(before,tr):
                date=tr.order_plan.decision_date;i=rt.index_of(date);post=dict(before.positions);nav=float(tr.step_result.diagnostics['pretrade_nav'])
                for fill in tr.step_result.fills:
                    j=lookup[fill.code];past=np.asarray(a[i-20:i,j],float);v=float(np.nanmean(past));trade_adv.append(v);participation.append(fill.quantity*fill.price/nav*1e6/v if v>0 else np.nan);post[fill.code]=post.get(fill.code,0)+(fill.quantity if fill.side=='buy' else -fill.quantity)
                codes=[s for s,q in post.items() if q>0];j=np.array([lookup[s] for s in codes]);w=np.asarray([post[s]*(float(op[i,lookup[s]]) if np.isfinite(op[i,lookup[s]]) and op[i,lookup[s]]>0 else before.last_prices.get(s,0)) for s in codes]);source=1 if date in maps[1] else 0;v=caps[source][maps[source][date],j];valid=np.isfinite(v);counts.append(len(codes));small.append(float(w[valid&(v>=.8)].sum()/w[valid].sum()) if w[valid].sum()>0 else np.nan)
            trace=run_target_weight_episode(session,schema.decode(np.ones(schema.action_dim)),targets,record_details=False,on_transition=observe)
            original=Path('artifacts/research/topk_launch_compare_20261109/outer')/name/f'{start:05d}.npz'
            with np.load(original) as z:np.testing.assert_array_equal(trace.nav,z['nav']);np.testing.assert_array_equal(trace.portfolio_returns,z['returns'])
            row={'strategy':name,'start':str(rt.trade_dates[start]),'start_index':start,'mean_holding_count':float(np.mean(counts)),'mean_smallcap_share':float(np.nanmean(small)),'trade_adv20_median':float(np.median(trade_adv)),'trade_adv20_p10':float(np.quantile(trade_adv,.1)),'participation_per1m_p95':float(np.nanquantile(participation,.95)),'native_full_path_exact':True,'original_trace_sha256':file_sha256(original)};rows.append(row);atomic_write_json(target/f'{name}_{start:05d}.json',row)
            if len(rows)%10==0:print({'strategy':name,'complete_starts':len(rows),'total':len(starts)},flush=True)
        results[name]=rows
    fields=['mean_holding_count','mean_smallcap_share','trade_adv20_median','trade_adv20_p10','participation_per1m_p95']
    summary={'starts_per_strategy':len(starts),'first_start':str(rt.trade_dates[starts[0]]),'last_start':str(rt.trade_dates[starts[-1]]),'metrics':{n:{k:stats([v[k] for v in rows]) for k in fields} for n,rows in results.items()},'scope':'First eligible trading day of every month with>=252 future returns; each cash account continues to2026-11-06. Descriptive liquidity/styles at46 monthly starts, not every daily start. Every entire NAV and return path verified exact versus daily-launch study.','source_sha256':file_sha256(__file__),'lock_sha256':sha,'seconds':time.monotonic()-began}
    atomic_write_json(OUT/'monthly_start_summary.json',summary);print({'state':'complete','starts':len(starts),'seconds':time.monotonic()-began},flush=True)

if __name__=='__main__':main()
