逐日开仓补测：冻结参数，不重新训练或选参
======================================

默认权重3/7/15/30/60日 =20/30/10/30/10%，buy40/sell40/hold3/max1。
选中权重=0/0/30/0/70%，buy30/sell40/hold7/max1。
参数及数据身份绑定既有winner_lock，原100万元初始资金、费用、合法性与公司行动口径保持。

OOF使用2011—2021各年对应折的预测，账户跨年自然延续；此区间曾用于研究选参。
外验使用最终冻结模型，2022起至2026-11-06开盘；本次仅做事后观察，不重新选择配置。

run.py对每个具备252个后续收益区间的交易日、两套策略，分别空仓启动原生账户并运行至共同截止日。
从完整路径截取前252/504/756个交易日，账户在截断前不重置。
每条路径的前252期全部字段必须与旧一年期回测逐项exact一致，否则失败停止。
short.py另补1—251个后续收益区间的所有交易日；最终截止日没有未来收益，不能回测。
这样共同截止日比较覆盖除最后一个交易日外的所有日期。

运行步骤（已运行的金融进程不得重复启动）
----------------------------------------

  .venv\Scripts\python.exe scripts/run_research_guarded.py --cwd D:\coding\WBR --logs artifacts/research/topk_launch_compare_20261109/run_logs -- D:\coding\WBR\.venv\Scripts\python.exe -m research.topk_launch_compare_20261109.run
  .venv\Scripts\python.exe scripts/run_research_guarded.py --cwd D:\coding\WBR --logs artifacts/research/topk_launch_compare_20261109/short_logs -- D:\coding\WBR\.venv\Scripts\python.exe -m research.topk_launch_compare_20261109.short
  .venv\Scripts\python.exe -m research.topk_launch_compare_20261109.report

前两个金融任务实际完成后才运行report。report独立复算全部原始路径、净值收益、费用及日期覆盖。
固定长度分别配对，不混合不同长度。共同截止日按不足1年、1—2年、2—3年、3年以上分组。
表格中年化、回撤、Calmar分别取中位数，三者不是同一个账户，不能用前两项相除重算第三项。
Calmar20%分位为较差收益风险表现；回撤分位方向不同，需看80%分位或最大值。
短期组不报告年化和Calmar推荐，仅累计收益、回撤和配对收益胜率。
全部路径保留npz+哈希，完整配对分布JSON和逐日起点CSV随报告保存。
重叠窗口不是独立样本，历史配对胜率不是未来胜率；同开盘成交仍是原理想化假设。
本补测不修改任何实盘配置，不根据结果继续调参。
