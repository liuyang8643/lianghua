"""Frozen-parameter, paired daily cash-start evaluation."""
