"""Independently audit saved daily launch paths and publish paired comparisons."""
import csv,html,json,time
from pathlib import Path
import numpy as np
from env.metrics import CALMAR_DRAWDOWN_EPSILON
from utils.atomic_file import atomic_write_json,file_sha256
from .run import ROOT,prefix

FIELDS=('annualized_return','max_drawdown','calmar','total_return','mean_gross_turnover','total_fees','mean_exposure')
def metrics(a):
    r=a['returns'];n=len(r);assert n>0 and len(a['nav'])==n+1
    np.testing.assert_allclose(r,a['nav'][1:]/a['nav'][:-1]-1,rtol=1e-10,atol=1e-12)
    curve=np.r_[1.,np.cumprod(1+r)];total=float(curve[-1]-1);annual=float(np.expm1(np.log1p(r).sum()*252/n));dd=float(np.max(1-curve/np.maximum.accumulate(curve)))
    return dict(total_return=total,annualized_return=annual,max_drawdown=dd,calmar=annual/max(dd,CALMAR_DRAWDOWN_EPSILON),mean_gross_turnover=float(a['turnover'].mean()),total_fees=float(a['fees'].sum()),mean_exposure=float(a['exposure'].mean()))

def table(head,rows):
    esc=lambda x:html.escape(str(x))
    return '<table><tr>'+''.join('<th>'+esc(x)+'</th>' for x in head)+'</tr>'+''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</table>'

def main():
    began=time.monotonic();assert (ROOT/'complete.json').exists() and (ROOT/'short_complete.json').exists()
    protocol=json.loads((ROOT/'protocol.json').read_text());old=Path('artifacts/research/topk_multistart_20261109');assert file_sha256(old/'winner_lock.json')==protocol['lock_sha256']
    assert file_sha256(Path(__file__).with_name('run.py'))==protocol['source_sha256']
    short_done=json.loads((ROOT/'short_complete.json').read_text())
    assert file_sha256(Path(__file__).with_name('short.py'))==short_done['source_sha256']
    for path,sha in json.loads((old/'stage12/identity.json').read_text())['sources'].items():assert file_sha256(path)==sha,path
    deployed=json.loads(Path('configs/default_supervised_strategy.json').read_text())
    bundle=Path(deployed['bundle'])/'manifest.json';assert file_sha256(bundle)==deployed['manifest_sha256']
    manifest=json.loads(bundle.read_text(encoding='utf8'))
    assert manifest['parameters']=={k:v for k,v in protocol['parameters']['default'].items() if k!='weights'}
    np.testing.assert_array_equal(manifest['weights'],np.asarray(protocol['parameters']['default']['weights'])/10)
    out=ROOT/'report';out.mkdir(exist_ok=True);records={};inputs={};rawrows=[];pathcount=0
    for split,label in [('oof','oof_continuous_selection_period'),('outer','outer')]:
        with np.load(old/'delivery'/label/'default/trace.npz') as z:calendar=np.concatenate((z['decision_dates'][:1],z['next_dates'])).astype(str)
        records[split]={}
        for name in ('default','selected'):
            values={}
            for folder in (ROOT/split/name,ROOT/split/(name+'_short')):
                for path in sorted(folder.glob('*.json')):
                    if not path.stem.isdigit():continue
                    r=json.loads(path.read_text());assert r['parameters']==protocol['parameters'][name] and r['identity']['lock']==protocol['lock_sha256']
                    assert file_sha256(path.with_suffix('.npz'))==r['trace_sha256']
                    with np.load(path.with_suffix('.npz')) as z:a={k:z[k] for k in z.files}
                    i=int(np.searchsorted(calendar,r['start']));assert calendar[i]==r['start'];assert r['end']==calendar[-1]
                    np.testing.assert_array_equal(a['next_dates'].astype(str),calendar[i+1:]);assert len(a['returns'])==r['transitions']==len(calendar)-i-1
                    assert a['nav'][0]==1000000
                    expected={'to_end'}|{str(h) for h in (252,504,756) if h<=r['transitions']};assert set(r['metrics'])==expected
                    for key,m in r['metrics'].items():
                        actual=metrics(a if key=='to_end' else prefix(a,int(key)))
                        for field in FIELDS:np.testing.assert_allclose(actual[field],m[field],rtol=1e-9,atol=1e-9)
                        rawrows.append([split,name,r['start'],r['end'] if key=='to_end' else str(a['next_dates'][int(key)-1]),key,r['transitions'] if key=='to_end' else int(key)]+[m[f] for f in FIELDS])
                    if r['transitions']>=252:assert r['prefix252_exact'] is True
                    assert r['start'] not in values;values[r['start']]=r;inputs[str(path)]=file_sha256(path);pathcount+=1
            assert sorted(values)==list(calendar[:-1]),'missing daily starts'
            records[split][name]=values
    summaries=[];display=[];shortdisplay=[]
    for split,cases in records.items():
        for key,lo,hi in [('252',252,None),('504',504,None),('756',756,None),('end_under1y',1,252),('end_1to2y',252,504),('end_2to3y',504,756),('end_3yplus',756,None)]:
            common=key.startswith('end_');mk='to_end' if common else key
            starts=[s for s,r in cases['default'].items() if r['transitions']>=lo and (not common or hi is None or r['transitions']<hi)];starts.sort();assert starts
            scores={n:{f:np.asarray([cases[n][s]['metrics'][mk][f] for s in starts]) for f in FIELDS} for n in cases}
            item={'split':split,'window':key,'pairs':len(starts),'first_start':starts[0],'last_start':starts[-1]}
            for name in cases:item[name]={f:{'median':float(np.median(v)),'q20':float(np.quantile(v,.2)),'q80':float(np.quantile(v,.8)),'min':float(v.min()),'max':float(v.max())} for f,v in scores[name].items()}
            item['paired']={f:{'selected_win_fraction':float(np.mean(scores['selected'][f]<scores['default'][f])) if f=='max_drawdown' else float(np.mean(scores['selected'][f]>scores['default'][f])),'median_selected_minus_default':float(np.median(scores['selected'][f]-scores['default'][f]))} for f in ('total_return','calmar','max_drawdown')}
            summaries.append(item)
            def cell(n):
                m=item[n];return f"{m['annualized_return']['median']:.2%} / {m['max_drawdown']['median']:.2%} / {m['calmar']['median']:.3f}"
            window_label={'252':'固定252日（约1年）','504':'固定504日（约2年）','756':'固定756日（约3年）','end_under1y':'共同截止：不足1年','end_1to2y':'共同截止：1—2年','end_2to3y':'共同截止：2—3年','end_3yplus':'共同截止：3年以上'}[key]
            split_label='OOF 2011—2021' if split=='oof' else '验证 2022—2026-11-06'
            row=[split_label,window_label,len(starts),starts[0]+' → '+starts[-1],cell('default'),cell('selected'),f"{item['default']['calmar']['q20']:.3f} → {item['selected']['calmar']['q20']:.3f}",f"{item['paired']['calmar']['selected_win_fraction']:.1%}",f"{item['paired']['total_return']['selected_win_fraction']:.1%}"]
            if key=='end_under1y':
                shortdisplay.append([split_label,len(starts),starts[0]+' → '+starts[-1]]+[f"{item[n]['total_return']['median']:.2%} / {item[n]['max_drawdown']['median']:.2%}" for n in cases]+[f"{item['paired']['total_return']['selected_win_fraction']:.1%}"])
            else:display.append(row)
    headers=['区间','窗口（交易日）','配对起点数','开仓日期范围','默认：年化/回撤/Calmar中位数','选中：年化/回撤/Calmar中位数','Calmar较差20%分位：默认→选中','选中Calmar胜率','选中累计收益胜率']
    with (out/'paired_summary.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f);w.writerow(headers);w.writerows(display)
    with (out/'all_daily_launches.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f);w.writerow(['split','strategy','start','end','window','transitions',*FIELDS]);w.writerows(rawrows)
    atomic_write_json(out/'summary.json',summaries)
    page='<!doctype html><meta charset="utf-8"><title>逐日开仓配对比较</title><style>body{font:16px system-ui;margin:32px;color:#182b45}table{border-collapse:collapse;width:100%;margin:24px 0}td,th{padding:10px;border:1px solid #ddd;text-align:right}th{background:#eef3fa}p{line-height:1.7}</style><h1>OOF与外验：逐日空仓上线配对比较</h1><p>固定两套模型/权重/交易参数，不重新选参。每个交易日以100万元空仓启动，按原生合法性、费用和公司行动口径回测。同起点两策略严格配对。252/504/756为固定观察长度；end为运行到各自数据共同截止日，并按剩余运行年限分组。各指标分别取中位数，不能用表中的年化除回撤重算中位Calmar。</p>'+table(headers,display)+'<h2>距截止日不足一年：只作短期观察</h2><p>短路径不与多年年化或Calmar混比。截止日当天没有后续收益，无法评价；其余每个开仓日均覆盖。</p>'+table(['区间','起点数','范围','默认：累计收益/回撤中位数','选中：累计收益/回撤中位数','选中累计收益胜率'],shortdisplay)+'<p>胜率是这些重叠历史窗口的配对比例，不是未来盈利概率或独立样本统计显著性。OOF仍属研究期；外验历史此前已看过，本次仅评价冻结参数。开盘成交仍沿用原理想化假设。</p><p><a href="paired_summary.csv">配对汇总CSV</a> · <a href="all_daily_launches.csv">全部起点明细CSV</a> · <a href="summary.json">完整分布JSON</a></p>'
    (out/'index.html').write_text(page,encoding='utf8')
    atomic_write_json(out/'audit.json',{'state':'pass_all_daily_starts_paths_metrics_and_pairing','paths':pathcount,'rows':len(rawrows),'source_sha256':file_sha256(__file__),'inputs':inputs,'files':{p.name:file_sha256(p) for p in out.iterdir() if p.is_file() and p.name!='audit.json'},'lock_sha256':protocol['lock_sha256'],'seconds':time.monotonic()-began})
    print({'audit':'pass','paths':pathcount,'report':str(out/'index.html')})

if __name__=='__main__':main()
