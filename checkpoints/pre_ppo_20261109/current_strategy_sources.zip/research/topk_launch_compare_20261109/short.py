"""Complete common-cutoff launches with fewer than252 future returns, descriptive only."""
import json,time
from pathlib import Path
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256
from . import run

def main():
    from scripts.run_research_guarded import require_guarded_job
    require_guarded_job();began=time.monotonic();results={}
    for split in ('outer','oof'):
        run.initialize(split);c,rt,params,prepared,identity,_=run.STATE
        identity=dict(identity,short_source=file_sha256(__file__))
        count=0
        for name,p in params.items():
            target=run.ROOT/split/(name+'_short');target.mkdir(parents=True,exist_ok=True)
            for start in range(max(rt.decision_start,rt.decision_stop-252),rt.decision_stop-1):
                path=target/f'{start:05d}.json';data=path.with_suffix('.npz')
                assert not path.exists(),'short run must not overwrite completed results'
                a=run.run_path(prepared[name],p,start,rt.decision_stop);n=len(a['returns']);assert 1<=n<252
                assert a['nav'][0]==c['execution']['initial_cash']
                np.testing.assert_array_equal(a['next_dates'].astype(str),rt.trade_dates[start+1:rt.decision_stop].astype(str))
                np.savez_compressed(data,**a)
                atomic_write_json(path,{'identity':identity,'parameters':p,'start_index':start,'start':str(rt.trade_dates[start]),'end':str(rt.trade_dates[rt.decision_stop-1]),'transitions':n,'metrics':{'to_end':run.summarize(a)},'prefix252_exact':None,'trace_sha256':file_sha256(data)})
                count+=1
        results[split]=count
        print({'short_split_complete':split,'paths':count},flush=True)
    atomic_write_json(run.ROOT/'short_complete.json',{'state':'complete','paths':results,'seconds':time.monotonic()-began,'source_sha256':file_sha256(__file__)})

if __name__=='__main__':main()
