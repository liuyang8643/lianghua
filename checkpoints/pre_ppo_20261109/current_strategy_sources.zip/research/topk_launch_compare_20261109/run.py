import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import concurrent.futures,json,multiprocessing,time
from pathlib import Path
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256
from research.topk_multistart_delivery_20261109.outer import locked_config,load_outer
from research.topk_multistart_20261109.evaluator import run_path,summarize
from ai.supervised.portfolio import PreparedModelPortfolio

ROOT=Path('artifacts/research/topk_launch_compare_20261109')
STATE=None

def prefix(a,n):return {k:v[:n+1] if k=='nav' else v[:n] for k,v in a.items()}

def initialize(split):
    global STATE
    from ai.supervised.multihorizon_search import load_forecasts
    c,lock,sha=locked_config()
    rt,cube,provenance=load_forecasts(Path(c['parent']),'oof') if split=='oof' else load_outer(c)
    params={'default':c['baseline'],'selected':lock['parameters']}
    prepared={name:PreparedModelPortfolio.from_scores(rt,np.sum(cube*(np.asarray(p['weights'])/10),axis=2),initial_cash=c['execution']['initial_cash'],source_hash=sha,split='frozen_daily_launch_comparison') for name,p in params.items()}
    del cube
    identity={'lock':sha,'provenance':provenance,'source':file_sha256(__file__),'evaluator':file_sha256('research/topk_multistart_20261109/evaluator.py')}
    STATE=(c,rt,params,prepared,identity,split)
    print({'loaded':split,'pid':os.getpid()},flush=True)

def evaluate(task):
    name,start=task;c,rt,params,prepared,identity,split=STATE
    target=ROOT/split/name;target.mkdir(parents=True,exist_ok=True)
    path=target/f'{start:05d}.json';data=path.with_suffix('.npz')
    if path.exists():
        r=json.loads(path.read_text());assert r['identity']==identity and r['parameters']==params[name]
        assert file_sha256(data)==r['trace_sha256'];return name,start
    a=run_path(prepared[name],params[name],start,rt.decision_stop)
    n=rt.decision_stop-start-1;assert len(a['returns'])==n and n>=252
    assert a['nav'][0]==c['execution']['initial_cash']
    np.testing.assert_array_equal(a['next_dates'].astype(str),rt.trade_dates[start+1:rt.decision_stop].astype(str))
    old=Path(c['output'])/'delivery/diagnostics'/split/name/'fresh252'/f'{start:05d}.json'
    prior=json.loads(old.read_text());assert prior['parameters']==params[name] and prior['identity']['lock']==identity['lock']
    assert file_sha256(old.with_suffix('.npz'))==prior['trace_sha256']
    with np.load(old.with_suffix('.npz')) as z:
        for k,v in prefix(a,252).items():np.testing.assert_array_equal(v,z[k],err_msg=f'prefix changed:{split}/{name}/{start}/{k}')
    np.savez_compressed(data,**a)
    metrics={str(h):summarize(prefix(a,h)) for h in (252,504,756) if h<=n}
    metrics['to_end']=summarize(a)
    atomic_write_json(path,{'identity':identity,'parameters':params[name],'start_index':start,'start':str(rt.trade_dates[start]),'end':str(rt.trade_dates[rt.decision_stop-1]),'transitions':n,'metrics':metrics,'prefix252_exact':True,'trace_sha256':file_sha256(data)})
    return name,start

def main():
    from scripts.run_research_guarded import require_guarded_job
    require_guarded_job();began=time.monotonic();c,lock,sha=locked_config();ROOT.mkdir(parents=True,exist_ok=True)
    protocol={'state':'frozen_post_selection_evaluation','lock_sha256':sha,'source_sha256':file_sha256(__file__),'parameters':{'default':c['baseline'],'selected':lock['parameters']},'horizons':[252,504,756],'common_end_min_transitions':252,'common_end_bands':{'1_to_2y':[252,504],'2_to_3y':[504,756],'3y_plus':[756,None]},'workers':4,'scope':'Every eligible trading-day cash start, same starting cash and native fees; common-end starts with <252 future transitions excluded from inference. Overlapping paths are not independent samples. No model training or parameter reselection.'}
    if (ROOT/'protocol.json').exists():assert json.loads((ROOT/'protocol.json').read_text())==protocol
    else:atomic_write_json(ROOT/'protocol.json',protocol)
    for split in ('outer','oof'):
        splitfile=ROOT/split/'complete.json'
        if splitfile.exists():continue
        with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('spawn'),initializer=initialize,initargs=(split,)) as pool:
            # Existing audited252 diagnostics enumerate every eligible start.
            prior=Path(c['output'])/'delivery/diagnostics'/split
            starts=sorted(int(p.stem) for p in (prior/'default/fresh252').glob('*.json') if p.stem.isdigit())
            other=sorted(int(p.stem) for p in (prior/'selected/fresh252').glob('*.json') if p.stem.isdigit());assert starts==other
            tasks=[(name,s) for s in starts for name in ('default','selected')]
            done=0
            for result in pool.map(evaluate,tasks,chunksize=4):
                done+=1
                if done%100==0:
                    atomic_write_json(ROOT/'status.json',{'state':'running','split':split,'complete_paths':done,'total_paths':len(tasks)})
                    print({'split':split,'done':done,'total':len(tasks)},flush=True)
        atomic_write_json(splitfile,{'state':'complete','starts_per_strategy':len(starts),'paths':len(tasks),'start_indices':starts,'lock_sha256':sha})
    assert file_sha256(Path(c['output'])/'winner_lock.json')==sha
    assert file_sha256(__file__)==protocol['source_sha256']
    atomic_write_json(ROOT/'complete.json',{'state':'financial_paths_complete_pending_audit','seconds':time.monotonic()-began,'lock_sha256':sha})

if __name__=='__main__':main()
