"""Post-lock initialization diagnostics. No scores feed back into selection."""
import gc,json,time
from pathlib import Path
import numpy as np
from env.action_schema import ActionSchema
from env.backtest import EpisodeSession,run_target_weight_episode
from env.contracts import PortfolioExecutionSpec
from env.fees import DEFAULT_FEE_SCHEDULE
from env.qlib_strategy import RankBufferConfig,RankBufferPortfolio
from ai.supervised.portfolio import PreparedModelPortfolio
from research.topk_multistart_20261109.evaluator import run_path,summarize
from utils.atomic_file import atomic_write_json,file_sha256
from .outer import locked_config,load_outer

def holding_path(prepared,p,start,stop):
    """Observe native settled holdings without altering decisions or state."""
    cfg=RankBufferConfig(**{k:v for k,v in p.items() if k!='weights'})
    schema=ActionSchema(factor_names=prepared.factors.factor_names,filter_names=prepared.factors.filter_names,
        fixed_buy_n=cfg.buy_n,fixed_sell_m=cfg.sell_m,fixed_turnover_rate=cfg.max_replacements/cfg.buy_n,
        fixed_rebalance_band_pct=.01,schema_version='supervised-portfolio-day-v1')
    class WindowSession(EpisodeSession):
        def reset(self,**kwargs):
            if kwargs:raise ValueError('diagnostic requires ordinary cash initialization')
            return super().reset(decision_start=int(start),decision_stop=int(stop))
    session=WindowSession(prepared.episode,action_schema=schema,initial_cash=prepared.initial_cash,fees=DEFAULT_FEE_SCHEDULE,
        portfolio_spec=PortfolioExecutionSpec(cfg.sell_m,1.,allow_cash=True))
    strategy=RankBufferPortfolio(prepared.runtime.stock_codes,cfg)
    lookup={code:i for i,code in enumerate(prepared.runtime.stock_codes)};held=[];counts=[]
    def targets(context):
        i=context.current_index
        return strategy.targets(context.current_market,context.current_account,i,prepared.prediction[i])
    def observe(before,tr):
        mask=np.zeros(prepared.runtime.n_stocks,dtype=np.uint8)
        for code,quantity in tr.step_result.account_state.positions.items():
            if quantity>0:mask[lookup[code]]=1
        held.append(np.packbits(mask));counts.append(int(mask.sum()))
    trace=run_target_weight_episode(session,schema.decode(np.ones(schema.action_dim)),targets,record_details=False,on_transition=observe)
    return trace,np.asarray(held),np.asarray(counts)

def overlap_summary(packed,nstocks):
    """Daily mean/min pairwise Jaccard; holdings sets, not capital weights."""
    assert packed.ndim==3 and packed.shape[0]>1
    masks=np.unpackbits(packed,axis=2)[...,:nstocks].astype(bool)
    rows=[]
    for i in range(len(masks)):
        for j in range(i+1,len(masks)):
            intersection=np.sum(masks[i]&masks[j],axis=1);union=np.sum(masks[i]|masks[j],axis=1)
            rows.append(np.divide(intersection,union,out=np.ones(len(union),float),where=union>0))
    pairs=np.asarray(rows);mean=pairs.mean(axis=0);minimum=pairs.min(axis=0)
    sustained=np.minimum.accumulate(mean[::-1])[::-1]>=.8
    first=int(np.flatnonzero(sustained)[0]) if sustained.any() else None
    return mean,minimum,{'mean_daily_pairwise_jaccard':float(mean.mean()),'first_day_sustained_mean_at_least_80pct':first,
        'day_samples':{str(i):{'mean':float(mean[i]),'minimum':float(minimum[i])} for i in sorted(set([0,min(20,len(mean)-1),min(60,len(mean)-1),min(120,len(mean)-1),len(mean)-1]))},
        'interpretation':'settled stock-set overlap, not weight/wealth equality; future-observed convergence diagnostic only'}

def fresh_starts(prepared,p,target,identity):
    target.mkdir(parents=True,exist_ok=True);records=[];rt=prepared.runtime
    for start in range(rt.decision_start,rt.decision_stop-252):
        path=target/f'{start:05d}.json'
        if path.exists():
            record=json.loads(path.read_text());assert record['identity']==identity and record['parameters']==p
            assert file_sha256(path.with_suffix('.npz'))==record['trace_sha256']
        else:
            a=run_path(prepared,p,start,start+253);assert len(a['returns'])==252
            np.savez_compressed(path.with_suffix('.npz'),**a)
            record={'start':str(rt.trade_dates[start]),'end':str(rt.trade_dates[start+252]),'parameters':p,'identity':identity,'metrics':summarize(a),'trace_sha256':file_sha256(path.with_suffix('.npz'))}
            atomic_write_json(path,record)
        records.append(record)
        if len(records)%100==0:print({'diagnostic':'fresh252','path':str(target),'complete':len(records)},flush=True)
    metrics={k:{'median':float(np.median([r['metrics'][k] for r in records])),'q20':float(np.quantile([r['metrics'][k] for r in records],.2)),
        'minimum':float(min(r['metrics'][k] for r in records)),'maximum':float(max(r['metrics'][k] for r in records))} for k in ('total_return','annualized_return','max_drawdown','calmar','mean_gross_turnover')}
    result={'paths':len(records),'horizon_transitions':252,'first_start':records[0]['start'],'last_start':records[-1]['start'],'metrics':metrics,
        'interpretation':'different market windows; not a pure causal estimate of initial-state effect and not independent samples'}
    atomic_write_json(target/'complete.json',result);return result

def common_holdings(prepared,p,target,starts,identity):
    target.mkdir(parents=True,exist_ok=True);rt=prepared.runtime;years=rt.trade_dates.astype('datetime64[Y]').astype(int)+1970;results={}
    for year in range(2012,2022):
        stop=min(rt.decision_stop,int(np.flatnonzero(years<=year)[-1])+1);packed=[];date_axis=None
        for start in starts['schedules'][str(year)]['12']:
            path=target/f'{year}_{start}.npz'
            if path.exists():
                receipt=json.loads(path.with_suffix('.json').read_text());assert receipt['identity']==identity and receipt['parameters']==p
                assert receipt['sha256']==file_sha256(path)
                with np.load(path) as z:hold=z['holdings'];dates=z['dates']
            else:
                trace,hold,counts=holding_path(prepared,p,start,stop)
                dates=np.asarray(trace.next_decision_dates).astype(str);mask=np.char.startswith(dates,str(year))
                hold=hold[mask];dates=dates[mask]
                np.savez_compressed(path,holdings=hold,dates=dates,returns=trace.portfolio_returns[mask],holding_count=counts[mask])
                atomic_write_json(path.with_suffix('.json'),{'identity':identity,'parameters':p,'sha256':file_sha256(path)})
            if date_axis is None:date_axis=dates
            else:np.testing.assert_array_equal(date_axis,dates)
            packed.append(hold)
        mean,minimum,summary=overlap_summary(np.asarray(packed),rt.n_stocks)
        np.savez_compressed(target/f'overlap_{year}.npz',dates=date_axis,mean=mean,minimum=minimum)
        results[str(year)]=summary
    atomic_write_json(target/'complete.json',{'years':results,'paths_per_year':12,'identity':identity});return results

def main():
    from scripts.run_research_guarded import require_guarded_job
    from ai.supervised.multihorizon_search import load_forecasts
    require_guarded_job();began=time.monotonic();c,lock,sha=locked_config();root=Path(c['output']);results={}
    probe=json.loads((root/'holding_probe/complete.json').read_text());assert probe['state']=='pass_native_holding_observer'
    assert probe['diagnostics_source_sha256']==file_sha256(__file__)
    starts=json.loads((root/'start_indices.json').read_text())
    for split in ('oof','outer'):
        if split=='oof':rt,cube,provenance=load_forecasts(Path(c['parent']),'oof')
        else:rt,cube,provenance=load_outer(c)
        results[split]={}
        for name,p in [('default',c['baseline']),('selected',lock['parameters'])]:
            scores=np.sum(cube*(np.asarray(p['weights'])/10),axis=2)
            prepared=PreparedModelPortfolio.from_scores(rt,scores,initial_cash=c['execution']['initial_cash'],source_hash=sha,split='post_lock_diagnostics')
            target=root/'delivery/diagnostics'/split/name
            identity={'lock':sha,'parameters':p,'provenance':provenance,'source':file_sha256(__file__)}
            result={'fresh252':fresh_starts(prepared,p,target/'fresh252',identity)}
            if split=='oof':result['common_period_holdings']=common_holdings(prepared,p,target/'holdings',starts,identity)
            results[split][name]=result
            del prepared,scores;gc.collect()
        del rt,cube;gc.collect()
    assert file_sha256(root/'winner_lock.json')==sha
    atomic_write_json(root/'delivery/diagnostics_complete.json',{'state':'complete','results':results,'winner_lock_sha256':sha,'seconds':time.monotonic()-began,'selection_unchanged':True})

if __name__=='__main__':main()
