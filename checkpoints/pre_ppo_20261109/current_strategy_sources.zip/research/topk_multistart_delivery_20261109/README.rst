多起点联合搜索：复现与交付
========================

本目录只交付已锁定参数的评价，不参与搜索。实盘默认配置不自动修改。
工作目录 D:\coding\WBR，解释器 .venv\Scripts\python.exe。

输入和边界
----------

主协议：research/topk_multistart_20261109/protocol.json。
扩展协议：research/topk_multistart_refinement_20261109/protocol.json。
结果根：artifacts/research/topk_multistart_20261109。

模型复用 multihorizon_pre_live_20261108_volume_fix 的11折OOF与最终模型。
每折模型2005..Y-2训练、Y-1早停、Y年预测，最大60日标签边界隔离。
2011只作初始化，2012..2021作共同完整年度评价。
每个评价年从上一年各交易日开始真实账户；初始化期间使用对应当年的OOF模型。
账户/持仓年龄/现金跨年延续，评分在共同下一开盘估值日期上截取。
因此“全起点”指预先固定的上一年全部可用交易日，不是无限历史账户状态。

选参仅看训练范围OOF，外验2022..2026-11-06开盘只在锁定后运行。
该历史过去已被观察，不冒称全新盲测。最终模型样本内结果另列，仅诊断。
费用、同开盘模拟与公司行动经济账户口径继承原项目，非实盘成交保证。

已准备的阶段入口（不是一键盲重跑命令）
--------------------------------------

1. preflight.py核对父模型/预测；benchmark.py核对原生采集器与多起点采集器。
2. search.py执行12起点GA；当前活跃根不得重复启动或热改源码。
3. audit_oof.py核对真实保存训练/早停样本边界；audit_paths.py复算实际路径。
4. refinement.driver完成48起点局部进化复筛及最终候选全起点评价，写winner_lock。
5. delivery.outer完成OOF连续、最终模型样本内、外验的默认/选中参数原生回测。
6. delivery.diagnostics完成252收益区间的全部合格上线起点以及共同区间持仓重合率。
   delivery.audit_diagnostics随后独立检查完整起点清单、252日长度、指标和持仓重合率。
7. delivery.report生成汇总HTML、PNG和CSV，链接原生多Tab详细报告。
8. delivery.audit_delivery核对数值/文件哈希/报告链接；随后实际查看生成图表并对照完整目标清单。

每个金融运行均通过 scripts/run_research_guarded.py，例：

  .venv\Scripts\python.exe scripts/run_research_guarded.py --cwd D:\coding\WBR --logs <新的日志目录> -- D:\coding\WBR\.venv\Scripts\python.exe -m research.topk_multistart_refinement_20261109.driver

后续对应模块：

  research.topk_multistart_delivery_20261109.outer
  research.topk_multistart_delivery_20261109.diagnostics
  research.topk_multistart_delivery_20261109.report

报告依赖隔离：当前基础.venv没有可选LightGBM，而既有ReplayAudit所在模块在导入时
需要它。已在结果根/report_dependencies单独安装仓库要求的lightgbm==4.6.0（无依赖升级），
并记录report_dependencies_manifest.json；基础搜索环境未改变。报告阶段使用：

  .venv\Scripts\python.exe scripts/run_research_guarded.py --cwd D:\coding\WBR --logs <新的日志目录> -- D:\coding\WBR\.venv\Scripts\python.exe -m research.topk_multistart_delivery_20261109.vendor_entry research.topk_multistart_delivery_20261109.outer

vendor_entry只给该子进程加入经哈希核对的报告依赖，不注入正在运行的搜索进程。
首次无依赖探针失败于模块导入，未产生账户回放；保存在delivery_probe及对应日志。
新目录delivery_probe_vendor的2012OOF实际双份报告验证已通过，不能当作最终策略报告。

禁止在缺少真实winner_lock时加载外验预测；outer入口会核对全起点候选与选择规则。
已完成根不覆盖、不删除结果，不通过改标记跳过验收。

停止与恢复
----------

每级10代无改善为停止条件。60代是安全边界，不满足耐心条件时不得冒称收敛，
需保留原状态、单独记录预算扩展后继续；refinement入口会拒绝这种提前决选。

原stage12.search的旧恢复逻辑存在已识别缺陷：读取全部缓存再从第0代重放，会
让后面代的缓存提前参加选择。当前不中断运行不受影响；不要直接用其main恢复。
若被中断，使用独立 recover_stage12.py，只在候选按原顺序出现时读取缓存，
重建当时已经可见的记录和确切RNG；它会拒绝仍有原搜索进程存活的重复启动。
恢复算法已通过未来缓存不改变历史的合成测试；实际恢复前还需运行
audit_ga_replay.py，逐代核对已完成的真实种群、获胜者、停滞计数和RNG。
重现从头运行与恢复是不同操作；复现新实验须新目录/新协议身份，不伪装续跑。

完成标准
--------

只有所有阶段真实完成、全起点覆盖一致、原生回测与费用审计通过、参数锁定早于
外验访问、上线/持仓诊断齐全且最终报告实际生成并检查，才能标记整个任务完成。
代码已准备、单元测试通过或探针通过，均不是最终策略效果验收。
