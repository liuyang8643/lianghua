"""Final artifact checks. Does not replace model-risk or visual review."""
import json,re,time
from pathlib import Path
from urllib.parse import unquote
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256
from env.metrics import performance_from_log_rewards
from .outer import locked_config
from .report import triple

def main():
    started=time.monotonic();c,lock,sha=locked_config();root=Path(c['output']);delivery=root/'delivery'
    stage12=json.loads((root/'stage12/complete.json').read_text());stage48=json.loads((root/'stage48/complete.json').read_text())
    assert stage12['stop_reason']=='patience'
    last=json.loads((root/'stage12'/f"generation_{stage12['generations']:03d}.json").read_text());assert last['stale']>=c['ga']['patience']
    ga_audit=json.loads((root/f"ga_replay_audit_{stage12['generations']:03d}.json").read_text());assert ga_audit['state']=='pass_saved_ga_history_exact'
    assert stage48['stop_reason'] in ('patience','neighbour_exhaustion')
    refinement=json.loads((root/'refinement_ga_audit.json').read_text())
    assert refinement['state']=='pass_refinement_history_exact' and refinement['complete_sha256']==file_sha256(root/'stage48/complete.json')
    if stage48['stop_reason']=='patience':assert stage48['stale']>=10
    for stage,n in [('12',stage12['trials']),('48',stage48['trials']),('all',len(lock['all_start_candidates']))]:
        receipt=json.loads((root/f'path_audit_stage{stage}_{n:05d}.json').read_text());assert receipt['state']=='pass_saved_paths_only' and receipt['trial_count']==n
        for path,expected in receipt['inputs'].items():assert file_sha256(path)==expected
    backtests=json.loads((delivery/'backtests_complete.json').read_text(encoding='utf8'));diag=json.loads((delivery/'diagnostics_complete.json').read_text())
    assert backtests['winner_lock_sha256']==diag['winner_lock_sha256']==sha and diag['state']=='complete'
    assert diag['selection_unchanged'] is True
    census=json.loads((delivery/'diagnostic_census_audit.json').read_text())
    assert census['state']=='pass_full_diagnostic_census' and census['winner_lock_sha256']==sha
    assert census['diagnostics_complete_sha256']==file_sha256(delivery/'diagnostics_complete.json')
    accesses=list((delivery/'outer_access').glob('*.json'));assert accesses
    for path in accesses:
        event=json.loads(path.read_text());assert event['winner_lock_sha256']==sha and event['state']=='winner_verified_before_outer_load'
        assert event['time_ns']>=event['lock_mtime_ns']
    outputs={};cases=0
    for label,configs in backtests['cases'].items():
        for name,result in configs.items():
            assert result['parameters']==(c['baseline'] if name=='default' else lock['parameters'])
            target=delivery/label/name;trace=target/'trace.npz'
            assert file_sha256(trace)==result['trace_sha256'];assert result['native_compact_parity']
            assert not any(result['audit'].values())
            with np.load(trace) as z:
                returns=z['returns'];nav=z['nav'];next_dates=z['next_dates'].astype(str)
            np.testing.assert_allclose(returns,nav[1:]/nav[:-1]-1,rtol=1e-10,atol=1e-12)
            recomputed=performance_from_log_rewards(np.log1p(returns)).as_dict()
            for field,value in recomputed.items():np.testing.assert_allclose(value,result['metrics'][field],rtol=1e-10,atol=1e-10)
            for year,metrics in result['annual_valuation_year'].items():
                actual=performance_from_log_rewards(np.log1p(returns[np.char.startswith(next_dates,year)])).as_dict()
                for field,value in actual.items():np.testing.assert_allclose(value,metrics[field],rtol=1e-10,atol=1e-10)
            if label=='outer':assert next_dates[-1]==c['holdout']['end']
            if result['report']:
                assert file_sha256(result['report'])==result['report_sha256']
                report=Path(result['report']).read_text(encoding='utf8')
                assert '已清仓' in report and '交易记录' in report and '每日快照' in report
            cases+=1
    assert cases==6
    summary=delivery/'summary';manifest=json.loads((summary/'manifest.json').read_text());page=(summary/'index.html').read_text(encoding='utf8')
    assert manifest['winner_lock_sha256']==sha
    for filename,expected in manifest['files'].items():assert file_sha256(summary/filename)==expected
    for case in backtests['cases'].values():
        for result in case.values():assert triple(result['metrics']) in page
    for url in re.findall(r'(?:src|href)="([^"]+)"',page):
        if '://' in url or url.startswith('#'):continue
        path=(summary/unquote(url)).resolve();assert path.is_relative_to(root.resolve()) and path.is_file(),url
    # Default package remains the original frozen release; no deployment from this task.
    default=json.loads(Path('configs/default_supervised_strategy.json').read_text())
    assert default['strategy']=='new_model_topk' and not default['mvo_enabled']
    assert file_sha256(Path(default['bundle'])/'manifest.json')==default['manifest_sha256']
    manifest_default=json.loads((Path(default['bundle'])/'manifest.json').read_text(encoding='utf8'))
    assert manifest_default['parameters']=={k:v for k,v in c['baseline'].items() if k!='weights'}
    np.testing.assert_allclose(manifest_default['weights'],np.asarray(c['baseline']['weights'])/10,atol=0,rtol=0)
    for path in [root/'winner_lock.json',delivery/'backtests_complete.json',delivery/'diagnostics_complete.json',summary/'manifest.json',summary/'index.html']:
        outputs[str(path)]=file_sha256(path)
    atomic_write_json(delivery/'final_numeric_audit.json',{'state':'pass_artifact_numeric_and_links_pending_visual_review','cases':cases,'outer_access_receipts':len(accesses),'outputs':outputs,'seconds':time.monotonic()-started,
        'scope':'saved trace metrics, start-score receipts, GA history receipt, native fill audit, lock, diagnostic census and report links. Visual inspection is not claimed.'})
    print({'state':'pass_artifact_numeric_and_links_pending_visual_review','cases':cases})

if __name__=='__main__':main()
