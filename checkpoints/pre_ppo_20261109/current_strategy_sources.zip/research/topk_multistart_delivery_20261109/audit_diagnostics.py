"""Census and independent arithmetic for post-lock saved diagnostic paths."""
import json,time
from pathlib import Path
import numpy as np
from env.metrics import CALMAR_DRAWDOWN_EPSILON
from utils.atomic_file import atomic_write_json,file_sha256
from .outer import locked_config

def fresh_metrics(a):
    r=a['returns'];assert len(r)==252 and len(a['nav'])==253
    np.testing.assert_allclose(r,a['nav'][1:]/a['nav'][:-1]-1,rtol=1e-10,atol=1e-12)
    curve=np.r_[1.,np.cumprod(1+r)];total=float(curve[-1]-1)
    dd=float(np.max(1-curve/np.maximum.accumulate(curve)))
    return {'total_return':total,'annualized_return':total,'max_drawdown':dd,'calmar':total/max(dd,CALMAR_DRAWDOWN_EPSILON),'mean_gross_turnover':float(a['turnover'].mean())}

def overlap_from_xor(packed,nstocks):
    bits=np.unpackbits(packed,axis=-1);assert not bits[...,nstocks:].any()
    bits=bits[...,:nstocks].astype(bool);counts=bits.sum(axis=-1);values=[]
    for i in range(len(bits)):
        for j in range(i+1,len(bits)):
            difference=np.logical_xor(bits[i],bits[j]).sum(axis=1)
            combined=counts[i]+counts[j];intersection=(combined-difference)//2;union=(combined+difference)//2
            values.append(np.divide(intersection,union,out=np.ones(len(union),float),where=union>0))
    values=np.asarray(values);return values.mean(axis=0),values.min(axis=0)

def main():
    began=time.monotonic();c,lock,sha=locked_config();root=Path(c['output']);delivery=root/'delivery';inputs={};path_count=0;holding_count=0
    summary=json.loads((delivery/'diagnostics_complete.json').read_text());assert summary['state']=='complete' and summary['winner_lock_sha256']==sha
    nstocks=len(np.load(Path(c['parent'])/'features/codes.npy'));starts=json.loads((root/'start_indices.json').read_text())
    for split,label in [('oof','oof_continuous_selection_period'),('outer','outer')]:
        with np.load(delivery/label/'default/trace.npz') as z:
            calendar=np.concatenate((z['decision_dates'][:1],z['next_dates'])).astype(str)
        assert len(set(calendar))==len(calendar)
        for name,p in [('default',c['baseline']),('selected',lock['parameters'])]:
            target=delivery/'diagnostics'/split/name;fresh=target/'fresh252'
            files=sorted(x for x in fresh.glob('*.json') if x.stem.isdigit())
            assert len(files)==len(calendar)-252
            rows=[];observed=[]
            for path in files:
                record=json.loads(path.read_text());inputs[str(path)]=file_sha256(path)
                assert record['parameters']==p and record['identity']['lock']==sha
                assert file_sha256(path.with_suffix('.npz'))==record['trace_sha256']
                with np.load(path.with_suffix('.npz')) as z:a={k:z[k] for k in z.files}
                index=int(np.searchsorted(calendar,record['start']));assert calendar[index]==record['start']
                assert record['end']==calendar[index+252]
                np.testing.assert_array_equal(a['next_dates'].astype(str),calendar[index+1:index+253])
                assert a['nav'][0]==c['execution']['initial_cash']
                metrics=fresh_metrics(a)
                for k,v in metrics.items():np.testing.assert_allclose(v,record['metrics'][k],rtol=1e-9,atol=1e-10)
                rows.append(metrics);observed.append(record['start']);path_count+=1
            assert observed==calendar[:-252].tolist()
            result=summary['results'][split][name]['fresh252'];assert result['paths']==len(files) and result['horizon_transitions']==252
            for k in rows[0]:
                values=np.asarray([r[k] for r in rows])
                metrics={'median':np.median(values),'q20':np.quantile(values,.2),'minimum':values.min(),'maximum':values.max()}
                for field,v in metrics.items():np.testing.assert_allclose(v,result['metrics'][k][field],rtol=1e-9,atol=1e-10)
            if split!='oof':continue
            folder=target/'holdings'
            for year in range(2012,2022):
                packed=[];expected_dates=calendar[np.char.startswith(calendar,str(year))]
                for start in starts['schedules'][str(year)]['12']:
                    path=folder/f'{year}_{start}.npz';receipt=json.loads(path.with_suffix('.json').read_text());assert receipt['identity']['lock']==sha and receipt['parameters']==p
                    assert file_sha256(path)==receipt['sha256'];inputs[str(path)]=receipt['sha256']
                    with np.load(path) as z:
                        hold=z['holdings'];dates=z['dates'];counts=z['holding_count']
                    np.testing.assert_array_equal(dates,expected_dates)
                    np.testing.assert_array_equal(np.unpackbits(hold,axis=1)[:,:nstocks].sum(axis=1),counts)
                    packed.append(hold);holding_count+=1
                mean,minimum=overlap_from_xor(np.asarray(packed),nstocks)
                with np.load(folder/f'overlap_{year}.npz') as z:
                    np.testing.assert_array_equal(z['dates'],expected_dates)
                    np.testing.assert_allclose(z['mean'],mean,rtol=1e-12,atol=1e-12);np.testing.assert_array_equal(z['minimum'],minimum)
                result=summary['results'][split][name]['common_period_holdings'][str(year)]
                np.testing.assert_allclose(result['mean_daily_pairwise_jaccard'],mean.mean(),rtol=1e-12,atol=1e-12)
                qualifying=[i for i in range(len(mean)) if np.all(mean[i:]>=.8)]
                assert result['first_day_sustained_mean_at_least_80pct']==(qualifying[0] if qualifying else None)
    for path,expected in inputs.items():assert file_sha256(path)==expected
    atomic_write_json(delivery/'diagnostic_census_audit.json',{'state':'pass_full_diagnostic_census','fresh_paths':path_count,'holding_paths':holding_count,'inputs':inputs,
        'winner_lock_sha256':sha,'diagnostics_complete_sha256':file_sha256(delivery/'diagnostics_complete.json'),'seconds':time.monotonic()-began})
    print({'state':'pass_full_diagnostic_census','fresh_paths':path_count,'holding_paths':holding_count})

if __name__=='__main__':main()
