"""OOF-only observer parity; not a final strategy diagnostic."""
import json,time
from pathlib import Path
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from ai.supervised.multihorizon_search import load_forecasts
from ai.supervised.portfolio import PreparedModelPortfolio
from research.topk_multistart_20261109.evaluator import run_path
from utils.atomic_file import atomic_write_json,file_sha256
from .diagnostics import holding_path,overlap_summary

def main():
    require_guarded_job();began=time.monotonic();c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text());out=Path(c['output'])/'holding_probe'
    if out.exists():raise RuntimeError('probe exists; inspect without overwriting')
    out.mkdir();rt,cube,_=load_forecasts(Path(c['parent']),'oof');p=c['baseline']
    scores=np.sum(cube*(np.asarray(p['weights'])/10),axis=2)
    prepared=PreparedModelPortfolio.from_scores(rt,scores,initial_cash=c['execution']['initial_cash'],source_hash='holding-observer-probe',split='oof_probe')
    starts=json.loads((Path(c['output'])/'start_indices.json').read_text())['schedules']['2012']['12']
    stop=int(np.searchsorted(rt.trade_dates,np.datetime64('2013-01-01')))
    masks=[];total=0
    for start in (starts[0],starts[-1]):
        reference=run_path(prepared,p,start,stop);trace,held,counts=holding_path(prepared,p,start,stop)
        for key,value in [('returns',trace.portfolio_returns),('nav',trace.nav),('cash',trace.cash),('exposure',trace.exposure),('next_dates',trace.next_decision_dates)]:np.testing.assert_array_equal(reference[key],value)
        mask=np.char.startswith(np.asarray(trace.next_decision_dates).astype(str),'2012')
        np.testing.assert_array_equal(np.unpackbits(held,axis=1)[:,:rt.n_stocks].sum(axis=1),counts)
        assert np.all(counts<=p['sell_m'])
        masks.append(held[mask]);total+=len(trace.portfolio_returns)
        np.savez_compressed(out/f'path_{start}.npz',holdings=held,counts=counts,**reference)
    mean,minimum,result=overlap_summary(np.asarray(masks),rt.n_stocks)
    assert len(mean)==243 and np.all((mean>=0)&(mean<=1));np.testing.assert_array_equal(mean,minimum)
    atomic_write_json(out/'complete.json',{'state':'pass_native_holding_observer','paths':2,'transitions_per_implementation':total,'all_five_trace_arrays_exact':True,
        'holding_counts_exact':True,'overlap_summary':result,'diagnostics_source_sha256':file_sha256(Path(__file__).with_name('diagnostics.py')),'holdout_read':False,'seconds':time.monotonic()-began})
    print({'state':'pass_native_holding_observer','seconds':time.monotonic()-began},flush=True)

if __name__=='__main__':main()
