"""Build final comparison from completed locked evaluations; never select anew."""
import csv,html,json
from pathlib import Path
import numpy as np
from utils.atomic_file import atomic_write_json,file_sha256
from research.topk_multistart_refinement_20261109.cache import read_trial,digest
from .outer import locked_config

def triple(m):
    return f"{100*m['annualized_return']:.2f}% / {100*m['max_drawdown']:.2f}% / {m['calmar']:.3f}"

def table(headers,rows):
    esc=lambda x:html.escape(str(x))
    return '<table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table>'

def save_csv(path,headers,rows):
    with path.open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(headers);writer.writerows(rows)

def figures(root,records):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    plt.rcParams['font.family']=['Microsoft YaHei','DejaVu Sans']
    years=list(range(2012,2022));fig,axes=plt.subplots(2,1,figsize=(14,9),constrained_layout=True)
    colors={'default':'#2867b2','selected':'#d27718'}
    names={'default':'原默认参数','selected':'多起点选中参数'}
    for ax,metric,label in zip(axes,['annualized_return','calmar'],['各起点年化收益（%）','各起点 Calmar']):
        for offset,(name,record) in enumerate(records.items()):
            values=[np.asarray([x['metrics'][metric] for x in record['paths'] if x['year']==year])*(100 if metric=='annualized_return' else 1) for year in years]
            ax.boxplot(values,positions=np.arange(len(years))*3+offset,widths=.75,patch_artist=True,showfliers=False,whis=(10,90),
                boxprops={'facecolor':colors[name],'alpha':.6},medianprops={'color':'black'})
        ax.set_xticks(np.arange(len(years))*3+.5,years);ax.set_ylabel(label);ax.grid(axis='y',alpha=.2)
    axes[0].legend(handles=[Patch(facecolor=colors[n],label=names[n]) for n in records],loc='upper left')
    fig.suptitle('同一评价年份、不同上一年开仓日起点\n箱体25%—75%，黑线中位数，须线10%—90%；完整尾部另见原始表')
    fig.savefig(root/'start_distributions.png',dpi=150);plt.close(fig)
    default={(r['year'],r['start']):r['metrics']['total_return'] for r in records['default']['paths']}
    differences=np.full((len(years),12),np.nan)
    for i,year in enumerate(years):
        for month in range(1,13):
            values=[100*(r['metrics']['total_return']-default[(year,r['start'])]) for r in records['selected']['paths'] if r['year']==year and int(r['start'][5:7])==month]
            if values:differences[i,month-1]=np.mean(values)
    limit=max(float(np.nanmax(np.abs(differences))),.01)
    fig,ax=plt.subplots(figsize=(14,7),constrained_layout=True);im=ax.imshow(differences,cmap='RdBu',vmin=-limit,vmax=limit,aspect='auto')
    ax.set_xticks(range(12),[str(i) for i in range(1,13)]);ax.set_yticks(range(len(years)),years)
    ax.set_xlabel('上一年实际开仓月份');ax.set_ylabel('共同评价年份');ax.set_title('选中参数 − 原默认参数：配对起点的年度收益差（百分点）')
    for i in range(len(years)):
        for j in range(12):
            if np.isfinite(differences[i,j]):ax.text(j,i,f'{differences[i,j]:+.1f}',ha='center',va='center',fontsize=8,color='white' if abs(differences[i,j])>.6*limit else 'black')
    fig.colorbar(im,ax=ax,label='百分点');fig.savefig(root/'paired_start_months.png',dpi=150);plt.close(fig)

def main():
    c,lock,sha=locked_config();root=Path(c['output']);delivery=root/'delivery'
    backtests=json.loads((delivery/'backtests_complete.json').read_text(encoding='utf8'))
    diagnostics=json.loads((delivery/'diagnostics_complete.json').read_text(encoding='utf8'))
    assert diagnostics['state']=='complete' and backtests['state']=='complete_backtests_only_diagnostics_and_summary_pending'
    assert backtests['winner_lock_sha256']==diagnostics['winner_lock_sha256']==sha
    records={name:read_trial(root/'stageall/trials'/f'{digest(p)}.json') for name,p in [('default',c['baseline']),('selected',lock['parameters'])]}
    assert [(x['year'],x['start']) for x in records['default']['paths']]==[(x['year'],x['start']) for x in records['selected']['paths']]
    output=delivery/'summary';output.mkdir(exist_ok=True)
    figures(output,records)
    rows=[]
    labels={'oof_continuous_selection_period':'2011—2021 连续OOF（用于选参，非测试）','final_model_insample_not_validation':'2005—2021 最终模型样本内（仅诊断）','outer':'2022—2026-11-06开盘 外验（不选参）'}
    for case,label in labels.items():
        results=backtests['cases'][case]
        rows.append([label,triple(results['default']['metrics']),triple(results['selected']['metrics'])])
    save_csv(output/'period_comparison.csv',['区间','原默认：年化/回撤/Calmar','选中：年化/回撤/Calmar'],rows)
    execution_rows=[]
    for case,label in labels.items():
        for name,result in backtests['cases'][case].items():
            m=result['metrics'];execution_rows.append([label,name,f"{100*m['mean_gross_turnover']:.2f}%",f"{m['total_fees']:,.2f}",f"{100*m['mean_exposure']:.2f}%"])
    save_csv(output/'execution_comparison.csv',['区间','配置','日均双边换手率','累计费用(元)','平均股票仓位'],execution_rows)
    score_rows=[[name,f"{r['summary']['typical']:.4f}",f"{r['summary']['tail']:.4f}",f"{r['summary']['worst_fold']:.4f}",f"{100*r['summary']['turnover']:.2f}%",len(r['paths'])] for name,r in records.items()]
    year_rows=[];outer=backtests['cases']['outer']
    for year,m in outer['default']['annual_valuation_year'].items():year_rows.append([year,triple(m),triple(outer['selected']['annual_valuation_year'][year])])
    save_csv(output/'outer_annual.csv',['估值年份','原默认：年化/回撤/Calmar','选中：年化/回撤/Calmar'],year_rows)
    path_rows=[]
    for name,r in records.items():
        for x in r['paths']:path_rows.append([name,x['year'],x['start'],x['metrics']['annualized_return'],x['metrics']['max_drawdown'],x['metrics']['calmar'],x['metrics']['mean_gross_turnover']])
    save_csv(output/'all_start_scores.csv',['配置','评价年','开仓日','年化','最大回撤','Calmar','日均双边换手'],path_rows)
    search_rows=[]
    for stage in ('12','48','all'):
        for path in sorted((root/f'stage{stage}/trials').glob('*.json')):
            record=read_trial(path);p=record['parameters'];s=record['summary']
            search_rows.append([stage,*p['weights'],p['buy_n'],p['sell_m'],p['hold_thresh'],p['max_replacements'],s['typical'],s['tail'],s['worst_fold'],s['turnover'],len(record['paths']),file_sha256(path),record['trace_sha256']])
    save_csv(output/'all_search_results.csv',['起点阶段','3日权重单位','7日','15日','30日','60日','buy_n','sell_m','最短持仓','每日换出上限','跨折中位Calmar均值','跨折20%分位Calmar均值','最弱折中位Calmar','平均双边换手','路径数','记录SHA256','轨迹SHA256'],search_rows)
    from research.topk_multistart_refinement_20261109.driver import neighbours
    neighbour_rows=[];neighbour_details={}
    for name,p in [('default',c['baseline']),('selected',lock['parameters'])]:
        center=read_trial(root/'stage48/trials'/f'{digest(p)}.json')['summary']
        possible=neighbours(p,c['space']);observed=[];missing=[]
        for q in possible:
            path=root/'stage48/trials'/f'{digest(q)}.json'
            if not path.exists():missing.append(q);continue
            r=read_trial(path);observed.append({'parameters':q,'summary':r['summary'],'typical_difference':r['summary']['typical']-center['typical'],'record_sha256':file_sha256(path)})
        values=[r['summary']['typical'] for r in observed]
        spread=f'{min(values):.4f} / {np.median(values):.4f} / {max(values):.4f}' if values else '未评价'
        fraction=f"{100*np.mean([abs(r['typical_difference'])<=.05 for r in observed]):.1f}%" if observed else '未评价'
        neighbour_rows.append([name,len(possible),len(observed),spread,fraction])
        neighbour_details[name]={'center_parameters':p,'center_stage48_summary':center,'evaluated':observed,'not_evaluated':missing}
    atomic_write_json(output/'neighbour_stability.json',{'scope':'descriptive only from existing stage48 trials; no new evaluation, no outer data and no reselection','winner_lock_sha256':sha,'configurations':neighbour_details})
    candidate_rows=[]
    for item in lock['all_start_candidates']:
        p=item['parameters'];s=item['summary'];stage_scores=[]
        for stage in (12,48):
            path=root/f'stage{stage}/trials'/f'{digest(p)}.json'
            stage_scores.append(f"{read_trial(path)['summary']['typical']:.4f}" if path.exists() else '该阶段未评价')
        candidate_rows.append([str(p['weights']),p['buy_n'],p['sell_m'],p['hold_thresh'],p['max_replacements'],*stage_scores,f"{s['typical']:.4f}",f"{s['tail']:.4f}",'选中' if p==lock['parameters'] else ''])
    sensitivity_rows=[]
    for year in range(2012,2022):
        cell=[];paired={}
        for name in ('default','selected'):
            paths=[r for r in records[name]['paths'] if r['year']==year]
            a=np.asarray([r['metrics']['total_return'] for r in paths])*100
            cell.append(f"{np.min(a):.2f}% / {np.median(a):.2f}% / {np.max(a):.2f}%")
            paired[name]={r['start']:r['metrics']['total_return'] for r in paths}
        delta=np.asarray([paired['selected'][s]-v for s,v in paired['default'].items()])*100
        sensitivity_rows.append([year,*cell,f"{np.quantile(delta,.2):+.2f} / {np.median(delta):+.2f} / {np.quantile(delta,.8):+.2f}"])
    save_csv(output/'same_calendar_sensitivity.csv',['评价年','默认收益最小/中位/最大','选中收益最小/中位/最大','配对收益差20%/50%/80%分位(pp)'],sensitivity_rows)
    fresh_rows=[]
    for split,results in diagnostics['results'].items():
        for name,r in results.items():
            f=r['fresh252'];m=f['metrics'];fresh_rows.append([split,name,f['paths'],f['first_start']+' → '+f['last_start'],f"{100*m['total_return']['median']:.2f}%",f"{m['calmar']['median']:.3f}",f"{m['calmar']['q20']:.3f}"])
    overlap_rows=[]
    for year in map(str,range(2012,2022)):
        a=diagnostics['results']['oof']['default']['common_period_holdings'][year];b=diagnostics['results']['oof']['selected']['common_period_holdings'][year]
        overlap_rows.append([year,f"{100*a['mean_daily_pairwise_jaccard']:.1f}%",f"{100*b['mean_daily_pairwise_jaccard']:.1f}%",a['first_day_sustained_mean_at_least_80pct'],b['first_day_sustained_mean_at_least_80pct']])
    links=[]
    for name,r in outer.items():
        report=Path(r['report']);assert file_sha256(report)==r['report_sha256']
        import os
        url=Path(os.path.relpath(report,output)).as_posix()
        links.append(f'<a href="{html.escape(url,quote=True)}">{html.escape(name)}：原生多Tab详细回测报告</a>')
    parts=['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>多起点TopK联合搜索</title><style>body{font:16px/1.7 system-ui;margin:32px auto;max-width:1450px;padding:0 24px;color:#17263b;background:#f4f7fb}table{border-collapse:collapse;width:100%;background:white;margin:18px 0}th,td{padding:10px;border-bottom:1px solid #dce3ec;text-align:left}th{background:#e9eff8}img{max-width:100%;background:white}p{max-width:1200px}a{display:inline-block;margin:8px 20px 8px 0}</style><h1>多起点TopK联合搜索</h1>',
        '<p>监督模型和因子冻结；只在训练范围的年度OOF上联合搜索五周期权重与交易参数。2011年用于账户初始化，2012—2021年同区间多起点评分。外验在参数锁定后运行，不用于反选。没有修改实盘默认配置。</p>',
        '<h2>最终配置</h2>',table(['配置','3/7/15/30/60权重（单位10%）','buy_n','sell_m','最短持仓','每日主动换出上限'],[[name,p['weights'],p['buy_n'],p['sell_m'],p['hold_thresh'],p['max_replacements']] for name,p in [('原默认',c['baseline']),('选中',lock['parameters'])]]),
        '<h2>相同区间回测</h2><p>每格：年化收益 / 最大回撤 / Calmar。均扣原费用和滑点；最终估值为开盘，不是收盘。</p>',table(['区间','原默认','选中'],rows),
        '<h2>实际交易与成本</h2><p>双边换手含买入和卖出；累计费用包含原模拟的佣金、税费和滑点，并随实际账户资金规模变化。</p>',table(['区间','配置','日均双边换手率','累计费用（元）','平均股票仓位'],execution_rows),
        '<h2>全起点选择依据</h2><p>通常分数＝各折起点Calmar中位数的等权平均；尾部分数＝各折20%分位数的等权平均。这些是选参统计，不能与上表连续区间Calmar混比。先保留通常分数距最佳≤0.05的候选，再选尾部分数最高者。</p>',
        table(['配置','通常分数','尾部分数','最弱折中位数','平均双边换手','路径数'],score_rows),
        table(['权重','buy_n','sell_m','持仓天数','换出上限','12起点通常分','48起点通常分','全起点通常分','全起点尾部分','结果'],candidate_rows),
        '<h2>相邻参数稳定性（已评价部分）</h2><p>相邻配置为交易参数移动一个候选档位，或两周期之间转移10%权重。仅比较同一48起点阶段已评价的邻居，未覆盖部分不推断。此项只作说明，不重新选参；“通常分”仍是跨折中位Calmar均值。</p>',
        table(['配置','可能邻居数','已评价数','邻居通常分最小/中位/最大','与中心相差≤0.05的已评价占比'],neighbour_rows),
        '<img src="start_distributions.png" alt="各评价年份不同起点表现分布"><img src="paired_start_months.png" alt="相同起点收益差">',
        '<h2>开仓路径到底造成多大差异</h2><p>同一年评价区间下，各起点实际净收益的最小值 / 中位数 / 最大值。配对差固定开仓日、评价区间和数据，比较选中与默认配置。这里量化差异，不把它强行解释成“收益的一半由开仓日决定”。</p>',
        table(['评价年','默认收益最小/中位/最大','选中收益最小/中位/最大','配对收益差20%/50%/80%分位（百分点）'],sensitivity_rows),
        '<h2>外验各年</h2><p>同一连续账户按下一开盘估值年份分组；2026年不足一年，年化是换算值。</p>',table(['年份','原默认：年化/回撤/Calmar','选中：年化/回撤/Calmar'],year_rows),
        '<h2>任意日期上线诊断</h2><p>每个可用交易日空仓启动，持有相同252个收益区间。包含不同市场窗口，不能把所有差异归因于初始持仓；重叠窗口不是独立样本。OOF结果仍属于研究期。</p>',
        table(['数据','配置','起点数','起点范围','252日收益中位数','Calmar中位数','Calmar20%分位'],fresh_rows),
        '<h2>共同区间的持仓接近程度</h2><p>每年取12个固定初始化日期。重合率为两账户股票集合交集÷并集的配对平均，不代表权重或财富相同。最后两列为从评价年首日起、此后始终保持平均重合率≥80%的位置索引；None表示未达到。</p>',
        table(['评价年','默认平均重合率','选中平均重合率','默认持续接近起点','选中持续接近起点'],overlap_rows),
        '<h2>详细报告与限制</h2>',''.join(links),
        '<p>开盘信号按同一开盘价成交仍是既有理想化假设；实盘排队、冲击和部分成交不能由本次搜索保证。公司行动沿用原经济账户口径。外验历史此前已被观察，本次未参与选择，不等于新盲测。搜索只证明已评价候选中的选择，不保证整个135,135组合的全局最优。</p>',
        '<p><a href="all_search_results.csv">全部阶段、全部已评价参数的搜索成绩</a><a href="all_start_scores.csv">默认与选中参数的全起点明细</a><a href="period_comparison.csv">区间对比表</a><a href="outer_annual.csv">外验年度表</a></p></html>']
    page=output/'index.html';page.write_text(''.join(parts),encoding='utf8')
    atomic_write_json(output/'manifest.json',{'state':'rendered_pending_final_review','winner_lock_sha256':sha,'files':{p.name:file_sha256(p) for p in output.iterdir() if p.is_file() and p.name!='manifest.json'},'inputs':{'backtests':file_sha256(delivery/'backtests_complete.json'),'diagnostics':file_sha256(delivery/'diagnostics_complete.json')}})
    print(page)

if __name__=='__main__':main()
