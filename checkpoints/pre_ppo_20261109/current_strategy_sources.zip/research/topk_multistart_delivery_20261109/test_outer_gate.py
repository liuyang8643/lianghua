import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from . import outer

class OuterGate(unittest.TestCase):
    def test_no_winner_no_outer_load(self):
        with tempfile.TemporaryDirectory() as folder:
            config=Path(folder)/'config.json';c={'output':folder};config.write_text(json.dumps(c))
            with patch.object(outer,'CONFIG',config):
                with self.assertRaisesRegex(RuntimeError,'outer access prohibited'):outer.locked_config()
                with self.assertRaisesRegex(RuntimeError,'outer access prohibited'):outer.load_outer(c)

    def test_unsealed_winner_denied(self):
        with tempfile.TemporaryDirectory() as folder:
            config=Path(folder)/'config.json';config.write_text(json.dumps({'output':folder}))
            (Path(folder)/'winner_lock.json').write_text(json.dumps({'state':'draft'}))
            with patch.object(outer,'CONFIG',config):
                with self.assertRaises(AssertionError):outer.locked_config()

if __name__=='__main__':unittest.main()
