"""Frozen winner/default evaluation. No prediction load before verified lock."""
import gc,gzip,json,time
from pathlib import Path
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from utils.atomic_file import atomic_write_json,file_sha256
from research.topk_multistart_20261109.selection import select,key
from research.topk_multistart_refinement_20261109.cache import digest,read_trial

CONFIG=Path('research/topk_multistart_20261109/protocol.json')
TAIL=Path('artifacts/research/new_topk_ytd_20261106')

def locked_config():
    c=json.loads(CONFIG.read_text());root=Path(c['output']);path=root/'winner_lock.json'
    if not path.exists():raise RuntimeError('winner not locked; outer access prohibited')
    lock=json.loads(path.read_text());assert lock['state']=='locked_before_outer_evaluation'
    records=[read_trial(root/'stageall/trials'/f"{digest(x['parameters'])}.json") for x in lock['all_start_candidates']]
    assert select(records)['parameters']==lock['parameters']
    assert file_sha256(root/'stage48/complete.json')==lock['stage48_sha256']
    assert file_sha256(root/'stage48/identity.json')==lock['identity_sha256']
    return c,lock,file_sha256(path)

def load_outer(c):
    # Defend the loader itself, including callers outside main().
    verified,lock,locksha=locked_config();assert c==verified
    access=Path(c['output'])/'delivery/outer_access';access.mkdir(parents=True,exist_ok=True)
    atomic_write_json(access/f'{time.time_ns()}.json',{'state':'winner_verified_before_outer_load','winner_lock_sha256':locksha,
        'loader_sha256':file_sha256(__file__),'time_ns':time.time_ns(),'lock_mtime_ns':(Path(c['output'])/'winner_lock.json').stat().st_mtime_ns})
    from offline_data import load_runtime_slice
    from ai.supervised.feature_data import rank_features
    parent=Path(c['parent']);active=json.loads((parent/'active_data.json').read_text())
    assert file_sha256(active['runtime_path'])==active['runtime_sha256']
    model=parent/'models/final';done=json.loads((model/'complete.json').read_text())
    for filename,field in [('model.txt','model_sha256'),('rows.npy','rows_sha256'),('predictions.npy','predictions_sha256')]:assert file_sha256(model/filename)==done[field]
    tail_done=json.loads((TAIL/'features/complete.json').read_text());assert tail_done['state']=='complete' and tail_done['model_sha256']==done['model_sha256']
    for filename,sha in tail_done['outputs'].items():assert file_sha256(TAIL/'features'/filename)==sha
    rt=load_runtime_slice(active['runtime_path'],c['holdout']['start'],c['holdout']['end'],preload_rows=252,cache_dir=Path(c['output'])/'outer_runtime_cache')
    dates=np.load(parent/'features/dates.npy');rows=np.load(model/'rows.npy');pred_dates=dates[rows]
    np.testing.assert_array_equal(np.load(parent/'features/codes.npy').astype(str),rt.stock_codes)
    raw=np.load(model/'predictions.npy',mmap_mode='r');eligible=np.load(parent/'features/eligible.npy',mmap_mode='r')
    cube=np.full((rt.n_dates,rt.n_stocks,5),np.nan)
    at=np.searchsorted(pred_dates,rt.trade_dates);hit=at<len(pred_dates);hit[hit]&=pred_dates[at[hit]]==rt.trade_dates[hit]
    idx=np.flatnonzero(hit)
    for k in range(0,len(idx),32):
        dest=idx[k:k+32];source=at[dest];values=raw[source];pool=eligible[rows[source]]&np.isfinite(values).all(axis=2)
        for h in range(5):cube[dest,:,h]=rank_features(values[:,:,h],pool)
    td=np.load(TAIL/'features/dates.npy');tp=np.load(TAIL/'features/predictions.npy',mmap_mode='r');te=np.load(TAIL/'features/eligible.npy',mmap_mode='r')
    np.testing.assert_array_equal(np.load(TAIL/'features/codes.npy').astype(str),rt.stock_codes)
    ix=np.searchsorted(rt.trade_dates,td);valid=ix<len(rt.trade_dates);valid[valid]&=rt.trade_dates[ix[valid]]==td[valid]
    for j in np.flatnonzero(valid):
        values=tp[j:j+1];pool=te[j:j+1]&np.isfinite(values).all(axis=2)
        ranks=np.stack([rank_features(values[:,:,h],pool)[0] for h in range(5)],axis=1)
        if np.isfinite(cube[ix[j]]).any():np.testing.assert_array_equal(cube[ix[j]],ranks)
        cube[ix[j]]=ranks
    assert np.isfinite(cube[rt.decision_start:rt.decision_stop]).all(axis=2).any(axis=1).all()
    assert file_sha256(Path(c['output'])/'winner_lock.json')==locksha
    provenance={'runtime_sha256':active['runtime_sha256'],'model_sha256':done['model_sha256'],'final_complete_sha256':file_sha256(model/'complete.json'),
        'tail_complete_sha256':file_sha256(TAIL/'features/complete.json'),'winner_lock_sha256':locksha,'outer_first':str(rt.trade_dates[rt.decision_start]),'outer_last_valuation':str(rt.trade_dates[rt.decision_stop-1])}
    return rt,cube,provenance

def evaluate_cases(c,lock,locksha,rt,cube,label,provenance,reports):
    from ai.supervised.portfolio import PreparedModelPortfolio
    from ai.supervised.explainability import ReplayAudit,json_value
    from testback.economic_positions import EconomicPositionLedger
    from testback.backtest import trace_to_report_result,core_report_metrics
    from testback.reportor import generate_single_report
    from env.metrics import performance_from_log_rewards
    root=Path(c['output'])/'delivery'/label;root.mkdir(parents=True,exist_ok=True);results={}
    for name,p in [('default',c['baseline']),('selected',lock['parameters'])]:
        target=root/name
        if target.exists():raise RuntimeError(f'case already exists: {target}; inspect before recovery')
        target.mkdir();scores=np.sum(cube*(np.asarray(p['weights'])/10),axis=2)
        prepared=PreparedModelPortfolio.from_scores(rt,scores,initial_cash=c['execution']['initial_cash'],source_hash=locksha,split=label)
        params={k:v for k,v in p.items() if k!='weights'};audit=ReplayAudit(target,prepared,params);ledger=EconomicPositionLedger()
        def observe(before,tr):audit(before,tr);ledger(before,tr)
        try:
            trace,metrics,_=prepared.evaluate('rank_buffer',params,details=True,on_transition=observe);audit.finish()
        finally:audit.stream.close()
        np.savez_compressed(target/'trace.npz',nav=trace.nav,returns=trace.portfolio_returns,cash=trace.cash,exposure=trace.exposure,decision_dates=trace.decision_dates,next_dates=trace.next_decision_dates)
        annual={};next_dates=np.asarray(trace.next_decision_dates).astype(str)
        for year in sorted({d[:4] for d in next_dates}):
            mask=np.char.startswith(next_dates,year);annual[year]=performance_from_log_rewards(np.log1p(trace.portfolio_returns[mask])).as_dict()
        # Details collector omits aggregate fee fields: reconstruct from audited daily rows.
        metrics['total_fees']=float(sum(d['fees'] for d in audit.days))
        replay,compact_metrics,_=prepared.evaluate('rank_buffer',params,details=False)
        for attr in ('nav','portfolio_returns','cash','exposure','decision_dates','next_decision_dates'):np.testing.assert_array_equal(getattr(trace,attr),getattr(replay,attr))
        metrics['mean_gross_turnover']=compact_metrics['mean_gross_turnover']
        np.testing.assert_allclose(metrics['total_fees'],compact_metrics['total_fees'],rtol=1e-12,atol=1e-7)
        report_path=None
        if reports:
            data=trace_to_report_result(trace,prepared.final_account,canonical_config={'weights':{'MultiHorizonScore':1.},**params})
            data['metrics']=core_report_metrics(data);ledger.enrich_report(data,prepared.final_account)
            for field in ('trace','final_account','day_config'):data.pop(field,None)
            data.update(init_cash=c['execution']['initial_cash'],period={'start':trace.decision_dates[0],'end':trace.next_decision_dates[-1],'trade_start':trace.decision_dates[0],'trade_end':trace.decision_dates[-1]},
                report_label=f'多起点搜索 / {label} / {name}',per_year_metrics=[],hs300_returns=[],rebalance_rule={'signal_timing':'T-open','trade_timing':'T-open','price_field':'open','allow_cash':True})
            data['strategy_explanation']={'description':f'冻结监督模型；五周期权重{p["weights"]}/10；交易参数{params}。外部数据不参与选参。',
                'timing_note':'同开盘信号与成交沿用既有理想化模拟；不保证实盘开盘价成交。公司行动沿用原经济账户口径。',
                'date_note':'收益按下一开盘估值日期归属；连续账户年指标与当年新建账户不同。'}
            data['audit_summary']={'state':'pass','counts':audit.counts}
            basic=json.loads(Path('artifacts/research/multihorizon_2026_explain_20261107_reference_complete/tail_source/stock_basic.json').read_text(encoding='utf8'))
            data['stock_name_map']={x['code'].split('.')[1]+'.'+x['code'].split('.')[0].upper():x['code_name'] for x in basic}
            report_dir=target/'report';report_dir.mkdir()
            with gzip.open(report_dir/'report_payload.json.gz','wt',encoding='utf8') as stream:json.dump(json_value(data),stream,ensure_ascii=False)
            data['_runtime_kline']={'trade_dates':rt.trade_dates,'stock_codes':np.asarray(rt.stock_codes),**{k:rt.field(k) for k in ('open','high','low','close','amount')}}
            report_path=str(generate_single_report(data,report_dir))
        result={'state':'complete','parameters':p,'metrics':metrics,'annual_valuation_year':annual,'audit':audit.counts,'ledger':ledger.summary(prepared.final_account),'native_compact_parity':True,
            'winner_lock_sha256':locksha,'provenance':provenance,'trace_sha256':file_sha256(target/'trace.npz'),'report':report_path,'report_sha256':file_sha256(report_path) if report_path else None}
        atomic_write_json(target/'complete.json',result);results[name]=result
        del prepared,scores,trace,replay,audit,ledger;gc.collect()
    return results

def main():
    require_guarded_job();began=time.monotonic();c,lock,sha=locked_config()
    from ai.supervised.multihorizon_search import load_forecasts
    results={}
    for split in ('oof','train'):
        rt,cube,provenance=load_forecasts(Path(c['parent']),split)
        label='oof_continuous_selection_period' if split=='oof' else 'final_model_insample_not_validation'
        results[label]=evaluate_cases(c,lock,sha,rt,cube,label,provenance,reports=False)
        del rt,cube;gc.collect()
    rt,cube,provenance=load_outer(c)
    results['outer']=evaluate_cases(c,lock,sha,rt,cube,'outer',provenance,reports=True)
    assert file_sha256(Path(c['output'])/'winner_lock.json')==sha
    atomic_write_json(Path(c['output'])/'delivery/backtests_complete.json',{'state':'complete_backtests_only_diagnostics_and_summary_pending','cases':results,'seconds':time.monotonic()-began,'winner_lock_sha256':sha})

if __name__=='__main__':main()
