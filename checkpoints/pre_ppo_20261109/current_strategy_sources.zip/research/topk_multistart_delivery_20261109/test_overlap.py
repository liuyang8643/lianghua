import unittest
import numpy as np
from .diagnostics import overlap_summary

class Overlap(unittest.TestCase):
    def test_exact_sets_not_sizes(self):
        masks=np.asarray([[[1,0,0],[1,1,0],[0,1,1]],[[0,1,0],[0,1,1],[0,1,1]]],dtype=np.uint8)
        mean,minimum,result=overlap_summary(np.packbits(masks,axis=2),3)
        np.testing.assert_allclose(mean,[0,1/3,1]);np.testing.assert_array_equal(mean,minimum)
        self.assertEqual(result['first_day_sustained_mean_at_least_80pct'],2)
    def test_temporary_convergence_does_not_count(self):
        masks=np.asarray([[[1,0],[1,0]],[[1,0],[0,1]]],dtype=np.uint8)
        _,_,result=overlap_summary(np.packbits(masks,axis=2),2)
        self.assertIsNone(result['first_day_sustained_mean_at_least_80pct'])

if __name__=='__main__':unittest.main()
