"""Pinned report-only overlay, without modifying the active search environment."""
import importlib.metadata,json,runpy,sys
from pathlib import Path
from utils.atomic_file import file_sha256

def main():
    if len(sys.argv)<2:raise RuntimeError('supply delivery module')
    module=sys.argv[1]
    if not module.startswith('research.topk_multistart_delivery_20261109.'):raise ValueError('delivery modules only')
    root=Path('artifacts/research/topk_multistart_20261109');vendor=root/'report_dependencies'
    manifest=json.loads((root/'report_dependencies_manifest.json').read_text())
    for name,sha in manifest['files'].items():assert file_sha256(vendor/name)==sha
    sys.path.insert(0,str(vendor.resolve()))
    assert importlib.metadata.version('lightgbm')=='4.6.0'
    import lightgbm
    assert Path(lightgbm.__file__).resolve().is_relative_to(vendor.resolve())
    print({'report_overlay':'lightgbm4.6.0','base_environment_unchanged':True},flush=True)
    sys.argv=[module,*sys.argv[2:]]
    runpy.run_module(module,run_name='__main__')

if __name__=='__main__':main()
