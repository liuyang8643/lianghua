import unittest
import numpy as np
from .audit_diagnostics import fresh_metrics,overlap_from_xor
from .diagnostics import overlap_summary

class AuditMath(unittest.TestCase):
    def test_252_return_and_drawdown(self):
        returns=np.zeros(252);returns[0]=.2;returns[1]=-.1;returns[2]=.1
        a={'returns':returns,'nav':1e6*np.r_[1.,np.cumprod(1+returns)],'turnover':np.full(252,.05)}
        m=fresh_metrics(a)
        self.assertAlmostEqual(m['total_return'],.188);self.assertAlmostEqual(m['max_drawdown'],.1);self.assertAlmostEqual(m['calmar'],1.88)
    def test_xor_matches_intersection(self):
        rng=np.random.default_rng(17);bits=rng.integers(0,2,size=(12,243,37),dtype=np.uint8);packed=np.packbits(bits,axis=2)
        a,b=overlap_from_xor(packed,37);x,y,_=overlap_summary(packed,37)
        np.testing.assert_array_equal(a,x);np.testing.assert_array_equal(b,y)

if __name__=='__main__':unittest.main()
