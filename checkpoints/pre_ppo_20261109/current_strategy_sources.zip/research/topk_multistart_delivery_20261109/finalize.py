"""Freeze the delivered research sources and inventory existing results, without trading."""
import hashlib,json,time,zipfile
from pathlib import Path
from utils.atomic_file import atomic_write_json,file_sha256

def main():
    began=time.monotonic()
    root=Path('artifacts/research/topk_multistart_20261109')
    out=root/'delivery/finalization';out.mkdir(exist_ok=True)
    def read(p):return json.loads((root/p).read_text(encoding='utf8'))
    assert read('delivery/final_numeric_audit.json')['state']=='pass_artifact_numeric_and_links_pending_visual_review'
    assert read('delivery/diagnostic_census_audit.json')['state']=='pass_full_diagnostic_census'
    assert read('stage12/complete.json')['stop_reason']==read('stage48/complete.json')['stop_reason']=='patience'
    assert read('winner_lock.json')['holdout_forecasts_read'] is False
    for identity,field in [('stage12/identity.json','sources'),('parallel_migration/identity.json','source'),('stage48/identity.json','source')]:
        obj=read(identity)
        if field not in obj:raise AssertionError((identity,list(obj)))
        for path,sha in obj[field].items():assert file_sha256(path)==sha,path
    sources=[]
    for folder in ['topk_multistart_20261109','topk_multistart_parallel_20261109','topk_multistart_refinement_20261109','topk_multistart_delivery_20261109']:
        sources.extend(p for p in (Path('research')/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    sources.extend([Path('scripts/run_research_guarded.py')])
    archive=out/'research_sources_v2.zip'
    assert not archive.exists(),'do not overwrite final archive'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(sources):z.write(p,str(p))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for p in sources:assert hashlib.sha256(z.read(str(p).replace('\\','/'))).hexdigest()==file_sha256(p)
    files={}
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.is_relative_to(out) or p.name in ('continuation.txt','status.json'):continue
        files[str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':file_sha256(p)}
    atomic_write_json(out/'artifact_inventory.json',{'root':str(root.resolve()),'files':files,'scope':'Existing local artifacts, raw paths, reports, provenance, environment, original snapshots and logs; external parent data remain at the hashed paths in preflight and environment manifests.'})
    images=['start_distributions.png','paired_start_months.png']
    atomic_write_json(out/'visual_review.json',{'state':'pass_png_pixel_inspection','images':{n:file_sha256(root/'delivery/summary'/n) for n in images},'review':'Both PNGs inspected with view_image: Chinese text, axes, legend, heatmap values and colour scale readable. HTML numeric, links and native tab markers audited separately. Browser interaction was not claimed.'})
    matrix={
      'frozen_models_factors_oof_boundaries':['preflight.json','oof_sample_boundary_audit.json','stage12/identity.json'],
      'native_execution_fees_and_speed':['benchmark.json','parallel_probe/complete.json','delivery/final_numeric_audit.json'],
      'joint_space_and_causal_ga_history':['ga_replay_audit_064.json','refinement_ga_audit.json','stage12/complete.json','stage48/complete.json'],
      'common_calendars_12_48_all_coverage':['start_indices.json','path_audit_stage12_01467.json','path_audit_stage48_00057.json','path_audit_stageall_00005.json'],
      'selection_and_outer_isolation':['winner_lock.json','delivery/final_numeric_audit.json'],
      'six_backtests_and_turnover':['delivery/backtests_complete.json','delivery/summary/period_comparison.csv','delivery/summary/execution_comparison.csv'],
      'all_eligible_fresh_starts_and_holdings':['delivery/diagnostics_complete.json','delivery/diagnostic_census_audit.json'],
      'reports_and_search_exports':['delivery/summary/index.html','delivery/summary/all_search_results.csv','delivery/summary/all_start_scores.csv','delivery/summary/manifest.json'],
      'environment_and_prior_sources':['environment/manifest.json','source_snapshot.zip','environment/supplementary_dependency_sources.zip','report_dependencies_manifest.json'],
      'unchanged_live_default':['delivery/final_numeric_audit.json'],
    }
    evidence={}
    for requirement,paths in matrix.items():
        evidence[requirement]={p:file_sha256(root/p) for p in paths}
    atomic_write_json(out/'completion_evidence.json',{'state':'research_delivery_complete','requirements':evidence,'sources':{str(p):file_sha256(p) for p in sources},'source_archive_sha256':file_sha256(archive),'inventory_sha256':file_sha256(out/'artifact_inventory.json'),'visual_review_sha256':file_sha256(out/'visual_review.json'),'seconds':time.monotonic()-began,'limitations':['2011 initialization only; scored2012-2021','No claim of global optimum or independent start samples','Outer historical data previously viewed, not newly blind','Same-open execution and corporate-action approximation retained','Search-selected configuration not deployed; no claim of uniformly superior performance']})
    print({'state':'research_delivery_complete','sources':len(sources),'inventory_files':len(files),'seconds':time.monotonic()-began})

if __name__=='__main__':main()
