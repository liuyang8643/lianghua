"""Actual OOF2012 integration of native ledger/audit/report, not final evaluation."""
import argparse,gc,json,time,re
from pathlib import Path
from copy import deepcopy
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from ai.supervised.multihorizon_search import load_forecasts
from offline_data import load_runtime_slice
from utils.atomic_file import atomic_write_json,file_sha256
from .outer import evaluate_cases

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output-name',default='delivery_probe');args=parser.parse_args()
    assert re.fullmatch(r'[a-zA-Z0-9_]+',args.output_name)
    require_guarded_job();began=time.monotonic();c=json.loads(Path('research/topk_multistart_20261109/protocol.json').read_text());root=Path(c['output']);probe=root/args.output_name
    if probe.exists():raise RuntimeError('probe root exists; preserve prior evidence')
    probe.mkdir();parent=Path(c['parent']);full,cube,provenance=load_forecasts(parent,'oof')
    active=json.loads((parent/'active_data.json').read_text());pc=json.loads((parent/'protocol.json').read_text())
    rt=load_runtime_slice(active['runtime_path'],'2012-01-01','2012-12-31',preload_rows=252,cache_dir=Path(pc['portfolio_runtime_cache']))
    ix=np.searchsorted(full.trade_dates,rt.trade_dates);np.testing.assert_array_equal(full.trade_dates[ix],rt.trade_dates)
    subset=cube[ix].copy();del full,cube;gc.collect()
    cfg=deepcopy(c);cfg['output']=str(probe)
    # No winner lock is created; this explicitly exercises a training-only helper.
    fake_lock={'parameters':c['baseline']};identifier='OOF2012_INTERFACE_PROBE_NOT_A_SELECTED_WINNER'
    results=evaluate_cases(cfg,fake_lock,identifier,rt,subset,'probe_oof_2012',{'probe':True,'oof_models':provenance},reports=True)
    for field in ('metrics','annual_valuation_year','audit','ledger'):
        assert results['default'][field]==results['selected'][field],field
    for name,result in results.items():
        assert result['native_compact_parity'] and not any(result['audit'].values())
        page=Path(result['report']).read_text(encoding='utf8')
        assert all(word in page for word in ('已清仓','交易记录','每日快照'))
    assert not (root/'winner_lock.json').exists(),'probe must precede selection; do not confuse with delivery'
    atomic_write_json(probe/'complete.json',{'state':'pass_oof_native_report_integration','scope':'2012OOF default parameter duplicated in two helper roles, no final winner or outer evaluation',
        'holdout_predictions_read':False,'cases':results,'outer_source_sha256':file_sha256(Path(__file__).with_name('outer.py')),'seconds':time.monotonic()-began})
    print({'state':'pass_oof_native_report_integration','seconds':time.monotonic()-began},flush=True)

if __name__=='__main__':main()
