"""Multiple cash-start paths using the unchanged native account and allocator."""
import math
import numpy as np
from env.action_schema import ActionSchema
from env.backtest import EpisodeSession
from env.contracts import PortfolioExecutionSpec
from env.fees import DEFAULT_FEE_SCHEDULE
from env.metrics import StreamingPerformanceState
from env.qlib_strategy import RankBufferConfig, RankBufferPortfolio

def run_path(prepared, parameters, start, stop):
    cfg = RankBufferConfig(**{k: parameters[k] for k in ('buy_n','sell_m','hold_thresh','max_replacements')})
    strategy = RankBufferPortfolio(prepared.runtime.stock_codes, cfg)
    schema = ActionSchema(factor_names=prepared.factors.factor_names, filter_names=prepared.factors.filter_names,
        fixed_buy_n=cfg.buy_n, fixed_sell_m=cfg.sell_m, fixed_turnover_rate=cfg.max_replacements/cfg.buy_n,
        fixed_rebalance_band_pct=.01, schema_version='supervised-portfolio-day-v1')
    session = EpisodeSession(prepared.episode, action_schema=schema, initial_cash=prepared.initial_cash,
        fees=DEFAULT_FEE_SCHEDULE, portfolio_spec=PortfolioExecutionSpec(cfg.sell_m,1.,allow_cash=True))
    session.reset(decision_start=int(start),decision_stop=int(stop))
    config = schema.decode(np.ones(schema.action_dim))
    values = {k: [] for k in ('returns','nav','cash','exposure','turnover','fees','next_dates')}
    values['nav'].append(float(session.current_account.nav))
    while not session.terminated:
        i=session.current_index
        targets=strategy.targets(session.current_market,session.current_account,i,prepared.prediction[i])
        transition=session.step(config,target_weights=targets)
        info=transition.info
        assert info['full_investment_contract_satisfied']
        for key, source in [('returns','portfolio_return'),('nav','nav'),('cash','cash'),('exposure','exposure'),('turnover','gross_turnover_ratio'),('fees','total_fees'),('next_dates','next_decision_date')]:
            values[key].append(info[source])
    arrays={k:np.asarray(v) for k,v in values.items()}
    np.testing.assert_allclose(arrays['returns'],arrays['nav'][1:]/arrays['nav'][:-1]-1,rtol=1e-10,atol=1e-12)
    return arrays

def summarize(arrays, year=None):
    mask=np.ones(len(arrays['returns']),bool) if year is None else np.char.startswith(arrays['next_dates'].astype(str),str(year))
    returns=arrays['returns'][mask]
    assert len(returns)>0
    state=StreamingPerformanceState.initial(len(returns))
    for value in returns:state=state.advance(math.log1p(float(value)))
    result=state.performance().as_dict()
    result.update(mean_gross_turnover=float(arrays['turnover'][mask].mean()),total_fees=float(arrays['fees'][mask].sum()),mean_exposure=float(arrays['exposure'][mask].mean()))
    return result

def nested_starts(indices, count):
    """Dyadic farthest-point order: deterministic, nested, no return access."""
    indices=np.asarray(indices,dtype=int)
    if count>=len(indices):return indices.copy()
    chosen=[0,len(indices)-1] if len(indices)>1 else [0]
    while len(chosen)<count:
        ordered=sorted(chosen)
        left,right=max(zip(ordered[:-1],ordered[1:]),key=lambda pair:(pair[1]-pair[0],-pair[0]))
        chosen.append((left+right)//2)
    return indices[sorted(chosen[:count])]
