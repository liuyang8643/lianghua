import unittest
import numpy as np
from .evaluator import nested_starts,summarize
from .selection import aggregate,select

class Contracts(unittest.TestCase):
    def test_nested_full_calendar(self):
        all_starts=np.arange(244)+252
        a=nested_starts(all_starts,12);b=nested_starts(all_starts,48)
        self.assertTrue(set(a)<=set(b)<=set(all_starts))
        self.assertEqual(len(set(a)),12);self.assertEqual(len(set(b)),48)
        np.testing.assert_array_equal(nested_starts(all_starts,244),all_starts)

    def test_equal_year_not_pooled(self):
        rows=[{'year':year,'start':str(i),'metrics':{'calmar':value,'mean_gross_turnover':.1}}
            for year,n,value in [(2012,10,1.),(2013,100,3.)] for i in range(n)]
        self.assertEqual(aggregate(rows)['typical'],2.)

    def test_tail_winner_and_coverage_rejection(self):
        def record(name,values):
            return {'parameters':{'name':name},'paths':[{'year':2012,'start':str(i),'metrics':{'calmar':v,'mean_gross_turnover':.1}} for i,v in enumerate(values)]}
        a=record('A',[.1,.2,1.,1.1,1.2]);b=record('B',[.7,.8,.97,1.,1.1]);c=record('C',[.7,.75,.8,.9,1.])
        self.assertEqual(select([a,b,c])['parameters']['name'],'B')
        b['paths'].pop()
        with self.assertRaises(AssertionError):select([a,b])

    def test_scored_nav_resets_peak_not_actual_account(self):
        a={'returns':np.array([1.,-.1,.2]),'next_dates':np.array(['2011-12-30','2012-01-04','2012-01-05']),
            'turnover':np.zeros(3),'fees':np.zeros(3),'exposure':np.ones(3)}
        result=summarize(a,2012)
        self.assertAlmostEqual(result['total_return'],.08)
        self.assertAlmostEqual(result['max_drawdown'],.1)
        self.assertEqual(result['transition_count'],2)

if __name__=='__main__':unittest.main()
