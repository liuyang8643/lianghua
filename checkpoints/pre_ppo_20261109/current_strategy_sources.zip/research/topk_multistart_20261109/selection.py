"""Predeclared equal-year median/tail decision rule, independent of holdout."""
import json
import numpy as np

def key(parameters):
    return json.dumps(parameters,sort_keys=True,separators=(',',':'))

def aggregate(rows):
    years=sorted({r['year'] for r in rows})
    folds=[]
    for year in years:
        subset=[r for r in rows if r['year']==year]
        assert len({r['start'] for r in subset})==len(subset), 'duplicate account start'
        values=np.asarray([r['metrics']['calmar'] for r in subset],float)
        assert np.isfinite(values).all()
        folds.append({'year':year,'count':len(subset),'median':float(np.median(values)),
            'q20':float(np.quantile(values,.2,method='linear')),
            'turnover':float(np.mean([r['metrics']['mean_gross_turnover'] for r in subset]))})
    assert folds
    return {'typical':float(np.mean([f['median'] for f in folds])),
        'tail':float(np.mean([f['q20'] for f in folds])),
        'worst_fold':min(f['median'] for f in folds),
        'turnover':float(np.mean([f['turnover'] for f in folds])), 'folds':folds}

def select(records,tolerance=.05):
    """No comparing candidates with different year/start coverage."""
    assert records
    coverage=lambda r:sorted((x['year'],x['start']) for x in r['paths'])
    common=coverage(records[0])
    assert all(coverage(r)==common for r in records), 'incomparable start coverage'
    scored=[dict(r,summary=aggregate(r['paths'])) for r in records]
    best=max(r['summary']['typical'] for r in scored)
    finalists=[r for r in scored if r['summary']['typical']>=best-tolerance-1e-12]
    return min(finalists,key=lambda r:(-r['summary']['tail'],-r['summary']['worst_fold'],r['summary']['turnover'],key(r['parameters'])))
