"""Read-only parent audit; no holdout predictions, financial replay or training."""
import json
import time
from pathlib import Path
import numpy as np
from utils.atomic_file import file_sha256, atomic_write_json

HERE = Path(__file__).resolve().parent

def main():
    begun = time.monotonic()
    protocol = json.loads((HERE / 'protocol.json').read_text(encoding='utf8'))
    parent = Path(protocol['parent'])
    output = Path(protocol['output']); output.mkdir(parents=True, exist_ok=True)
    c = json.loads((parent / 'protocol.json').read_text(encoding='utf8'))
    active = json.loads((parent / 'active_data.json').read_text(encoding='utf8'))
    assert c['fold_years'] == protocol['oof_years']
    assert file_sha256(active['runtime_path']) == active['runtime_sha256']
    dates = np.load(parent / 'features/dates.npy')
    manifest = json.loads((parent / 'features/data_manifest.json').read_text(encoding='utf8'))
    for filename in ('dates.npy', 'codes.npy'):
        assert file_sha256(parent / 'features' / filename) == manifest[filename]
    folds = []
    for year in protocol['oof_years']:
        folder = parent / 'models' / f'fold{year}'
        done = json.loads((folder / 'complete.json').read_text(encoding='utf8'))
        identity = json.loads((folder / 'identity.json').read_text(encoding='utf8'))
        assert done['state'] == 'complete'
        assert file_sha256(folder / 'identity.json') == done['identity_sha256']
        assert identity['selection'] == file_sha256(parent / 'fold_selection' / f'fold{year}' / 'complete.json')
        assert identity['data_manifest'] == file_sha256(parent / 'features/data_manifest.json')
        for filename, key in [('model.txt', 'model_sha256'), ('predictions.npy', 'predictions_sha256'), ('rows.npy', 'rows_sha256')]:
            assert file_sha256(folder / filename) == done[key]
        spec = done['spec']
        assert spec['fit'] == ['2005-01-01', f'{year-2}-12-31']
        assert spec['stop'] == [f'{year-1}-01-01', f'{year-1}-12-31']
        rows = np.load(folder / 'rows.npy'); dd = dates[rows].astype(str)
        assert all(x.startswith(str(year)) for x in dd)
        prediction = np.load(folder / 'predictions.npy', mmap_mode='r')
        assert prediction.shape[0] == len(rows) and prediction.shape[-1] == 5
        folds.append({'year': year, 'spec': spec, 'first': str(dd[0]), 'last': str(dd[-1]), 'rows': len(rows), 'shape': list(prediction.shape), 'complete_sha256': file_sha256(folder / 'complete.json')})
        print({'verified_fold': year, 'rows': len(rows)}, flush=True)
    result = {'state': 'parent_files_verified_not_full_causality_audit', 'protocol_sha256': file_sha256(HERE/'protocol.json'), 'runtime': active, 'folds': folds, 'holdout_predictions_read': False, 'seconds': time.monotonic()-begun}
    atomic_write_json(output/'preflight.json', result)
    print({'state': result['state'], 'seconds': result['seconds']}, flush=True)

if __name__ == '__main__':
    main()
