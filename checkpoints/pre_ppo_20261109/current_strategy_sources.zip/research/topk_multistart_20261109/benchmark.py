"""Native multi-start timings and full-collector parity; OOF only."""
import json,time
from pathlib import Path
from dataclasses import asdict
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from ai.supervised.multihorizon_search import load_forecasts
from ai.supervised.portfolio import PreparedModelPortfolio
from env.fees import DEFAULT_FEE_SCHEDULE
from utils.atomic_file import atomic_write_json,file_sha256
from .evaluator import run_path,summarize,nested_starts

def main():
    require_guarded_job()
    here=Path(__file__).resolve().parent
    c=json.loads((here/'protocol.json').read_text(encoding='utf8'))
    output=Path(c['output']); parent=Path(c['parent'])
    pre=json.loads((output/'preflight.json').read_text(encoding='utf8'))
    assert pre['protocol_sha256']==file_sha256(here/'protocol.json')
    parent_c=json.loads((parent/'protocol.json').read_text(encoding='utf8'))
    assert asdict(DEFAULT_FEE_SCHEDULE)==parent_c['fees']
    began=time.monotonic();rt,cube,provenance=load_forecasts(parent,'oof')
    loaded=time.monotonic()-began
    print({'phase':'loaded_oof','seconds':loaded,'shape':cube.shape},flush=True)
    p=c['baseline'];t=time.monotonic()
    scores=np.sum(cube*(np.asarray(p['weights'])/10),axis=2)
    prepared=PreparedModelPortfolio.from_scores(rt,scores,initial_cash=c['execution']['initial_cash'],source_hash=file_sha256(here/'protocol.json'),split='oof_multistart')
    preparation=time.monotonic()-t
    years=np.asarray([int(str(d)[:4]) for d in rt.trade_dates])
    rows=np.arange(rt.decision_start,rt.decision_stop)
    schedules={}
    for year in c['scored_years']:
        allowed=rows[years[rows]==year-1]
        schedules[str(year)]={str(k):nested_starts(allowed,k).tolist() for k in (12,48,len(allowed))}
    atomic_write_json(output/'start_indices.json',{'dates':[str(d) for d in rt.trade_dates],'schedules':schedules,'models':provenance})
    # Full native collector parity before accepting the custom path collector.
    t=time.monotonic();reference,metrics,_=prepared.evaluate('rank_buffer',{k:v for k,v in p.items() if k!='weights'},details=False)
    native_seconds=time.monotonic()-t
    print({'phase':'native_baseline_complete','seconds':native_seconds},flush=True)
    t=time.monotonic();path=run_path(prepared,p,rt.decision_start,rt.decision_stop);manual_seconds=time.monotonic()-t
    for key,other in [('nav',reference.nav),('returns',reference.portfolio_returns),('cash',reference.cash),('exposure',reference.exposure),('next_dates',reference.next_decision_dates)]:
        np.testing.assert_array_equal(path[key],other)
    for key,value in summarize(path).items():
        if key in metrics:np.testing.assert_allclose(value,metrics[key],rtol=1e-10,atol=1e-10)
    np.savez_compressed(output/'baseline_continuous_oof.npz',**path)
    samples=[]
    for year in (2012,2021):
        starts=nested_starts(rows[years[rows]==year-1],3)
        stop=int(rows[years[rows]<=year][-1])+1
        for start in starts:
            t=time.monotonic();a=run_path(prepared,p,int(start),stop)
            result={'year':year,'start':str(rt.trade_dates[start]),'seconds':time.monotonic()-t,'metrics':summarize(a,year),'steps':len(a['returns'])}
            np.savez_compressed(output/f'benchmark_{year}_{int(start)}.npz',**a)
            samples.append(result);print(result,flush=True)
    atomic_write_json(output/'benchmark.json',{'state':'complete','parity':'exact_nav_returns_cash_exposure_dates','load_seconds':loaded,'prepare_seconds':preparation,'native_full_seconds':native_seconds,'path_full_seconds':manual_seconds,'samples':samples,'baseline_metrics':metrics,'seconds':time.monotonic()-began})

if __name__=='__main__':main()
