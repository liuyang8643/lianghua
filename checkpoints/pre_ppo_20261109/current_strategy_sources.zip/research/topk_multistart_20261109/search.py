"""Stage-one reproducible GA. Only OOF is loaded; never reads holdout forecasts."""
import gc,hashlib,json,random,time
from pathlib import Path
import numpy as np
from scripts.run_research_guarded import require_guarded_job
from ai.supervised.multihorizon_search import load_forecasts,random_candidate
from ai.supervised.portfolio import PreparedModelPortfolio
from utils.atomic_file import atomic_write_json,file_sha256
from .evaluator import run_path,summarize
from .selection import aggregate,key,select

HERE=Path(__file__).resolve().parent

def save_trial(output,parameters,stage,prepared,starts,years):
    began=time.monotonic();paths=[];all_arrays=[];offsets=[0]
    dates=prepared.runtime.trade_dates
    date_years=np.asarray([int(str(d)[:4]) for d in dates])
    for year in years:
        stop=min(prepared.runtime.decision_stop,int(np.flatnonzero(date_years<=year)[-1])+1)
        for start in starts['schedules'][str(year)][str(stage)]:
            a=run_path(prepared,parameters,start,stop)
            paths.append({'year':year,'start':str(dates[start]),'metrics':summarize(a,year)})
            # Full native path incl initialization, sufficient to recompute every score.
            all_arrays.append(np.column_stack([a['returns'],a['nav'][:-1],a['nav'][1:],a['cash'],a['exposure'],a['turnover'],a['fees']]))
            offsets.append(offsets[-1]+len(a['returns']))
    record={'parameters':parameters,'stage':stage,'paths':paths,'summary':aggregate(paths),'seconds':time.monotonic()-began}
    name=hashlib.sha256(key(parameters).encode()).hexdigest()
    directory=output/f'stage{stage}'/'trials';directory.mkdir(parents=True,exist_ok=True)
    trace=directory/f'{name}.npz'
    np.savez_compressed(trace,values=np.concatenate(all_arrays),offsets=np.asarray(offsets),columns=np.asarray(['returns','nav_before','nav_after','cash','exposure','turnover','fees']))
    record['trace_sha256']=file_sha256(trace)
    atomic_write_json(directory/f'{name}.json',record)
    return record

def make_child(space,population,records,rng):
    # Typical gate then tail ranking is fixed before observations.
    best=max(records[key(p)]['summary']['typical'] for p in population)
    def fitness(p):
        s=records[key(p)]['summary'];eligible=s['typical']>=best-.05
        return (eligible,s['tail'] if eligible else s['typical'],s['worst_fold'],-s['turnover'])
    def parent():return max(rng.sample(population,min(3,len(population))),key=fitness)
    a,b=parent(),parent();p={'weights':list(rng.choice([a['weights'],b['weights']]))}
    for field in ('buy_n','sell_m','hold_thresh','max_replacements'):
        p[field]=rng.choice(space[field]) if rng.random()<.2 else rng.choice([a[field],b[field]])
    if rng.random()<.6:
        for _ in range(rng.randint(1,3)):
            source=rng.choice([i for i,v in enumerate(p['weights']) if v]);dest=rng.randrange(5)
            p['weights'][source]-=1;p['weights'][dest]+=1
    return p

def main():
    require_guarded_job();begin=time.monotonic()
    c=json.loads((HERE/'protocol.json').read_text(encoding='utf8'));output=Path(c['output'])
    assert json.loads((output/'benchmark.json').read_text())['state']=='complete'
    starts=json.loads((output/'start_indices.json').read_text())
    directory=output/'stage12';directory.mkdir(exist_ok=True)
    if (directory/'complete.json').exists():raise RuntimeError('completed stage is sealed')
    sources={str(p):file_sha256(p) for root in ('env','factor','offline_data','utils','ai/supervised','research/topk_multistart_20261109') for p in Path(root).rglob('*.py')}
    identity={'sources':sources,'protocol':file_sha256(HERE/'protocol.json'),'starts':file_sha256(output/'start_indices.json'),'preflight':file_sha256(output/'preflight.json')}
    if (directory/'identity.json').exists():assert json.loads((directory/'identity.json').read_text())==identity
    else:atomic_write_json(directory/'identity.json',identity)
    records={}
    for f in (directory/'trials').glob('*.json'):
        r=json.loads(f.read_text());assert file_sha256(f.with_suffix('.npz'))==r['trace_sha256'];records[key(r['parameters'])]=r
    rt,cube,provenance=load_forecasts(Path(c['parent']),'oof')
    assert provenance==starts['models']
    np.testing.assert_array_equal(rt.trade_dates.astype(str),starts['dates'])
    space=c['space'];ga=c['ga'];rng=random.Random(ga['seed'])
    population=[c['baseline']]
    for i in range(5):
        w=[0]*5;w[i]=10
        population.append(dict(weights=w,buy_n=20,sell_m=60,hold_thresh=7,max_replacements=2))
    population.append(dict(weights=[2]*5,buy_n=20,sell_m=60,hold_thresh=7,max_replacements=2))
    while len(population)<ga['population']:
        p=random_candidate(space,rng)
        if p not in population:population.append(p)
    stale=0;anchor=None
    # Deterministic replay of cached generations reconstructs exact RNG after interruption.
    for generation in range(ga['generation_safety_limit']):
        for p in population:
            if key(p) in records:continue
            signal=np.sum(cube*(np.asarray(p['weights'])/10),axis=2)
            prepared=PreparedModelPortfolio.from_scores(rt,signal,initial_cash=c['execution']['initial_cash'],source_hash=hashlib.sha256((identity['protocol']+key(p)).encode()).hexdigest(),split='oof_multistart')
            record=save_trial(output,p,12,prepared,starts,c['scored_years']);records[key(p)]=record
            del prepared,signal;gc.collect()
            status={'state':'searching','stage':12,'generation':generation+1,'trials':len(records),'last_parameters':p,'last_summary':record['summary'],'elapsed':time.monotonic()-begin}
            atomic_write_json(output/'status.json',status)
            print({'generation':generation+1,'trials':len(records),'typical':record['summary']['typical'],'tail':record['summary']['tail'],'seconds':record['seconds']},flush=True)
        winner=select(list(records.values()));s=winner['summary']
        best_typical=max(r['summary']['typical'] for r in records.values())
        score=(best_typical,s['tail'])
        improved=anchor is None or score[0]>anchor[0]+ga['min_improvement'] or (score[0]>=anchor[0]-1e-12 and score[1]>anchor[1]+ga['min_improvement'])
        if improved:stale=0;anchor=score
        else:stale+=1
        atomic_write_json(directory/f'generation_{generation+1:03d}.json',{'population':population,'winner':winner,'stale':stale,'rng':rng.getstate(),'trials':len(records)})
        if stale>=ga['patience']:break
        ranked=sorted(records.values(),key=lambda r:r['summary']['typical'],reverse=True)
        elite=[winner['parameters']]
        for r in ranked:
            if r['parameters'] not in elite:elite.append(r['parameters'])
            if len(elite)==4:break
        new=elite[:]
        while len(new)<ga['population']:
            p=random_candidate(space,rng) if rng.random()<.15 else make_child(space,population,records,rng)
            if p not in new:new.append(p)
        population=new
    for path,sha in sources.items():assert file_sha256(path)==sha, 'source changed during search'
    ranked=sorted(records.values(),key=lambda r:r['summary']['typical'],reverse=True)
    shortlist=[r['parameters'] for r in ranked[:12]]
    for r in sorted(records.values(),key=lambda r:r['summary']['tail'],reverse=True):
        if r['summary']['typical']>=ranked[0]['summary']['typical']-.05 and r['parameters'] not in shortlist:shortlist.append(r['parameters'])
        if len(shortlist)>=24:break
    if c['baseline'] not in shortlist:shortlist.append(c['baseline'])
    atomic_write_json(directory/'complete.json',{'state':'stage_complete_not_final_winner','generations':generation+1,'trials':len(records),'stop_reason':'patience' if stale>=ga['patience'] else 'safety_generation_limit','shortlist':shortlist,'seconds':time.monotonic()-begin})
    atomic_write_json(output/'status.json',{'state':'stage12_complete_pending_stage48','trials':len(records)})

if __name__=='__main__':main()
