"""Read one baseline and weight-only strategy variants."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
BASELINE_PATH = Path(__file__).with_name('config.json')

def resolve_strategy_config(payload):
    if 'base_config' not in payload:
        return payload
    # References are repository-relative and cannot form recursive inheritance.
    base_path = (ROOT / payload['base_config']).resolve()
    base_path.relative_to(ROOT)
    if base_path != BASELINE_PATH.resolve():
        raise ValueError('strategy variants must reference configs/config.json')
    base = json.loads(base_path.read_text(encoding='utf-8'))
    if 'base_config' in base:
        raise ValueError('strategy inheritance must reference the one full baseline')
    if set(payload) - {'base_config', 'individual_config'}:
        raise ValueError('weight-only strategy has unexpected fields')
    overrides = payload['individual_config']
    if set(overrides) != {'weights'}:
        raise ValueError('strategy variants may override weights only')
    return {**base, 'individual_config': {**base['individual_config'], 'weights': overrides['weights']}}

def load_strategy_config(path=BASELINE_PATH):
    return resolve_strategy_config(json.loads(Path(path).read_text(encoding='utf-8')))
